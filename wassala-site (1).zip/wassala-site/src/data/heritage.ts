/**
 * Héritage : faits sourcés dans le dossier WASSALA. Les citations et les chiffres incertains sont marqués
 * et doivent être vérifiés avant publication. Ne rien ajouter sans source.
 */
export interface TimelineEvent {
  year: string;
  title: string;
  body: string;
  quote?: { text: string; author: string };
  note?: string;
}

export const TIMELINE: readonly TimelineEvent[] = [
  {
    year: "1954",
    title: "La guerre d’indépendance algérienne éclate.",
    body: "Dès le premier jour, la question n’est pas seulement celle de l’Algérie. Les dirigeants du FLN comprennent qu’il faut internationaliser le conflit, et visent d’abord l’Afrique et l’Asie. La guerre d’Algérie sera le catalyseur qui précipite la fin de l’empire colonial français en Afrique.",
  },
  {
    year: "Avril 1955",
    title: "Conférence de Bandung.",
    body: "La délégation du FLN, conduite par Hocine Aït Ahmed et M’hamed Yazid, obtient la reconnaissance du FLN comme seul représentant légitime du peuple algérien : la première victoire diplomatique de la révolution algérienne. En septembre 1955, la question algérienne est inscrite pour la première fois à l’ordre du jour de l’Assemblée générale des Nations unies.",
  },
  {
    year: "1962",
    title: "L’indépendance.",
    body: "L’Algérie devient un État. Dès juillet 1962, Alger devient la base arrière des mouvements anticoloniaux du continent tout entier. L’Algérie en retient une idée qui orientera sa politique extérieure : sa liberté a un sens plus large qu’elle-même.",
  },
  {
    year: "1965",
    title: "Un bureau, pas une déclaration.",
    body: "Le gouvernement algérien crée un « Bureau de soutien aux mouvements de libération » : il répond aux demandes, gère les passeports, les loyers, les créneaux radio, le transit d’armes. À la fin des années 1960, 27 organisations de libération ont un bureau à Alger : le MPLA angolais, le FRELIMO mozambicain, l’ANC sud-africain, mais aussi le Vietcong et les Black Panthers.",
    quote: {
      text: "Les musulmans vont en pèlerinage à La Mecque, les chrétiens au Vatican, et les mouvements de libération à Alger.",
      author: "Amílcar Cabral",
    },
    note: "[Citation à sourcer avant publication]",
  },
  {
    year: "21 juillet – 1er août 1969",
    title: "PANAF, premier Festival culturel panafricain.",
    body: "Il réunit 5 000 participants, 40 pays africains et 200 000 spectateurs. Miriam Makeba y chante « Ana horra fi El Djazair » (« Je suis libre en Algérie »). C’est un investissement politique : les mouvements que l’Algérie héberge deviendront, pour beaucoup, des gouvernements.",
    quote: { text: "L’unité culturelle de l’Afrique et le destin partagé de tous les Africains.", author: "Houari Boumediene" },
    note: "[À vérifier : une autre source du dossier parle d’une trentaine de nations] [Citation à sourcer avant publication]",
  },
  {
    year: "Septembre 1973",
    title: "Conférence des Non-Alignés d’Alger.",
    body: "76 pays y participent, dont une soixantaine de chefs d’État et de gouvernement. Le mouvement non-aligné passe de la décolonisation politique à la décolonisation économique : souveraineté sur les ressources naturelles et Nouvel Ordre Économique Mondial.",
  },
  {
    year: "2010 – 2012",
    title: "Effacement des dettes de 14 pays africains.",
    body: "Plus de 902 millions de dollars annoncés ; des déclarations ultérieures évoquent 1,5 milliard de dollars. L’exécution technique reste peu documentée.",
  },
  {
    year: "2019",
    title: "Le tournant économique.",
    body: "Jusqu’ici sanctuaire politique, l’Algérie devient un acteur commercial. Un Forum du partenariat économique Algérie-Afrique ouvre la voie aux opérateurs privés. La ZLECAf entre en vigueur le 30 mai 2019.",
  },
  {
    year: "2021",
    title: "Début des échanges sous la ZLECAf.",
    body: "L’Algérie signe, mais demande une phase de transition : son tissu exportateur hors hydrocarbures est encore fragile.",
    note: "[À vérifier : la source indique 2021 pour l’entrée en vigueur]",
  },
  {
    year: "Septembre 2025",
    title: "4e Foire du commerce intra-africain, à Alger.",
    body: "550 rencontres B2B, plus de 70 protocoles d’intention. AGM exporte des machines agricoles vers six pays africains pour plus de 40 millions de dollars. GATMA vend 50 000 tonnes de ciment à la Mauritanie. Trois laboratoires pharmaceutiques signent avec le Burkina Faso pour 17 millions de dollars.",
  },
];

export interface Highlight {
  id: string;
  period: string;
  title: string;
  body: string;
  /** Valeur numérique pour l'animation de comptage ; absente = texte affiché tel quel. */
  kpiValue?: number;
  kpi: string;
  kpiLabel: string;
  note?: string;
}

/** Les sept grands moments de l'Algérie pour l'Afrique. */
export const HIGHLIGHTS: readonly Highlight[] = [
  {
    id: "mecque",
    period: "1962 – 1970",
    title: "Alger, « La Mecque des révolutionnaires »",
    body: "Au lendemain de l’indépendance, Alger devient la base arrière des mouvements de libération du continent : l’ANC sud-africain, le MPLA angolais, le FRELIMO mozambicain, le PAIGC de Cabral, la SWAPO namibienne. Mandela, Cabral et Nujoma y séjournent. L’Algérie fournit asile, armes, entraînement militaire et moyens de propagande.",
    kpi: "25 à 30",
    kpiLabel: "organisations de libération hébergées",
  },
  {
    id: "panaf",
    period: "Juillet – août 1969",
    title: "Le Festival panafricain d’Alger (PANAF)",
    body: "Premier grand rassemblement culturel panafricain organisé par un gouvernement africain indépendant. Il reste, dans la mémoire collective, l’expression d’une utopie post-coloniale qui n’a jamais été reproduite à cette échelle.",
    kpiValue: 200_000,
    kpi: "200 000",
    kpiLabel: "spectateurs",
    note: "[À vérifier : 40 pays ou une trentaine selon les sources]",
  },
  {
    id: "non-alignes",
    period: "Septembre 1973",
    title: "La Conférence des Non-Alignés d’Alger",
    body: "Le mouvement non-aligné passe de la décolonisation politique à la décolonisation économique, en appelant à la souveraineté sur les ressources naturelles et à un Nouvel Ordre Économique Mondial. C’est l’apogée de l’influence diplomatique algérienne au XXe siècle.",
    kpiValue: 76,
    kpi: "76",
    kpiLabel: "pays participants",
  },
  {
    id: "mediation",
    period: "18 juin 2000",
    title: "La médiation entre l’Éthiopie et l’Érythrée",
    body: "Sous la présidence tournante de l’OUA assurée par Abdelaziz Bouteflika, l’Algérie conduit les pourparlers indirects entre les deux pays. L’Accord de cessation des hostilités est signé à Alger, mettant fin à la guerre.",
    kpi: "2000",
    kpiLabel: "accord signé à Alger",
    note: "[Source à confirmer : fait issu de la première version du dossier]",
  },
  {
    id: "dettes",
    period: "2010 – 2012",
    title: "L’effacement des dettes de 14 pays africains",
    body: "Bénin, Burkina Faso, Congo, Éthiopie, Guinée, Guinée-Bissau, Mali, Mauritanie, Mozambique, Niger, Sao Tomé-et-Principe, Sénégal, Seychelles, Tanzanie. Un geste financier unilatéral dont l’exécution technique reste peu documentée, mais qui a marqué les relations bilatérales.",
    kpi: "902 M$",
    kpiLabel: "annoncés, jusqu’à 1,5 Md$ selon des déclarations ultérieures",
  },
  {
    id: "transsaharienne",
    period: "Depuis 1964",
    title: "La route transsaharienne Alger-Lagos",
    body: "Axe principal réalisé à plus de 90 %, partie algérienne opérationnelle jusqu’à la frontière nigérienne. Des branches vers le Mali (Tamanrasset-Gao-Bamako) et le Tchad (Zinder-N’Djamena) sont en cours ou en retard. L’exploitation commerciale reste inégale selon les tronçons.",
    kpiValue: 2415,
    kpi: "2 415 km",
    kpiLabel: "côté algérien",
  },
  {
    id: "tsgp",
    period: "Projet NEPAD",
    title: "Le gazoduc transsaharien Nigeria-Niger-Algérie",
    body: "Destiné à relier les réserves de gaz nigérianes aux marchés européens via le Niger et l’Algérie. Il figure parmi les projets structurants les plus ambitieux du continent. Son état d’avancement et son calendrier ne sont pas publiquement documentés avec précision.",
    kpiValue: 4128,
    kpi: "4 128 km",
    kpiLabel: "de gazoduc prévu",
  },
];

export const SOURCES = [
  "elmoudjahid.dz",
  "hal.science",
  "reseau-canope.fr",
  "theses.fr",
  "nytimes.com",
  "ambassade-algerie.ch",
  "radioalgerie.dz",
  "embmoscow.mfa.gov.dz",
  "lavoiedalgerie.dz",
] as const;
