/**
 * Contenu structurel du site (navigation, pied de page, contact).
 * Tout fait manquant reste un [placeholder] : ne jamais l'inventer.
 */
export const SITE = {
  name: "WASSALA",
  tagline: "Le lien qui construit l’Afrique.",
  city: "Alger, Algérie",
  email: "[email@wassala.org]",
  linkedin: "[LinkedIn à renseigner]",
  phone: "[Téléphone à renseigner]",
  year: String(new Date().getFullYear()),
  /** Délai de réponse annoncé aux formulaires. */
  responseDelay: "[placeholder] jours ouvrés",
} as const;

export type NavKey = "sanad" | "heritage" | "projects";

export interface NavItem {
  href: string;
  key: NavKey;
}

/**
 * Quatre pages : Accueil (logo), SANAD en deuxième (à la place de l'ancienne page « Le projet »),
 * Héritage, Projets continentaux. Les onglets Formation et Investissement n'existent plus :
 * ils sont regroupés dans Projets continentaux.
 */
export const NAV_ITEMS: readonly NavItem[] = [
  { href: "/sanad", key: "sanad" },
  { href: "/heritage", key: "heritage" },
  { href: "/projets-continentaux", key: "projects" },
];

/** Ancres de la page Projets continentaux (pied de page, palette de commandes). */
export const CONTINENTAL_ANCHORS = [
  { href: "/projets-continentaux#incubation", key: "incubation" },
  { href: "/projets-continentaux#formation", key: "training" },
  { href: "/projets-continentaux#investissement", key: "investment" },
  { href: "/projets-continentaux#placement", key: "placement" },
] as const;
