/**
 * Chiffres clés de l'accueil. `value: null` = pas encore de chiffre réel : un [placeholder] est affiché.
 * Renseigner une valeur numérique active l'animation de comptage. Ne jamais publier un chiffre non vérifié.
 * Note : WASSALA accompagne, elle ne finance pas — d'où « projets accompagnés » (et non « financés »).
 */
export const KEY_FIGURES: ReadonlyArray<{ value: number | null; label: string }> = [
  { value: null, label: "transactions accompagnées" },
  { value: null, label: "corridors couverts" },
  { value: null, label: "projets accompagnés" },
];
