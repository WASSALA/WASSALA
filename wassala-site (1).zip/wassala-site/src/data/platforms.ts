/**
 * Les quatre plateformes des Projets continentaux. Toutes sont « à venir » : SANAD est le premier service ouvert.
 * Aucun calendrier, chiffre ni partenaire n'est inventé : ce qui manque reste un [placeholder].
 */
export type PlatformId = "incubation" | "formation" | "investissement" | "placement";

export interface Platform {
  id: PlatformId;
  n: string;
  short: string;
  title: string;
  lead: string;
  body: string;
  items: readonly string[];
  /** Ce que la plateforme refuse de faire : la limite est dite clairement. */
  limit: string;
  /** false = formulation proposée, à valider par l'équipe avant publication. */
  limitValidated: boolean;
  note?: string;
}

export const PLATFORMS: readonly Platform[] = [
  {
    id: "incubation",
    n: "01",
    short: "Incubation",
    title: "Plateforme d’incubation d’entreprises africaines",
    lead: "Transformer des entrepreneurs en véritables opérateurs économiques de développement pour leur continent.",
    body: "L’incubation part de l’entrepreneur et de son terrain. Elle l’aide à lire son marché, à comprendre le cadre légal des pays visés et à lancer une activité capable de circuler dans la ZLECAf.",
    items: ["Diagnostic de l’activité et du terrain", "Fiche pays et cadre légal", "Formation entrepreneuriale", "Accompagnement au lancement"],
    limit: "Nous accompagnons des projets portés par des entrepreneurs africains ; nous ne les remplaçons pas.",
    limitValidated: false,
  },
  {
    id: "formation",
    n: "02",
    short: "Formation",
    title: "Plateforme de formation d’excellence",
    lead: "Des formations courtes et pratiques, et à terme des universités et centres de formation d’excellence africains.",
    body: "Former au commerce intra-africain tel qu’il se pratique : règles d’origine, documents, logistique, négociation. Des contenus conçus pour les réalités africaines, pas transposés d’ailleurs.",
    items: ["Audit des besoins", "Fiches pays", "Formation entrepreneuriale", "Contenus adaptés aux réalités africaines"],
    limit: "Pas de promesse de diplôme ni d’emploi : des compétences utiles, vérifiables sur le terrain.",
    limitValidated: false,
  },
  {
    id: "investissement",
    n: "03",
    short: "Investissement",
    title: "Plateforme d’investissement dans les projets africains",
    lead: "Relier les projets aux investisseurs africains et accompagner ceux qui sont prêts.",
    body: "Les projets sont préparés, évalués et vérifiés avant d’être présentés. Les investisseurs africains accèdent à une salle de transaction sécurisée. WASSALA relie et accompagne : les investisseurs décident et financent.",
    items: ["Préparation et score des projets", "Vérification KYC/KYB", "Salle de transaction sécurisée", "Suivi des engagements"],
    limit: "WASSALA accompagne, elle ne finance pas : les investisseurs décident et financent.",
    limitValidated: true,
  },
  {
    id: "placement",
    n: "04",
    short: "Placement éthique",
    title: "Plateforme de placement financier éthique et constructif",
    lead: "Orienter l’épargne africaine vers des projets africains de structuration.",
    body: "Une épargne qui construit : agriculture, énergie, industrie, technologie. Le modèle, le cadre réglementaire et la charte éthique seront publiés avant toute ouverture.",
    items: ["[Modèle à préciser]", "[Cadre réglementaire à préciser]", "[Charte éthique à rédiger]"],
    limit: "Aucune ouverture sans cadre réglementaire établi et sans charte éthique publiée.",
    limitValidated: false,
    note: "[Calendrier, modèle et partenaires à préciser avant publication]",
  },
];

/** Objectifs macro, repris de la vision WASSALA. */
export const GOALS = [
  "Transformer nos matières premières.",
  "Atteindre l’autosuffisance alimentaire grâce à une agriculture riche et pérenne.",
  "Conquérir notre indépendance énergétique et réussir la transition vers le solaire.",
  "Maîtriser notre sécurité technologique et prendre part à l’avènement inéluctable de l’IA.",
  "Créer des universités et des centres de formation d’excellence africains.",
] as const;

/** Trois principes éthiques, repris de la vision. La charte complète reste à rédiger. */
export const ETHICS = [
  { n: "01", title: "Des capitaux africains pour l’Afrique", body: "Que les capitaux africains financent l’Afrique, et que les solutions africaines répondent aux problèmes des Africains." },
  { n: "02", title: "Des projets de structuration", body: "Autosuffisance alimentaire, industrialisation, indépendance énergétique, sécurité technologique : pas des projets de vitrine." },
  { n: "03", title: "Des limites dites clairement", body: "Comme pour la garantie DAMAN de SANAD, ce qui n’est pas couvert est annoncé, jamais caché." },
] as const;
