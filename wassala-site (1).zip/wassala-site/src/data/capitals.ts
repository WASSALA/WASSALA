import type { LonLat } from "@/lib/map-geometry";

/** Capitales de l'Afrique francophone, dans l'ordre du bandeau défilant. Alger est mise en évidence. */
export const FRANCOPHONE_CAPITALS = [
  "Alger", "Rabat", "Tunis", "Nouakchott", "Dakar", "Bamako", "Conakry", "Ouagadougou",
  "Niamey", "N’Djamena", "Yamoussoukro", "Lomé", "Porto-Novo", "Yaoundé", "Libreville",
  "Brazzaville", "Kinshasa", "Bangui", "Kigali", "Gitega", "Djibouti", "Moroni", "Antananarivo",
] as const;

export type LabelAnchor = "start" | "middle" | "end";
export type NodeKind = "hub" | "capital" | "partner";

export interface MapNode {
  id: string;
  name: string;
  lonlat: LonLat;
  kind: NodeKind;
  /** Libellé affiché sur la carte, décalé par rapport au point. Absent = pas de libellé. */
  label?: { text: string; dx: number; dy: number; anchor: LabelAnchor; strong?: boolean };
}

export const NODES: readonly MapNode[] = [
  { id: "alg", name: "Alger", lonlat: [3.06, 36.75], kind: "hub", label: { text: "ALGER", dx: 0, dy: -14, anchor: "middle", strong: true } },
  // Hubs partenaires
  { id: "lag", name: "Lagos", lonlat: [3.4, 6.5], kind: "partner", label: { text: "LAGOS", dx: 10, dy: 24, anchor: "start", strong: true } },
  { id: "nai", name: "Nairobi", lonlat: [36.8, -1.3], kind: "partner", label: { text: "NAIROBI", dx: -10, dy: 24, anchor: "end", strong: true } },
  { id: "add", name: "Addis-Abeba", lonlat: [38.7, 9], kind: "partner" },
  { id: "joh", name: "Johannesburg", lonlat: [28, -26.2], kind: "partner", label: { text: "JOHANNESBURG", dx: -10, dy: -14, anchor: "end", strong: true } },
  { id: "cai", name: "Le Caire", lonlat: [31.2, 30], kind: "partner" },
  { id: "abi", name: "Abidjan", lonlat: [-4, 5.3], kind: "partner" },
  // Capitales francophones
  { id: "rab", name: "Rabat", lonlat: [-6.85, 34.0], kind: "capital", label: { text: "Rabat", dx: -8, dy: 3, anchor: "end" } },
  { id: "tun", name: "Tunis", lonlat: [10.18, 36.8], kind: "capital", label: { text: "Tunis", dx: 8, dy: 4, anchor: "start" } },
  { id: "nkc", name: "Nouakchott", lonlat: [-15.98, 18.08], kind: "capital", label: { text: "Nouakchott", dx: 8, dy: 3, anchor: "start" } },
  { id: "dak", name: "Dakar", lonlat: [-17.45, 14.7], kind: "capital", label: { text: "Dakar", dx: 8, dy: 16, anchor: "start" } },
  { id: "bam", name: "Bamako", lonlat: [-8.0, 12.65], kind: "capital", label: { text: "Bamako", dx: 6, dy: -6, anchor: "start" } },
  { id: "cky", name: "Conakry", lonlat: [-13.7, 9.5], kind: "capital", label: { text: "Conakry", dx: -8, dy: 4, anchor: "end" } },
  { id: "oua", name: "Ouagadougou", lonlat: [-1.52, 12.37], kind: "capital", label: { text: "Ouagadougou", dx: -20, dy: 16, anchor: "start" } },
  { id: "nia", name: "Niamey", lonlat: [2.11, 13.51], kind: "capital", label: { text: "Niamey", dx: 8, dy: -6, anchor: "start" } },
  { id: "ndj", name: "N’Djamena", lonlat: [15.05, 12.11], kind: "capital", label: { text: "N’Djamena", dx: 8, dy: 4, anchor: "start" } },
  { id: "yam", name: "Yamoussoukro", lonlat: [-5.28, 6.82], kind: "capital", label: { text: "Yamoussoukro", dx: -8, dy: 4, anchor: "end" } },
  { id: "lom", name: "Lomé", lonlat: [1.22, 6.13], kind: "capital", label: { text: "Lomé", dx: -8, dy: 14, anchor: "end" } },
  { id: "pno", name: "Porto-Novo", lonlat: [2.62, 6.5], kind: "capital", label: { text: "Porto-Novo", dx: 10, dy: -6, anchor: "start" } },
  { id: "yao", name: "Yaoundé", lonlat: [11.5, 3.87], kind: "capital", label: { text: "Yaoundé", dx: 8, dy: -6, anchor: "start" } },
  { id: "lib", name: "Libreville", lonlat: [9.45, 0.39], kind: "capital", label: { text: "Libreville", dx: -8, dy: 4, anchor: "end" } },
  { id: "kin", name: "Kinshasa · Brazzaville", lonlat: [15.3, -4.3], kind: "capital", label: { text: "Kinshasa · Brazzaville", dx: 10, dy: 4, anchor: "start" } },
  { id: "ban", name: "Bangui", lonlat: [18.56, 4.36], kind: "capital", label: { text: "Bangui", dx: 8, dy: 4, anchor: "start" } },
  { id: "kig", name: "Kigali · Gitega", lonlat: [30.06, -1.95], kind: "capital", label: { text: "Kigali · Gitega", dx: -8, dy: 16, anchor: "end" } },
  { id: "dji", name: "Djibouti", lonlat: [43.15, 11.59], kind: "capital", label: { text: "Djibouti", dx: 8, dy: 4, anchor: "start" } },
  { id: "mor", name: "Moroni", lonlat: [43.26, -11.7], kind: "capital", label: { text: "Moroni", dx: 8, dy: 4, anchor: "start" } },
  { id: "tan", name: "Antananarivo", lonlat: [47.5, -18.9], kind: "capital", label: { text: "Antananarivo", dx: -8, dy: 14, anchor: "end" } },
];

/** Liens dorés tracés depuis Alger. */
export const HUB_LINKS = ["rab", "dak", "nia", "lag", "kin", "nai", "add", "joh", "cai"] as const;
/** Liens fins vers les autres capitales francophones. */
export const THIN_LINKS = NODES.filter((n) => n.kind === "capital" && !(HUB_LINKS as readonly string[]).includes(n.id)).map((n) => n.id);
/** Liens entre pays africains (Alger n'est pas le seul centre). */
export const CROSS_LINKS: ReadonlyArray<readonly [string, string]> = [
  ["dak", "abi"], ["abi", "lag"], ["lag", "kin"], ["kin", "joh"], ["nai", "joh"], ["add", "nai"], ["cai", "add"], ["nia", "lag"],
];

/** Contour continental (sans frontières politiques). */
export const AFRICA_OUTLINE: readonly LonLat[] = [
  [-5.9, 35.8], [-2, 35.2], [3, 36.8], [10, 37.3], [11, 33.5], [15, 32.3], [20, 32.5], [22, 32.9], [25, 31.7], [32, 31.2],
  [34, 28], [35, 24], [37, 20], [38.5, 18], [41, 14.5], [43, 12.5], [51, 12], [51, 10.5], [48, 5], [42, -1], [40, -5],
  [39, -10], [40.5, -15], [35, -20], [35.5, -24], [33, -26], [32.5, -28], [30, -31], [27, -33.5], [20, -34.8], [18.4, -34],
  [17, -29], [15, -26], [12, -18], [13.5, -12], [12, -6], [9, -1], [9.5, 3.5], [8, 4.5], [4, 6.3], [1, 6], [-2, 4.8],
  [-7.5, 4.3], [-12, 7.5], [-14.5, 10.5], [-17.2, 14.7], [-16.5, 19], [-16, 21], [-13, 27.5], [-9.8, 31], [-9.5, 33], [-6.8, 34],
];
export const MADAGASCAR_OUTLINE: readonly LonLat[] = [
  [44, -25], [47, -25.2], [49.5, -17], [50.4, -15.5], [49.3, -12], [48, -13.5], [44.3, -16.5], [43.5, -21],
];

/** Points de passage de la route maritime qui contourne l'Afrique par l'extérieur (boucle fermée). */
export const SEA_ROUTE: readonly LonLat[] = [
  [3, 38.4], [-3, 37.6], [-8, 36.2], [-12, 32.5], [-18.5, 26], [-20, 19], [-19.8, 14.7], [-18, 8], [-12, 3.5], [-4, 1.8],
  [4, 1], [8, -3], [9, -10], [10, -18], [11, -26], [15, -34], [20, -37.3], [27, -36], [33, -32], [37.5, -26], [41.5, -18],
  [43.5, -8], [47, -3], [52, 4], [53.3, 10.5], [52, 13.5], [46, 13.8], [43, 13], [40, 17.5], [37, 22], [34.5, 27], [32.8, 30],
  [31, 32.8], [25, 34.3], [18, 34.6], [12, 36.6], [9, 38.5], [5, 38.8],
];
