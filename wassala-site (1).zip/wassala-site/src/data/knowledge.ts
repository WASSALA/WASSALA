/**
 * Base de connaissances de l'assistant WASSALA.
 * - Sans clé API : l'assistant y cherche la meilleure réponse (mots-clés pondérés).
 * - Avec une clé API Claude : ces fiches sont la seule source autorisée ; le modèle reformule sans rien inventer.
 * Règle éditoriale : aucun chiffre, date ou partenaire non sourcé. Ce qui manque reste « [à préciser] ».
 */
export interface KnowledgeEntry {
  id: string;
  /** Formulation de la question, affichée comme suggestion. */
  question: string;
  /** Mots-clés sans accents, en minuscules. Un mot-clé peut être une racine (« sequest » couvre séquestre). */
  keywords: readonly string[];
  answer: string;
  links?: ReadonlyArray<{ label: string; href: string }>;
  /** Pages où la question est suggérée (préfixes de chemin). */
  routes?: readonly string[];
}

export const KNOWLEDGE: readonly KnowledgeEntry[] = [
  {
    id: "wassala",
    question: "Qu’est-ce que WASSALA ?",
    keywords: ["wassala", "agence", "qui etes", "qui est", "presentation", "c'est quoi", "cooperation"],
    answer:
      "WASSALA est une agence de coopération à portée panafricaine basée à Alger. Elle stimule la coopération en Afrique à travers les **flux commerciaux** entre l’Algérie et le reste du continent.\n\nSon rôle : **transformer** des entrepreneurs en opérateurs économiques de leur continent, **relier** les projets aux investisseurs africains et **accompagner** ceux qui sont prêts.",
    links: [{ label: "L’agence", href: "/#agence" }],
    routes: ["/"],
  },
  {
    id: "nom",
    question: "Que signifie « Wassala » ?",
    keywords: ["signifie", "signification", "nom", "veut dire", "sens", "lien", "arabe", "وصلة"],
    answer:
      "Wassala (وصلة) signifie **un lien** en langue arabe. C’est donc une agence dont l’objectif premier est de créer du lien : elle transforme de simples entrepreneurs en véritables opérateurs économiques de développement pour leur continent.",
  },
  {
    id: "objectif",
    question: "Quel est votre objectif ?",
    keywords: ["objectif", "mission", "vision", "pourquoi", "but", "ambition", "panafrican"],
    answer:
      "Atteindre un niveau de développement conséquent de l’Afrique pour affirmer notre dignité et nos convictions dans le monde. Nous croyons que l’union fait la force : le partage de connaissance, de ressources et d’une vision commune permettra à l’Afrique de s’inscrire comme un acteur à part entière de l’évolution du monde ces prochaines décennies.",
    links: [{ label: "Pourquoi WASSALA", href: "/#agence" }],
  },
  {
    id: "financement",
    question: "WASSALA finance-t-elle les projets ?",
    keywords: ["financ", "pret", "credit", "subvention", "argent", "capital", "levee", "investit"],
    answer:
      "Non. WASSALA **accompagne** ceux qui sont prêts et **relie** les projets aux investisseurs africains : ce sont les investisseurs qui décident et financent. Dans SANAD, les fonds d’une transaction sont déposés chez une banque partenaire ou un agent séquestre régulé : WASSALA ne détient jamais les fonds.",
    links: [
      { label: "Projets continentaux", href: "/projets-continentaux#investissement" },
      { label: "AMANA", href: "/sanad#amana" },
    ],
  },
  {
    id: "zlecaf",
    question: "Quel est votre périmètre ?",
    keywords: ["zlecaf", "afcfta", "perimetre", "zone", "libre-echange", "libre echange", "frontalier", "portuaire", "port", "pays couverts", "quels pays", "ou intervenez"],
    answer:
      "WASSALA agit dans le périmètre de la **ZLECAf**, la Zone de libre-échange continentale africaine (plus de 1,3 milliard de consommateurs). Deux types de territoires sont ciblés : les **pays de zone frontalière** (commerce terrestre rapide, chaînes courtes) et les **capitales portuaires** (import-export, banques, assurances, stockage).\n\nHors de ce périmètre, WASSALA ne s’engage pas : les règles d’origine, les tarifs préférentiels et les mécanismes de règlement doivent être connus et opposables.",
    links: [{ label: "Notre périmètre", href: "/#perimetre" }],
  },
  {
    id: "sanad",
    question: "Qu’est-ce que SANAD ?",
    keywords: ["sanad", "سند", "finder", "fee", "service", "mise en relation", "intermediation"],
    answer:
      "SANAD est le service **Finder’s Fee** de WASSALA. Il conduit une transaction commerciale entre deux inconnus africains, **de l’introduction jusqu’au paiement**, et ne se rémunère que si elle arrive à son terme.\n\nSix mécanismes la rendent traçable : le Fil, SILSILA, AMANA, CHAHID, MUQASSA et DAMAN.",
    links: [
      { label: "Découvrir SANAD", href: "/sanad" },
      { label: "Les six mécanismes", href: "/sanad#mecanismes" },
    ],
    routes: ["/", "/sanad"],
  },
  {
    id: "commission",
    question: "Combien coûte SANAD ?",
    keywords: ["combien", "cout", "coute", "prix", "tarif", "commission", "frais", "remuner", "pourcentage", "%"],
    answer:
      "SANAD ne se rémunère que si la transaction aboutit. Une commission de **3 à 5 % de la valeur confirmée** est répartie selon une règle fixée à l’avance entre l’apporteur, l’agent local, les témoins, le fonds de garantie DAMAN et WASSALA.\n\nExemple illustratif : 60 000 $ à 4 % = 2 400 $ de commission, dont environ 660 $ pour WASSALA (≈ 1,1 % de la valeur). [Règle de répartition à confirmer.]",
    links: [{ label: "Simuler la répartition", href: "/sanad#simulateur" }],
    routes: ["/sanad"],
  },
  {
    id: "fil",
    question: "Qu’est-ce que le Fil ?",
    keywords: ["le fil", "fil", "conversation", "horodat", "registre", "proforma", "contrat-type", "trilingue"],
    answer:
      "Chaque transaction ouvre un **fil numéroté** avec les parties, un témoin et un assistant trilingue (français, arabe, anglais). Il génère la facture proforma, le contrat-type et la liste des pièces. Chaque message, photo et document est horodaté dans un registre.\n\nUne fois la négociation engagée, l’IA en tire le **récapitulatif d’accord SANAD**.",
    links: [{ label: "Le Fil", href: "/sanad#fil" }],
  },
  {
    id: "recapitulatif",
    question: "Qu’est-ce que le récapitulatif d’accord SANAD ?",
    keywords: ["recapitulatif", "recap", "mandat", "contrat de vente", "termes convenus", "ne vaut pas facture"],
    answer:
      "Une fois la négociation engagée, l’IA relit le Fil et rassemble les **termes convenus** entre l’acheteur et le vendeur : produit, quantité, prix, incoterm, délai, code SH, paiement. Chaque terme renvoie au message d’où il vient ; ce qui n’a pas été écrit reste à compléter, rien n’est inventé.\n\nC’est un **document interne SANAD** : il fixe la base de la commission, les tranches AMANA et les missions CHAHID. Il est validé par un agent puis soumis aux parties. **Il ne vaut ni facture, ni contrat de vente** : ceux-ci restent établis par les parties.\n\nEn amont, chaque partie accepte le **mandat SANAD** avant d’être présentée à l’autre. [Texte du mandat à valider par un juriste.]",
    links: [{ label: "Voir un exemple", href: "/app/transactions/tx-001#accord-title" }],
  },
  {
    id: "silsila",
    question: "Qu’est-ce que SILSILA ?",
    keywords: ["silsila", "chaine", "apporteur", "contournement", "introduction"],
    answer:
      "SILSILA est **la chaîne des apporteurs** : chaque introduction est enregistrée. La commission (3 à 5 % de la valeur confirmée) est répartie selon une règle fixée à l’avance. Le contournement n’est pas interdit : il est rendu peu rentable, car garantie, séquestre, financement et réputation ne sont accessibles que dans le circuit.",
    links: [{ label: "SILSILA", href: "/sanad#silsila" }],
  },
  {
    id: "amana",
    question: "Comment fonctionne AMANA ?",
    keywords: ["amana", "sequest", "escrow", "fonds", "paiement", "payer", "tranche", "banque", "deblocage", "securis"],
    answer:
      "AMANA est **le séquestre à étapes**. L’acheteur dépose les fonds chez une banque partenaire ou un agent séquestre régulé. Ils sont débloqués par tranches liées à des événements constatés par un témoin :\n- **30 %** à l’inspection\n- **40 %** au chargement ou au passage de la frontière\n- **30 %** à la réception\n\nWASSALA ne détient jamais les fonds.",
    links: [{ label: "AMANA", href: "/sanad#amana" }],
    routes: ["/sanad", "/app"],
  },
  {
    id: "chahid",
    question: "Qui sont les témoins CHAHID ?",
    keywords: ["chahid", "temoin", "inspect", "constat", "huissier", "laboratoire", "transitaire", "preuve"],
    answer:
      "CHAHID est **le témoin local certifié** : inspecteurs, transitaires, avocats, huissiers, laboratoires, payés à la mission et responsables de leurs constats. Preuves à l’appui (photos géolocalisées, scans, relevés). Un faux constat entraîne l’exclusion.",
    links: [{ label: "CHAHID", href: "/sanad#chahid" }],
  },
  {
    id: "muqassa",
    question: "Qu’est-ce que MUQASSA ?",
    keywords: ["muqassa", "compensation", "devise", "change", "solde net", "netting", "convertib"],
    answer:
      "MUQASSA est **la compensation de flux** : quand un exportateur algérien vend vers un pays et qu’un exportateur de ce pays vend vers l’Algérie, les flux s’annulent en partie et seul le solde net traverse la frontière. C’est un service d’appariement exécuté par des banques agréées, jamais un transfert opéré par WASSALA.",
    links: [{ label: "MUQASSA", href: "/sanad#muqassa" }],
  },
  {
    id: "daman",
    question: "Que couvre DAMAN ?",
    keywords: ["daman", "garantie", "assurance", "tontine", "litige", "perte", "couverture", "risque"],
    answer:
      "Chaque transaction verse **0,3 à 0,5 %** dans un fonds de garantie mutuel. Il couvre une première perte plafonnée à **10 à 20 % de la valeur**, sur les litiges constatés par un témoin.\n\nAu-delà, rien n’est garanti. Cette limite est dite clairement.",
    links: [{ label: "DAMAN", href: "/sanad#daman" }],
    routes: ["/sanad"],
  },
  {
    id: "certificat",
    question: "SANAD délivre-t-il le certificat d’origine ?",
    keywords: ["certificat", "origine", "douane", "douanier", "regle d'origine"],
    answer:
      "Non. Le certificat d’origine ZLECAf est **exigé et vérifié** par le témoin CHAHID, mais sa délivrance appartient aux autorités nationales. SANAD ne délivre jamais le certificat.",
    links: [{ label: "Conformité ZLECAf", href: "/sanad#conformite" }],
    routes: ["/sanad"],
  },
  {
    id: "conformite",
    question: "SANAD est-il conforme à la ZLECAf ?",
    keywords: ["conforme", "conformite", "legal", "juridique", "droit", "code sh", "sh", "concession", "preferentiel", "tarif", "kigali"],
    answer:
      "SANAD ne crée aucun droit propre : il fait appliquer, transaction par transaction, ce que l’accord ZLECAf (signé à Kigali le 21 mars 2018, en vigueur depuis le 30 mai 2019) et le droit douanier algérien prévoient déjà. Avant toute transaction, le fil relève le code SH, la liste de concessions (A, B ou C) de chaque pays et le droit applicable : la transaction est étiquetée « préférentielle » ou « droit commun ».",
    links: [{ label: "Conformité", href: "/sanad#conformite" }],
  },
  {
    id: "passeport",
    question: "Qu’est-ce que le passeport de transaction ?",
    keywords: ["passeport", "reputation", "historique", "carte", "friction", "corridor", "donnees de corridor"],
    answer:
      "SANAD produit deux choses. **Le passeport de transaction** : l’historique des transactions menées à terme, pondéré par la diversité des contreparties, utilisable par les banques partenaires pour ouvrir le financement. **Les cartes de frictions de corridor** : coûts, délais et obstacles réels documentés par les témoins, proposés par abonnement aux institutions, logisticiens et banques.",
    links: [{ label: "Ce que SANAD produit", href: "/sanad#produits" }],
  },
  {
    id: "exportateur",
    question: "Comment devenir exportateur ?",
    keywords: ["devenir exportateur", "exportateur", "exporter", "vendre", "acheteurs", "debouche", "client"],
    answer:
      "Décrivez votre activité et votre besoin dans un **brief** : produit, pays visé, volume, valeur estimée. Un agent SANAD le qualifie, puis la transaction avance par étapes : présentation, rencontre, négociation, accord. Vous êtes payé par tranches, depuis un séquestre bancaire, à chaque étape constatée par un témoin.",
    links: [{ label: "Devenir exportateur", href: "/app/transactions/new?role=exportateur" }],
    routes: ["/", "/sanad"],
  },
  {
    id: "acheteur",
    question: "Comment devenir acheteur ?",
    keywords: ["devenir acheteur", "acheteur", "acheter", "importer", "importateur", "fournisseur", "sourcing"],
    answer:
      "Décrivez ce que vous cherchez dans un **brief** : produit, quantité, pays de livraison, budget. SANAD vous présente des producteurs et industriels algériens. Vos fonds restent en séquestre (AMANA) et ne sont débloqués qu’aux étapes constatées par un témoin CHAHID.",
    links: [{ label: "Devenir acheteur", href: "/app/transactions/new?role=acheteur" }],
    routes: ["/", "/sanad"],
  },
  {
    id: "projets",
    question: "Quels sont les projets continentaux ?",
    keywords: ["projets continentaux", "plateforme", "projets", "ecosysteme", "a venir", "futur"],
    answer:
      "Quatre plateformes, toutes centrées sur l’Afrique et sur l’éthique, en préparation :\n- **Incubation** d’entreprises africaines\n- **Formation** d’excellence\n- **Investissement** dans les projets africains\n- **Placement financier** éthique et constructif\n\nSANAD est le premier service ouvert.",
    links: [{ label: "Projets continentaux", href: "/projets-continentaux" }],
    routes: ["/", "/projets-continentaux"],
  },
  {
    id: "incubation",
    question: "Que propose l’incubation ?",
    keywords: ["incubat", "incubateur", "accompagnement", "lancement", "diagnostic", "fiche pays"],
    answer:
      "La plateforme d’incubation veut transformer des entrepreneurs en véritables opérateurs économiques de développement pour leur continent : diagnostic de l’activité et du terrain, fiche pays et cadre légal, formation entrepreneuriale, accompagnement au lancement. [Calendrier à préciser.]",
    links: [{ label: "Incubation", href: "/projets-continentaux#incubation" }],
    routes: ["/projets-continentaux"],
  },
  {
    id: "formation",
    question: "Proposez-vous des formations ?",
    keywords: ["formation", "former", "cours", "universite", "apprendre", "centre de formation"],
    answer:
      "La plateforme de formation d’excellence est en préparation : des formations courtes et pratiques, et à terme des universités et centres de formation d’excellence africains. [Calendrier à préciser.] Laissez votre email sur la page Projets continentaux pour être prévenu.",
    links: [{ label: "Formation", href: "/projets-continentaux#formation" }],
    routes: ["/projets-continentaux"],
  },
  {
    id: "investissement",
    question: "Comment fonctionnera la plateforme d’investissement ?",
    keywords: ["investissement", "investisseur", "investir", "deal room", "scoring", "kyc", "kyb"],
    answer:
      "Elle reliera les projets aux investisseurs africains et accompagnera ceux qui sont prêts : préparation et score des projets, vérification KYC/KYB, salle de transaction sécurisée, suivi des engagements. WASSALA accompagne ; les investisseurs décident et financent. [Calendrier à préciser.]",
    links: [{ label: "Investissement", href: "/projets-continentaux#investissement" }],
    routes: ["/projets-continentaux"],
  },
  {
    id: "placement",
    question: "Qu’est-ce que le placement éthique ?",
    keywords: ["placement", "epargne", "ethique", "ethical", "rendement", "placer"],
    answer:
      "La plateforme de placement financier éthique et constructif veut orienter l’épargne africaine vers des projets africains de structuration. Son modèle, son cadre réglementaire et sa charte éthique seront publiés avant toute ouverture. [À préciser.]",
    links: [{ label: "Placement éthique", href: "/projets-continentaux#placement" }],
    routes: ["/projets-continentaux"],
  },
  {
    id: "ouverture",
    question: "Quand ouvrent les plateformes ?",
    keywords: ["quand", "date", "ouverture", "calendrier", "bientot", "lancement"],
    answer:
      "SANAD est le premier service ouvert. Les plateformes d’incubation, de formation, d’investissement et de placement financier sont en préparation : leur calendrier sera annoncé. [Calendrier à préciser.] Vous pouvez demander à être prévenu sur la page Projets continentaux.",
    links: [{ label: "Être prévenu", href: "/projets-continentaux#prevenir" }],
    routes: ["/projets-continentaux"],
  },
  {
    id: "alger",
    question: "Pourquoi Alger ?",
    keywords: ["alger", "algerie", "heritage", "histoire", "legitim", "pourquoi alger", "liberation", "1962", "panaf"],
    answer:
      "Depuis 1954, l’Algérie a internationalisé sa lutte, accueilli les mouvements de libération du continent, porté des initiatives continentales et investi dans l’intégration africaine. Membre fondateur de l’OUA, devenue l’Union africaine, elle a constitué un capital de légitimité que WASSALA met au service d’un réseau économique.",
    links: [{ label: "Héritage", href: "/heritage" }],
    routes: ["/heritage"],
  },
  {
    id: "moments",
    question: "Quels sont les grands moments de l’Algérie pour l’Afrique ?",
    keywords: ["moments", "grands moments", "non-alignes", "non alignes", "festival", "transsaharien", "gazoduc", "dette", "mecque des revolutionnaires"],
    answer:
      "La page Héritage en retient sept : Alger « La Mecque des révolutionnaires » (1962-1970), le Festival panafricain (1969), la Conférence des Non-Alignés (1973), la médiation Éthiopie-Érythrée (2000, source à confirmer), l’effacement des dettes de 14 pays (2010-2012), la route transsaharienne et le gazoduc transsaharien.",
    links: [{ label: "Les sept moments", href: "/heritage#moments" }],
    routes: ["/heritage"],
  },
  {
    id: "commerce",
    question: "Quelle est la part du commerce intra-africain ?",
    keywords: ["intra-africain", "intra africain", "commerce", "15", "europe", "chiffre"],
    answer:
      "Le commerce intra-africain représente environ **15 %** du commerce total du continent, contre **60 %** en Europe (chiffre cité à l’ouverture de la 4e Foire du commerce intra-africain, Alger, septembre 2025).",
    links: [{ label: "En chiffres", href: "/heritage#chiffres" }],
    routes: ["/heritage"],
  },
  {
    id: "contact",
    question: "Comment vous contacter ?",
    keywords: ["contact", "joindre", "telephone", "email", "mail", "adresse", "rendez-vous", "parler", "humain", "conseiller"],
    answer:
      "Le plus simple : le formulaire de contact en bas de l’accueil. Une personne de l’équipe vous répond sous [placeholder] jours ouvrés. WASSALA est basée à Alger, Algérie.",
    links: [{ label: "Nous contacter", href: "/#contact" }],
  },
  {
    id: "donnees",
    question: "Que faites-vous de mes données ?",
    keywords: ["donnees", "rgpd", "confidential", "vie privee", "cookie", "personnelles"],
    answer:
      "Les informations envoyées par formulaire servent uniquement à répondre à votre demande ; elles ne sont ni vendues ni cédées. Le site n’utilise qu’un cookie de langue, sans traceur publicitaire. Détails dans les mentions légales.",
    links: [{ label: "Mentions légales", href: "/mentions-legales" }],
  },
  {
    id: "coaching-message",
    question: "Comment préparer mon premier message ?",
    keywords: ["premier message", "message", "presenter", "presentation", "pitch", "aborder", "ecrire"],
    answer:
      "Un premier message efficace tient en cinq lignes :\n- **Qui vous êtes** : société, ville, ce que vous produisez ou achetez.\n- **Ce que vous proposez** : produit, volume, régularité.\n- **Pourquoi lui** : son marché, sa ville, un besoin identifié.\n- **Une preuve** : une référence, une certification, un échantillon disponible.\n- **Une question simple** pour obtenir une réponse.\n\nDans SANAD, ce message passe par le Fil : il est horodaté et l’introduction est enregistrée dans SILSILA.",
    links: [{ label: "Nouveau brief", href: "/app/transactions/new" }],
    routes: ["/app/coaching"],
  },
  {
    id: "coaching-questions",
    question: "Quelles questions poser à un acheteur ?",
    keywords: ["questions", "poser", "qualifier", "acheteur", "besoin", "negocier", "negociation"],
    answer:
      "Pour qualifier un acheteur :\n- Quel volume, à quelle fréquence, pour quel usage ?\n- Quelles normes, quel conditionnement, quel étiquetage ?\n- Quel incoterm et quel lieu de livraison ?\n- Quel délai, et qui décide de l’achat ?\n- Accepte-t-il un séquestre AMANA avec déblocage par tranches ?\n\nNotez les réponses dans le Fil : elles servent à la facture proforma et au contrat-type.",
    routes: ["/app/coaching"],
  },
  {
    id: "coaching-documents",
    question: "Quels documents préparer avant un brief ?",
    keywords: ["documents", "piece", "pieces", "dossier", "preparer", "registre", "fiche technique"],
    answer:
      "Préparez :\n- l’extrait du registre du commerce et l’identité du dirigeant (KYC/KYB) ;\n- la fiche technique du produit et, si possible, des photos ;\n- le code SH s’il est connu ;\n- vos conditions habituelles (incoterm, délais, conditionnement).\n\nLe certificat d’origine ZLECAf sera demandé aux autorités nationales ; il est vérifié par le témoin CHAHID.",
    links: [{ label: "Vérification KYC/KYB", href: "/app/kyc" }],
    routes: ["/app/coaching", "/app/kyc"],
  },
];

/** Suggestions affichées selon la page (les plus spécifiques d'abord). */
export function suggestionsFor(pathname: string, max = 3): KnowledgeEntry[] {
  const scored = KNOWLEDGE.filter((k) => k.routes?.some((r) => (r === "/" ? pathname === "/" : pathname.startsWith(r))));
  const list = scored.length ? scored : KNOWLEDGE.filter((k) => k.routes?.includes("/"));
  return list.slice(0, max);
}

/** Texte compact de toute la base, injecté dans le prompt système du modèle. */
export function knowledgeAsContext(): string {
  return KNOWLEDGE.map((k) => `### ${k.question}\n${k.answer}${k.links?.length ? `\nLiens : ${k.links.map((l) => `${l.label} (${l.href})`).join(", ")}` : ""}`).join("\n\n");
}
