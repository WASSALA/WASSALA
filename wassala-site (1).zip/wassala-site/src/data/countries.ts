/**
 * Les 54 États africains membres des Nations unies, en français, avec quelques variantes d'écriture
 * et leur capitale (ou grande ville portuaire) pour la détection d'intention de l'assistant.
 */
export interface Country {
  name: string;
  aliases: readonly string[];
  cities: readonly string[];
}

export const AFRICAN_COUNTRIES: readonly Country[] = [
  { name: "Afrique du Sud", aliases: ["south africa", "afrique australe"], cities: ["pretoria", "johannesburg", "le cap", "durban"] },
  { name: "Algérie", aliases: ["algerie", "algeria", "dz"], cities: ["alger", "oran", "constantine", "setif", "annaba", "biskra", "bejaia", "tamanrasset"] },
  { name: "Angola", aliases: [], cities: ["luanda"] },
  { name: "Bénin", aliases: ["benin"], cities: ["porto-novo", "porto novo", "cotonou"] },
  { name: "Botswana", aliases: [], cities: ["gaborone"] },
  { name: "Burkina Faso", aliases: ["burkina"], cities: ["ouagadougou", "bobo-dioulasso"] },
  { name: "Burundi", aliases: [], cities: ["gitega", "bujumbura"] },
  { name: "Cabo Verde", aliases: ["cap-vert", "cap vert", "cape verde"], cities: ["praia"] },
  { name: "Cameroun", aliases: ["cameroon"], cities: ["yaounde", "douala"] },
  { name: "Centrafrique", aliases: ["republique centrafricaine", "rca"], cities: ["bangui"] },
  { name: "Comores", aliases: ["comoros"], cities: ["moroni"] },
  { name: "Congo", aliases: ["congo-brazzaville", "congo brazzaville"], cities: ["brazzaville", "pointe-noire"] },
  { name: "Côte d’Ivoire", aliases: ["cote d'ivoire", "cote d’ivoire", "cote divoire", "ivory coast"], cities: ["yamoussoukro", "abidjan", "san-pedro"] },
  { name: "Djibouti", aliases: [], cities: [] },
  { name: "Égypte", aliases: ["egypte", "egypt"], cities: ["le caire", "caire", "alexandrie"] },
  { name: "Érythrée", aliases: ["erythree", "eritrea"], cities: ["asmara"] },
  { name: "Eswatini", aliases: ["swaziland"], cities: ["mbabane"] },
  { name: "Éthiopie", aliases: ["ethiopie", "ethiopia"], cities: ["addis-abeba", "addis abeba", "addis"] },
  { name: "Gabon", aliases: [], cities: ["libreville", "port-gentil"] },
  { name: "Gambie", aliases: ["gambia"], cities: ["banjul"] },
  { name: "Ghana", aliases: [], cities: ["accra", "tema"] },
  { name: "Guinée", aliases: ["guinee", "guinea"], cities: ["conakry"] },
  { name: "Guinée-Bissau", aliases: ["guinee-bissau", "guinee bissau"], cities: ["bissau"] },
  { name: "Guinée équatoriale", aliases: ["guinee equatoriale"], cities: ["malabo"] },
  { name: "Kenya", aliases: [], cities: ["nairobi", "mombasa"] },
  { name: "Lesotho", aliases: [], cities: ["maseru"] },
  { name: "Libéria", aliases: ["liberia"], cities: ["monrovia"] },
  { name: "Libye", aliases: ["libya"], cities: ["tripoli", "benghazi"] },
  { name: "Madagascar", aliases: [], cities: ["antananarivo", "toamasina"] },
  { name: "Malawi", aliases: [], cities: ["lilongwe"] },
  { name: "Mali", aliases: [], cities: ["bamako", "gao"] },
  { name: "Maroc", aliases: ["morocco"], cities: ["rabat", "casablanca", "tanger"] },
  { name: "Maurice", aliases: ["ile maurice", "mauritius"], cities: ["port-louis"] },
  { name: "Mauritanie", aliases: ["mauritania"], cities: ["nouakchott", "nouadhibou"] },
  { name: "Mozambique", aliases: [], cities: ["maputo"] },
  { name: "Namibie", aliases: ["namibia"], cities: ["windhoek"] },
  { name: "Niger", aliases: [], cities: ["niamey", "zinder", "agadez"] },
  { name: "Nigéria", aliases: ["nigeria"], cities: ["abuja", "lagos", "kano"] },
  { name: "Ouganda", aliases: ["uganda"], cities: ["kampala"] },
  { name: "RD Congo", aliases: ["rdc", "republique democratique du congo", "congo-kinshasa", "congo kinshasa", "drc"], cities: ["kinshasa", "lubumbashi"] },
  { name: "Rwanda", aliases: [], cities: ["kigali"] },
  { name: "Sao Tomé-et-Principe", aliases: ["sao tome", "sao tome-et-principe"], cities: [] },
  { name: "Sénégal", aliases: ["senegal"], cities: ["dakar", "thies"] },
  { name: "Seychelles", aliases: [], cities: ["victoria"] },
  { name: "Sierra Leone", aliases: [], cities: ["freetown"] },
  { name: "Somalie", aliases: ["somalia"], cities: ["mogadiscio"] },
  { name: "Soudan", aliases: ["sudan"], cities: ["khartoum", "port-soudan"] },
  { name: "Soudan du Sud", aliases: ["south sudan"], cities: ["djouba", "juba"] },
  { name: "Tanzanie", aliases: ["tanzania"], cities: ["dodoma", "dar es salaam"] },
  { name: "Tchad", aliases: ["chad"], cities: ["n'djamena", "n’djamena", "ndjamena"] },
  { name: "Togo", aliases: [], cities: ["lome"] },
  { name: "Tunisie", aliases: ["tunisia"], cities: ["tunis", "sfax"] },
  { name: "Zambie", aliases: ["zambia"], cities: ["lusaka"] },
  { name: "Zimbabwe", aliases: [], cities: ["harare"] },
];

export const COUNTRY_NAMES: readonly string[] = AFRICAN_COUNTRIES.map((c) => c.name);

/** Liste des formulaires : les 54 pays, puis une option hors Afrique (diaspora, partenaires). */
export const FORM_COUNTRIES = [...COUNTRY_NAMES, "Hors Afrique"] as const;
