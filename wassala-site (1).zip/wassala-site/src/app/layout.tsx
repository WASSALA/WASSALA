import type { Metadata, Viewport } from "next";
import { Toaster } from "sonner";
import { InteractionLayer } from "@/components/motion/InteractionLayer";
import { CommandPalette } from "@/components/shared/CommandPalette";
import { I18nProvider } from "@/lib/i18n/I18nProvider";
import { getLocale } from "@/lib/i18n/server";
import { dirOf } from "@/lib/locale";
import "./fonts.css";
import "./globals.css";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: "WASSALA · Le lien qui construit l’Afrique", template: "%s · WASSALA" },
  description:
    "WASSALA, agence de coopération à portée panafricaine basée à Alger : elle transforme des entrepreneurs en opérateurs économiques de leur continent, relie les projets aux investisseurs africains et accompagne ceux qui sont prêts.",
  applicationName: "WASSALA",
  keywords: ["WASSALA", "SANAD", "ZLECAf", "commerce intra-africain", "Alger", "panafricanisme", "Finder’s Fee", "export Algérie Afrique"],
  openGraph: { type: "website", siteName: "WASSALA", locale: "fr_FR" },
  twitter: { card: "summary_large_image" },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = { themeColor: "#EEF3EA", colorScheme: "light" };

/** Pose la classe `js` avant le premier rendu : les animations d'apparition ne masquent rien sans JavaScript. */
const JS_FLAG = "document.documentElement.classList.add('js')";

/**
 * Racine : la langue est lue dans un cookie pour que `lang` et `dir` soient corrects dès le rendu serveur
 * (pas de clignotement RTL en arabe). Conséquence : les pages sont rendues à la demande.
 */
export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await getLocale();
  return (
    <html lang={locale} dir={dirOf(locale)} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: JS_FLAG }} />
        <link rel="preload" href="/fonts/inter-latin-wght-normal.woff2" as="font" type="font/woff2" crossOrigin="anonymous" />
        <link rel="preload" href="/fonts/fraunces-latin-full-normal.woff2" as="font" type="font/woff2" crossOrigin="anonymous" />
      </head>
      <body>
        <I18nProvider locale={locale}>
          {children}
          <CommandPalette />
          <InteractionLayer />
          <Toaster position="bottom-left" richColors closeButton />
        </I18nProvider>
      </body>
    </html>
  );
}
