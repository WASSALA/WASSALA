import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "WASSALA",
    short_name: "WASSALA",
    description: "Le lien qui construit l’Afrique.",
    start_url: "/",
    display: "standalone",
    background_color: "#EEF3EA",
    theme_color: "#10261B",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
  };
}
