import { NextResponse } from "next/server";
import { briefSchema } from "@/lib/forms/schemas";
import { forwardSubmission } from "@/lib/server/forward";
import { clientKey, rateLimit } from "@/lib/server/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "brief"), 6, 10 * 60_000);
  if (!rl.ok) return NextResponse.json({ ok: false, error: "Trop d’envois." }, { status: 429, headers: { "Retry-After": String(rl.retryAfter) } });
  const parsed = briefSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Brief incomplet.", issues: parsed.error.flatten().fieldErrors }, { status: 400 });
  }
  if (parsed.data.website) return NextResponse.json({ ok: true, reference: "OK" });
  const { website: _w, ...data } = parsed.data;
  const result = await forwardSubmission("brief", data);
  if (!result.ok) return NextResponse.json({ ok: false, error: "Envoi impossible pour le moment." }, { status: 502 });
  return NextResponse.json({ ok: true, reference: result.reference });
}
