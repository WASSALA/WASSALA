import { z } from "zod";
import { COUNTRY_NAMES } from "@/data/countries";
import { detectIntent, type BriefIntent } from "@/lib/ai/intent";
import { ROLES, SECTORS } from "@/lib/forms/schemas";
import { clientKey, rateLimit } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

const body = z.object({ text: z.string().trim().min(3).max(1200) });

/** Réponse attendue du modèle : tous les champs sont facultatifs, rien n'est inventé. */
const extraction = z.object({
  role: z.enum(ROLES).nullable().optional(),
  secteur: z.enum(SECTORS).nullable().optional(),
  produit: z.string().max(120).nullable().optional(),
  paysOrigine: z.string().nullable().optional(),
  paysDestination: z.string().nullable().optional(),
  valeur: z.number().positive().nullable().optional(),
  devise: z.enum(["USD", "EUR", "DZD"]).nullable().optional(),
  quantite: z.string().max(80).nullable().optional(),
});

const country = (c: string | null | undefined) => (c && COUNTRY_NAMES.includes(c) ? c : null);

/**
 * Extraction structurée d'un brief à partir d'une phrase libre.
 * Toujours : heuristique locale (detectIntent). En plus, si une clé Claude est configurée : extraction par le modèle,
 * validée par zod, qui complète l'heuristique sans jamais l'écraser par une valeur invalide.
 */
export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "extract"), 20, 60_000);
  if (!rl.ok) return Response.json({ error: "Trop de requêtes." }, { status: 429 });
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Texte invalide." }, { status: 400 });

  const local = detectIntent(parsed.data.text);
  if (!process.env.ANTHROPIC_API_KEY) return Response.json({ intent: local, mode: "local" });

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ASSISTANT_MODEL || "claude-haiku-5-5",
        max_tokens: 300,
        system: `Tu extrais les informations d’un projet commercial décrit en une phrase, pour pré-remplir un brief. Réponds UNIQUEMENT par un objet JSON avec les clés : role ("exportateur" | "acheteur" | null), secteur (une valeur parmi ${JSON.stringify(SECTORS)} ou null), produit (texte court ou null), paysOrigine et paysDestination (noms exacts parmi ${JSON.stringify(COUNTRY_NAMES)} ou null), valeur (nombre ou null), devise ("USD" | "EUR" | "DZD" | null), quantite (texte court avec unité ou null). Mets null pour toute information absente : n’invente rien.`,
        messages: [{ role: "user", content: parsed.data.text }],
      }),
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as { content?: Array<{ type: string; text?: string }> };
    const text = json.content?.find((c) => c.type === "text")?.text ?? "";
    const match = text.match(/\{[\s\S]*\}/);
    const ai = extraction.safeParse(match ? JSON.parse(match[0]) : null);
    if (!ai.success) return Response.json({ intent: local, mode: "local" });
    const a = ai.data;
    const merged: BriefIntent = {
      role: local.role ?? a.role ?? null,
      secteur: local.secteur ?? a.secteur ?? null,
      produit: local.produit ?? a.produit ?? null,
      paysOrigine: local.paysOrigine ?? country(a.paysOrigine),
      paysDestination: local.paysDestination ?? country(a.paysDestination),
      valeur: local.valeur ?? a.valeur ?? null,
      devise: local.devise ?? a.devise ?? null,
      quantite: local.quantite ?? a.quantite ?? null,
      confidence: local.confidence,
    };
    return Response.json({ intent: merged, mode: "live" });
  } catch (err) {
    console.error("[brief/extract] repli sur l’heuristique locale", err);
    return Response.json({ intent: local, mode: "local" });
  }
}
