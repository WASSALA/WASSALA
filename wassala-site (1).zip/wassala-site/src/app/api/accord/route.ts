import { z } from "zod";
import { MOCK_FIL, getTransaction } from "@/lib/api/mock";
import { TRANSACTION_STATUSES } from "@/lib/api/types";
import { CLAUSES, aiAccordSchema, buildRecap, extractLocal, mergeAi, numberedThread, validConditions } from "@/lib/sanad/accord";
import { clientKey, rateLimit } from "@/lib/server/rate-limit";

export const dynamic = "force-dynamic";

const body = z.object({ id: z.string().trim().min(1).max(40) });

/** Le récapitulatif n'a de sens qu'une fois la négociation engagée dans le Fil. */
const MIN_STEP = TRANSACTION_STATUSES.findIndex((s) => s.id === "negociation");

const SYSTEM = `Tu lis le Fil d’une transaction SANAD (messages numérotés #1, #2…) entre un vendeur et un acheteur, et tu en extrais les termes CONVENUS, pour un récapitulatif interne de WASSALA (ce n’est ni une facture ni un contrat de vente).

Règles :
1. N’extrais que ce qui est écrit dans le Fil. Si un terme n’y figure pas, mets "value": null. N’invente, ne déduis et ne complète rien.
2. Chaque valeur cite les numéros des messages d’où elle vient dans "sources". Si une partie a fait une contre-proposition, retiens la dernière valeur acceptée.
3. Recopie les crochets tels quels (ex. « [à confirmer] ») : ils signalent une information non confirmée.
4. "conditions" : les conditions particulières demandées par une partie (certificats, analyses, normes…), avec leurs sources.

Réponds UNIQUEMENT par un objet JSON :
{"clauses": {${CLAUSES.map((c) => `"${c.id}": {"value": string|null, "sources": number[]}`).join(", ")}}, "conditions": [{"text": string, "sources": number[]}]}

Signification des clés : ${CLAUSES.map((c) => `${c.id} = ${c.label}`).join(" ; ")}.`;

/**
 * Génère le récapitulatif d'accord d'une transaction à partir de son Fil.
 * Toujours : extraction locale déterministe. En plus, si une clé Claude est configurée : extraction par le modèle,
 * validée par zod ; une valeur n'est retenue que si elle cite des messages existants. Les montants SANAD
 * (commission, tranches AMANA) sont calculés par le code, jamais par le modèle.
 */
export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "accord"), 10, 60_000);
  if (!rl.ok) return Response.json({ error: "Trop de requêtes. Réessayez dans une minute." }, { status: 429 });
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Requête invalide." }, { status: 400 });

  // En production : lire la transaction et son Fil depuis la base, après contrôle des droits de l'agent.
  const tx = getTransaction(parsed.data.id);
  if (!tx) return Response.json({ error: "Transaction introuvable." }, { status: 404 });
  if (TRANSACTION_STATUSES.findIndex((s) => s.id === tx.status) < MIN_STEP) {
    return Response.json({ error: "Le récapitulatif est disponible à partir de l’étape Négociation." }, { status: 409 });
  }
  const fil = MOCK_FIL[tx.id] ?? [];
  const local = extractLocal(fil);

  if (!process.env.ANTHROPIC_API_KEY || fil.length === 0) {
    return Response.json(buildRecap(tx, fil, local.clauses, local.conditions, "local"));
  }

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: process.env.ASSISTANT_MODEL || "claude-haiku-5-5",
        max_tokens: 1200,
        system: SYSTEM,
        messages: [{ role: "user", content: `Transaction ${tx.ref} · ${tx.corridor} · ${tx.secteur}\n\nFil :\n${numberedThread(fil)}` }],
      }),
      signal: AbortSignal.timeout(20_000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as { content?: Array<{ type: string; text?: string }> };
    const text = json.content?.find((c) => c.type === "text")?.text ?? "";
    const match = text.match(/\{[\s\S]*\}/);
    const ai = aiAccordSchema.safeParse(match ? JSON.parse(match[0]) : null);
    if (!ai.success) throw new Error("réponse du modèle non conforme");
    const clauses = mergeAi(local.clauses, ai.data, fil.length);
    const aiConditions = validConditions(ai.data.conditions, fil.length);
    return Response.json(buildRecap(tx, fil, clauses, aiConditions.length ? aiConditions : local.conditions, "live"));
  } catch (err) {
    console.error("[accord] repli sur l’extraction locale", err);
    return Response.json(buildRecap(tx, fil, local.clauses, local.conditions, "local"));
  }
}
