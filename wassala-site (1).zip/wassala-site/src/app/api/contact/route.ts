import { NextResponse } from "next/server";
import { contactSchema } from "@/lib/forms/schemas";
import { forwardSubmission } from "@/lib/server/forward";
import { clientKey, rateLimit } from "@/lib/server/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(clientKey(req, "contact"), 5, 10 * 60_000);
  if (!rl.ok) {
    return NextResponse.json({ ok: false, error: "Trop d’envois. Réessayez dans quelques minutes." }, { status: 429, headers: { "Retry-After": String(rl.retryAfter) } });
  }
  const json = await req.json().catch(() => null);
  const parsed = contactSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: "Formulaire invalide.", issues: parsed.error.flatten().fieldErrors }, { status: 400 });
  }
  if (parsed.data.website) return NextResponse.json({ ok: true, reference: "OK" }); // robot : on ne dit rien
  const { website: _w, ...data } = parsed.data;
  const result = await forwardSubmission("contact", data);
  if (!result.ok) return NextResponse.json({ ok: false, error: "Envoi impossible pour le moment. Écrivez-nous directement par email." }, { status: 502 });
  return NextResponse.json({ ok: true, reference: result.reference });
}
