import Link from "next/link";
import { GeometricPattern } from "@/components/shared/GeometricPattern";
import { Logo } from "@/components/shared/Logo";

export default function NotFound() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
      <GeometricPattern />
      <div className="relative">
        <Link href="/" aria-label="WASSALA, accueil" className="mb-14 inline-block">
          <Logo size={40} />
        </Link>
        <p className="font-display text-[clamp(96px,18vw,200px)] leading-none text-gold-read">404</p>
        <h1 className="mb-4 text-4xl">Ce lien n’existe pas.</h1>
        <p className="mx-auto mb-10 max-w-md text-lg text-ink-soft">Ironique, pour une agence dont le nom signifie « le lien ». Reprenons depuis l’accueil.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link href="/" className="btn-primary">
            Retour à l’accueil
          </Link>
          <Link href="/sanad" className="btn-outline">
            Découvrir SANAD
          </Link>
        </div>
      </div>
    </main>
  );
}
