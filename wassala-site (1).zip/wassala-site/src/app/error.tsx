"use client";

import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <main className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
      <p className="eyebrow justify-center">Erreur</p>
      <h1 className="mb-4 text-4xl">Quelque chose s’est mal passé.</h1>
      <p className="mb-8 max-w-md text-ink-soft">La page n’a pas pu s’afficher. Réessayez ; si le problème persiste, écrivez-nous depuis la page de contact.</p>
      <button type="button" onClick={reset} className="btn-primary">
        Réessayer
      </button>
    </main>
  );
}
