import type { Metadata } from "next";
import { HeritageClosing } from "@/components/marketing/heritage/HeritageClosing";
import { HeritageContext } from "@/components/marketing/heritage/HeritageContext";
import { HeritageFigures } from "@/components/marketing/heritage/HeritageFigures";
import { HeritageHero } from "@/components/marketing/heritage/HeritageHero";
import { HeritageJourney } from "@/components/marketing/heritage/HeritageJourney";

export const metadata: Metadata = {
  title: "Héritage · Algérie et panafricanisme",
  description:
    "Un peu d’histoire pour dire pourquoi Alger : depuis 1954, l’Algérie a internationalisé sa lutte, accueilli les mouvements de libération du continent et investi dans l’intégration africaine.",
  alternates: { canonical: "/heritage" },
};

/** Héritage : légitimité d'Alger, puis frise et sept grands moments réunis dans une seule section. */
export default function HeritagePage() {
  return (
    <>
      <HeritageHero />
      <HeritageContext />
      <HeritageJourney />
      <HeritageFigures />
      <HeritageClosing />
    </>
  );
}
