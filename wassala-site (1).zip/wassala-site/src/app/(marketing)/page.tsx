import type { Metadata } from "next";
import { AgencyBlock } from "@/components/marketing/AgencyBlock";
import { Constat } from "@/components/marketing/Constat";
import { ContactForm } from "@/components/marketing/ContactForm";
import { ContinentalProjects } from "@/components/marketing/ContinentalProjects";
import { Hero } from "@/components/marketing/Hero";
import { Promise } from "@/components/marketing/Promise";
import { SANADCondensed } from "@/components/marketing/SANADCondensed";
import { VisionStatement } from "@/components/marketing/VisionStatement";
import { ZLECAfBlock } from "@/components/marketing/ZLECAfBlock";

export const metadata: Metadata = {
  title: { absolute: "WASSALA · Le lien qui construit l’Afrique" },
  description:
    "WASSALA transforme des entrepreneurs en opérateurs économiques de leur continent, relie les projets aux investisseurs africains et accompagne ceux qui sont prêts.",
  alternates: { canonical: "/" },
};

/**
 * Accueil. Ordre validé :
 * Hero → Vision → L'agence (flux commerciaux, objectif, créer du lien) → Périmètre ZLECAf →
 * Le constat (+ devenir exportateur / devenir acheteur) → SANAD en condensé → Projets continentaux → Promesse → Contact.
 * Retirés de l'accueil : la section Héritage, « Du diagnostic au financement », « Trois services, un seul réseau ».
 */
export default function Home() {
  return (
    <>
      <Hero />
      <VisionStatement />
      <AgencyBlock />
      <ZLECAfBlock />
      <Constat />
      <SANADCondensed />
      <ContinentalProjects />
      <Promise />
      <ContactForm />
    </>
  );
}
