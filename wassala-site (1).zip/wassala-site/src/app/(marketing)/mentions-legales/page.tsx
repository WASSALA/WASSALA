import type { Metadata } from "next";
import { Breadcrumb } from "@/components/shared/Breadcrumb";
import { SITE } from "@/data/site";

export const metadata: Metadata = {
  title: "Mentions légales",
  description: "Mentions légales et politique de confidentialité du site WASSALA.",
  alternates: { canonical: "/mentions-legales" },
};

const BLOCKS: ReadonlyArray<{ title: string; items: ReadonlyArray<[string, string]> }> = [
  {
    title: "Éditeur du site",
    items: [
      ["Dénomination", "WASSALA [forme juridique à préciser]"],
      ["Siège", SITE.city + " [adresse complète à préciser]"],
      ["Registre du commerce", "[numéro à préciser]"],
      ["NIF / NIS", "[à préciser]"],
      ["Directeur de la publication", "[nom à préciser]"],
      ["Contact", SITE.email],
    ],
  },
  {
    title: "Hébergement",
    items: [
      ["Hébergeur", "[nom, adresse et téléphone de l’hébergeur à préciser]"],
    ],
  },
];

export default function MentionsLegalesPage() {
  return (
    <section className="py-16 md:py-24">
      <div className="container max-w-3xl">
        <Breadcrumb items={[{ href: "/", label: "Accueil" }, { label: "Mentions légales" }]} />
        <h1 className="mb-10 text-[clamp(38px,5vw,60px)]">Mentions légales</h1>

        {BLOCKS.map((b) => (
          <div key={b.title} className="mb-10">
            <h2 className="mb-4 text-2xl">{b.title}</h2>
            <dl className="divide-y divide-line rounded-xl border border-line bg-card">
              {b.items.map(([k, v]) => (
                <div key={k} className="grid gap-1 px-5 py-3.5 sm:grid-cols-[220px_1fr]">
                  <dt className="font-semibold">{k}</dt>
                  <dd className={v.includes("[") ? "text-gold-text" : "text-ink-soft"}>{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        ))}

        <div className="space-y-5 text-ink-soft">
          <h2 className="text-2xl text-ink">Données personnelles</h2>
          <p>
            Les informations envoyées par les formulaires (contact, brief SANAD, « être prévenu ») servent uniquement à répondre à votre demande
            et à assurer le suivi de votre dossier. Elles ne sont ni vendues ni cédées à des tiers.
          </p>
          <p>
            Vous pouvez demander l’accès, la rectification ou la suppression de vos données à l’adresse {SITE.email}. Le traitement est réalisé
            conformément à la loi algérienne n° 18-07 du 10 juin 2018 relative à la protection des personnes physiques dans le traitement des
            données à caractère personnel. <span className="placeholder-tag">À valider par un juriste</span>
          </p>
          <h2 className="pt-4 text-2xl text-ink">Cookies</h2>
          <p>
            Le site n’utilise qu’un cookie technique, <code className="rounded bg-section px-1.5 py-0.5 text-sm">wassala-locale</code>, qui mémorise la
            langue choisie. Aucun cookie publicitaire ni traceur de mesure d’audience tiers n’est déposé. La conversation avec l’assistant est
            conservée dans l’onglet de votre navigateur (stockage de session) et disparaît à sa fermeture.
          </p>
          <h2 className="pt-4 text-2xl text-ink">Assistant WASSALA</h2>
          <p>
            L’assistant répond à partir des contenus publiés sur ce site. Lorsqu’il est connecté à un modèle d’IA, vos questions sont transmises
            à ce fournisseur pour générer la réponse. Ses réponses sont indicatives et ne constituent ni un conseil juridique, fiscal ou
            financier, ni un engagement contractuel. <span className="placeholder-tag">Fournisseur et conditions à préciser</span>
          </p>
          <h2 className="pt-4 text-2xl text-ink">Propriété intellectuelle</h2>
          <p>
            Le nom WASSALA, le symbole waw et l’ensemble des contenus du site sont la propriété de WASSALA, sauf mention contraire. Toute
            reproduction sans autorisation est interdite.
          </p>
        </div>
      </div>
    </section>
  );
}
