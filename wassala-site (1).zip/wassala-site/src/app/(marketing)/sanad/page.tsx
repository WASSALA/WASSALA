import type { Metadata } from "next";
import { SANADCompliance } from "@/components/marketing/sanad/SANADCompliance";
import { SANADCTA } from "@/components/marketing/sanad/SANADCTA";
import { SANADHero } from "@/components/marketing/sanad/SANADHero";
import { SANADJourney } from "@/components/marketing/sanad/SANADJourney";
import { SANADMechanisms } from "@/components/marketing/sanad/SANADMechanisms";
import { SANADProblem } from "@/components/marketing/sanad/SANADProblem";
import { SANADProducts } from "@/components/marketing/sanad/SANADProducts";
import { SANADSimulator } from "@/components/marketing/sanad/SANADSimulator";
import { SANADStatement } from "@/components/marketing/sanad/SANADStatement";

export const metadata: Metadata = {
  title: "SANAD · Finder’s Fee",
  description:
    "SANAD conduit une transaction commerciale entre deux inconnus africains, de l’introduction jusqu’au paiement, et ne se rémunère que si elle arrive à son terme.",
  alternates: { canonical: "/sanad" },
};

/** SANAD : deuxième page du site, à la place de l'ancienne page « Le projet ». */
export default function SANADPage() {
  return (
    <>
      <SANADHero />
      <SANADStatement />
      <SANADProblem />
      <SANADMechanisms />
      <SANADJourney />
      <SANADSimulator />
      <SANADProducts />
      <SANADCompliance />
      <SANADCTA />
    </>
  );
}
