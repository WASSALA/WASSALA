import { ScrollProgress } from "@/components/motion/ScrollProgress";
import { AIChatWidget } from "@/components/shared/AIChatWidget";
import { Footer } from "@/components/shared/Footer";
import { Navbar } from "@/components/shared/Navbar";
import { TranslationNotice } from "@/components/shared/TranslationNotice";
import { getDictionary } from "@/lib/i18n/server";

/** Pages marketing : / , /sanad , /heritage , /projets-continentaux , /mentions-legales. */
export default async function MarketingLayout({ children }: { children: React.ReactNode }) {
  const { t } = await getDictionary();
  return (
    <>
      <a href="#main" className="skip-link">
        {t.nav.skip}
      </a>
      <ScrollProgress />
      <Navbar />
      <TranslationNotice />
      <main id="main" tabIndex={-1} className="outline-none">
        {children}
      </main>
      <Footer />
      <AIChatWidget />
    </>
  );
}
