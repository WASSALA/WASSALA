import { ArrowRight } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { ContactForm } from "@/components/marketing/ContactForm";
import { PlatformIcon } from "@/components/marketing/PlatformIcon";
import { EcosystemOrbit } from "@/components/marketing/projets/EcosystemOrbit";
import { NotifyForm } from "@/components/marketing/projets/NotifyForm";
import { PlatformDetails } from "@/components/marketing/projets/PlatformDetails";
import { Reveal } from "@/components/motion/Reveal";
import { SplitText } from "@/components/motion/SplitText";
import { Breadcrumb } from "@/components/shared/Breadcrumb";
import { GeometricPattern } from "@/components/shared/GeometricPattern";
import { ETHICS, GOALS, PLATFORMS } from "@/data/platforms";

export const metadata: Metadata = {
  title: "Projets continentaux",
  description:
    "Quatre plateformes centrées sur l’Afrique et sur l’éthique : incubation, formation, investissement et placement financier. En préparation ; SANAD est le premier service ouvert.",
  alternates: { canonical: "/projets-continentaux" },
};

const CHAIN = [{ id: "sanad" as const, label: "SANAD", open: true }, ...PLATFORMS.map((p) => ({ id: p.id, label: p.short, open: false }))];

/** Projets continentaux : remplace les anciens onglets Formation et Investissement. */
export default function ProjetsContinentauxPage() {
  return (
    <>
      {/* Ouverture */}
      <section className="relative overflow-hidden border-b border-gold/60" aria-labelledby="pc-title">
        <GeometricPattern />
        <div className="container relative grid items-center gap-12 pb-20 pt-12 lg:grid-cols-[1.15fr_1fr] lg:pb-24">
          <div>
            <Breadcrumb items={[{ href: "/", label: "Accueil" }, { label: "Projets continentaux" }]} />
            <p className="eyebrow">En préparation</p>
            <h1 id="pc-title" className="mb-7 text-[clamp(42px,6.4vw,82px)] leading-[1.0] tracking-[-0.025em]">
              <SplitText text="Des plateformes centrées sur l’Afrique et sur l’éthique." delay={0.1} accent={["Afrique", "l’éthique"]} accentClassName="italic text-forest" />
            </h1>
            <p className="max-w-2xl animate-rise text-lg text-ink-soft md:text-xl" style={{ animationDelay: ".5s" }}>
              Nous portons beaucoup de projets. Nous savons qu’ils sont ambitieux. Cela ne nous empêche ni d’être lucides, ni d’avancer par
              étapes : Wassala veut bâtir un écosystème d’organes capables de s’auto-alimenter et d’étendre son action à tout le continent.
            </p>
            <div className="mt-9 flex animate-rise flex-wrap gap-3" style={{ animationDelay: ".65s" }}>
              <a href="#incubation" className="btn-primary">
                Découvrir les plateformes
              </a>
              <a href="#prevenir" className="btn-outline">
                Être prévenu
              </a>
            </div>
          </div>
          <div className="mx-auto w-full max-w-[460px] animate-rise" style={{ animationDelay: ".3s" }}>
            <EcosystemOrbit />
          </div>
        </div>
      </section>

      <PlatformDetails />

      {/* Centrés sur l'Afrique */}
      <section className="on-ink relative overflow-hidden bg-ink-section py-24 text-bg md:py-32" aria-labelledby="afrique-title">
        <div className="container grid items-start gap-14 lg:grid-cols-2">
          <div className="lg:sticky lg:top-40">
            <p className="eyebrow">Centrés sur l’Afrique</p>
            <h2 id="afrique-title" className="mb-6 text-[clamp(34px,4.6vw,56px)] text-bg">
              Un rêve panafricain, des objectifs concrets.
            </h2>
            <p className="text-lg text-bg/75">
              Construisons ensemble ce rêve panafricain porté par les grands militants et les chefs d’État de notre continent. L’imagination est
              notre seule limite.
            </p>
          </div>
          <ol className="divide-y divide-line-dark">
            {GOALS.map((g, i) => (
              <Reveal as="li" key={g} index={i} className="flex gap-5 py-6">
                <span className="font-display text-2xl text-gold">0{i + 1}</span>
                <span className="font-display text-[clamp(20px,2vw,26px)] leading-snug text-bg">{g}</span>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Guidés par l'éthique */}
      <section className="py-24 md:py-32" aria-labelledby="ethique-title">
        <div className="container">
          <div className="mb-14 grid gap-6 lg:grid-cols-[1fr_1.1fr] lg:items-end">
            <div>
              <p className="eyebrow">Guidés par l’éthique</p>
              <h2 id="ethique-title" className="text-[clamp(34px,4.6vw,56px)]">
                Guidés par l’éthique.
              </h2>
            </div>
            <p className="text-lg text-ink-soft">
              Trois principes, repris de notre vision, s’appliquent à chacune des plateformes. <span className="placeholder-tag">Charte éthique complète à rédiger</span>
            </p>
          </div>
          <ol className="grid gap-5 md:grid-cols-3">
            {ETHICS.map((e, i) => (
              <Reveal as="li" key={e.n} index={i} className="spotlight card card-lift p-8">
                <p className="mb-8 font-display text-5xl text-gold-read">{e.n}</p>
                <h3 className="mb-3 text-2xl">{e.title}</h3>
                <p className="text-ink-soft">{e.body}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      {/* Enchaînement */}
      <section className="bg-section py-24 md:py-32" aria-labelledby="chaine-title">
        <div className="container">
          <p className="eyebrow">Un écosystème</p>
          <h2 id="chaine-title" className="mb-12 text-[clamp(34px,4.6vw,56px)]">
            Comment elles s’enchaînent.
          </h2>
          <ol className="grid gap-3 md:grid-cols-5">
            {CHAIN.map((c, i) => (
              <Reveal as="li" key={c.id} index={i} className="relative">
                <div className={c.open ? "on-ink flex h-full flex-col items-center gap-3 rounded-xl bg-ink p-6 text-center text-bg" : "card flex h-full flex-col items-center gap-3 p-6 text-center"}>
                  <PlatformIcon kind={c.id} className="h-14 w-14" />
                  <p className="font-semibold">{c.label}</p>
                  <p className={c.open ? "text-xs font-semibold uppercase tracking-[.14em] text-gold" : "text-xs font-semibold uppercase tracking-[.14em] text-gold-text"}>
                    {c.open ? "Ouvert" : "À venir"}
                  </p>
                </div>
                {i < CHAIN.length - 1 ? (
                  <ArrowRight className="absolute -end-3 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 rounded-full bg-bg text-gold-text md:block rtl:-scale-x-100" aria-hidden="true" />
                ) : null}
              </Reveal>
            ))}
          </ol>
          <p className="mt-8 max-w-2xl text-ink-soft">
            Chaque transaction menée à terme avec SANAD construit une réputation. Cette réputation pourra, à terme, ouvrir l’accès aux autres
            plateformes. <span className="placeholder-tag">À confirmer</span>
          </p>
          <Link href="/sanad" className="btn-outline group mt-8">
            Commencer avec SANAD
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
          </Link>
        </div>
      </section>

      <NotifyForm />
      <ContactForm defaultSubject="Projets continentaux" />
    </>
  );
}
