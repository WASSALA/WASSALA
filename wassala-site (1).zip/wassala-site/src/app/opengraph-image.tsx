import { ImageResponse } from "next/og";
import { WAW_PATH, WAW_VIEWBOX } from "@/components/shared/waw-path";

export const alt = "WASSALA · Le lien qui construit l’Afrique";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Image de partage (Open Graph), générée au build. */
export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background: "linear-gradient(135deg, #10261B 0%, #155F3B 100%)",
          color: "#EEF3EA",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
          <svg viewBox={WAW_VIEWBOX} width={76} height={80}>
            <path fill="#E3B65B" fillRule="evenodd" d={WAW_PATH} />
          </svg>
          <span style={{ fontSize: 46, fontWeight: 700, letterSpacing: 2 }}>WASSALA</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <span style={{ fontSize: 76, lineHeight: 1.05, fontWeight: 600 }}>Le lien qui construit l’Afrique.</span>
          <span style={{ fontSize: 30, color: "#E3B65B" }}>Agence de coopération panafricaine · Alger · ZLECAf</span>
        </div>
      </div>
    ),
    size,
  );
}
