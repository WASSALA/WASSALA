import type { Metadata } from "next";
import { SmsBrief, UssdSimulator } from "@/components/app/UssdSimulator";

export const metadata: Metadata = { title: "Mode SMS / USSD" };

export default function OfflinePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Mode SMS / USSD</h1>
        <p className="mt-1 max-w-2xl text-ink-soft">
          Pour les zones à faible connectivité : SANAD reste accessible depuis n’importe quel téléphone, sans données mobiles. Essayez la
          simulation.
        </p>
      </div>
      <div className="grid items-start gap-8 lg:grid-cols-[auto_1fr]">
        <UssdSimulator />
        <div className="space-y-5">
          <SmsBrief />
          <div className="card p-5 text-sm text-ink-soft md:p-6">
            <h2 className="mb-2 font-sans text-base font-semibold text-ink">Comment ça marche</h2>
            <ol className="list-inside list-decimal space-y-1.5">
              <li>Composez le code court, choisissez « Nouveau brief ».</li>
              <li>Répondez à trois questions : secteur, pays, valeur.</li>
              <li>Un agent SANAD vous rappelle pour qualifier la demande.</li>
            </ol>
            <p className="mt-3">
              <span className="placeholder-tag">Démonstration</span> L’intégration réelle passe par un agrégateur USSD/SMS de l’opérateur.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
