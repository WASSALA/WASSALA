import type { Metadata } from "next";
import { TenderWatch } from "@/components/app/TenderWatch";

export const metadata: Metadata = { title: "Veille" };

export default function VeillePage() {
  return <TenderWatch />;
}
