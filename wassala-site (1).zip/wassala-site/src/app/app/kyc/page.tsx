import type { Metadata } from "next";
import { KycWizard } from "@/components/app/KycWizard";

export const metadata: Metadata = { title: "KYC / KYB" };

export default function KycPage() {
  return <KycWizard />;
}
