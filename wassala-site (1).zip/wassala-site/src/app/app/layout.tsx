import type { Metadata } from "next";
import { AppShell } from "@/components/app/AppShell";
import { AIChatWidget } from "@/components/shared/AIChatWidget";

export const metadata: Metadata = {
  title: { default: "Espace SANAD", template: "%s · Espace SANAD" },
  robots: { index: false, follow: false },
};

/** Application SANAD (démonstration). La palette de commandes est montée dans le layout racine. */
export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <AppShell>{children}</AppShell>
      <AIChatWidget />
    </>
  );
}
