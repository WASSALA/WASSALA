import type { Metadata } from "next";
import { EmbassiesDirectory } from "@/components/app/Directory";

export const metadata: Metadata = { title: "Ambassades" };

export default function AmbassadesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Ambassades d’Algérie en Afrique</h1>
        <p className="mt-1 text-ink-soft">
          Légalisation, visas d’affaires, appui commercial. <span className="placeholder-tag">Coordonnées officielles à compléter avant publication</span>
        </p>
      </div>
      <EmbassiesDirectory />
    </div>
  );
}
