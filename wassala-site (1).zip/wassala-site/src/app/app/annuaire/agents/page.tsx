import type { Metadata } from "next";
import { AgentsDirectory } from "@/components/app/Directory";

export const metadata: Metadata = { title: "Agents locaux" };

export default function AgentsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Agents locaux</h1>
        <p className="mt-1 text-ink-soft">
          Inspecteurs, transitaires, avocats, huissiers, laboratoires : les témoins CHAHID du réseau. <span className="placeholder-tag">Données de démonstration</span>
        </p>
      </div>
      <AgentsDirectory />
    </div>
  );
}
