import { Mail, Phone } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { StatusBadge } from "@/components/app/TransactionRow";
import { MOCK_TRANSACTIONS } from "@/lib/api/mock";
import { TRANSACTION_STATUSES } from "@/lib/api/types";
import { formatAmount } from "@/lib/utils";

export const metadata: Metadata = { title: "Deal House" };

const counts = {
  ouverts: MOCK_TRANSACTIONS.length,
  qualifies: MOCK_TRANSACTIONS.filter((t) => TRANSACTION_STATUSES.findIndex((s) => s.id === t.status) >= 1).length,
  accords: MOCK_TRANSACTIONS.filter((t) => t.status === "accord" || t.status === "commission").length,
  abouties: MOCK_TRANSACTIONS.filter((t) => t.status === "commission").length,
};

export default function DealHousePage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Deal House</h1>
        <p className="mt-1 text-ink-soft">Votre chargé de compte et la traçabilité de chaque deal.</p>
      </div>

      <section className="card grid items-center gap-5 p-5 sm:grid-cols-[auto_1fr_auto] md:p-6" aria-label="Chargé de compte">
        <span className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-gold bg-section font-display text-2xl text-gold-read">A</span>
        <div>
          <p className="text-lg font-semibold">[Prénom Nom du chargé de compte]</p>
          <p className="text-sm text-ink-soft">Chargé de compte SANAD · [disponibilités à préciser]</p>
        </div>
        <div className="flex gap-2">
          <Link href="/#contact" className="btn-outline min-h-10 px-4 text-sm">
            <Mail className="h-4 w-4" aria-hidden="true" /> Écrire
          </Link>
          <span className="btn-outline min-h-10 cursor-not-allowed px-4 text-sm opacity-60" aria-disabled="true">
            <Phone className="h-4 w-4" aria-hidden="true" /> Appeler
          </span>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-4" aria-label="Entonnoir">
        {(
          [
            ["Briefs ouverts", counts.ouverts],
            ["Qualifiés", counts.qualifies],
            ["Accords", counts.accords],
            ["Abouties", counts.abouties],
          ] as const
        ).map(([label, n], i) => (
          <div key={label} className="card relative overflow-hidden p-5">
            <p className="font-display text-4xl">{n}</p>
            <p className="mt-1 text-sm text-ink-soft">{label}</p>
            <span className="absolute inset-x-0 bottom-0 h-1 bg-forest" style={{ opacity: 1 - i * 0.2 }} aria-hidden="true" />
          </div>
        ))}
      </section>

      <section aria-labelledby="deals-title">
        <h2 id="deals-title" className="mb-4 font-sans text-lg font-semibold">
          Mes deals
        </h2>
        <ul className="space-y-3">
          {MOCK_TRANSACTIONS.map((tx) => (
            <li key={tx.id} className="card flex flex-wrap items-center justify-between gap-4 p-5">
              <div className="min-w-0">
                <p className="font-mono text-xs text-ink-soft">{tx.ref}</p>
                <p className="font-semibold">
                  {tx.corridor} · {tx.secteur}
                </p>
                <p className="text-sm text-ink-soft">
                  {formatAmount(tx.valeur)} {tx.devise} · {tx.nextAction}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <StatusBadge status={tx.status} />
                <Link href={`/app/transactions/${tx.id}`} className="text-sm font-semibold text-forest hover:underline">
                  Ouvrir →
                </Link>
              </div>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-ink-soft">[Données de démonstration]</p>
      </section>
    </div>
  );
}
