import type { Metadata } from "next";
import { Matching } from "@/components/app/Matching";

export const metadata: Metadata = { title: "Matching et score" };

export default function MatchingPage() {
  return <Matching />;
}
