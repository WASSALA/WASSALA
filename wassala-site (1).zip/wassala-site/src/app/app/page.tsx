import { ArrowRight, BriefcaseBusiness, CircleDollarSign, Gauge, Sparkles, TrendingUp } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { KpiCard } from "@/components/app/KpiCard";
import { TransactionTable } from "@/components/app/TransactionRow";
import { ScoreBadge } from "@/components/shared/ScoreBadge";
import { MOCK_TRANSACTIONS, MOCK_USER } from "@/lib/api/mock";
import { TRANSACTION_STATUSES } from "@/lib/api/types";
import { computeCommission } from "@/lib/sanad/commission";
import { formatAmount } from "@/lib/utils";

export const metadata: Metadata = { title: "Tableau de bord" };

const active = MOCK_TRANSACTIONS.filter((t) => t.status !== "commission");
const valueInProgress = active.reduce((acc, t) => acc + t.valeur, 0);
const potential = active.reduce((acc, t) => acc + computeCommission(t.valeur, t.taux).wassala, 0);
const byStatus = TRANSACTION_STATUSES.map((s) => ({ ...s, count: MOCK_TRANSACTIONS.filter((t) => t.status === s.id).length }));
const maxCount = Math.max(1, ...byStatus.map((s) => s.count));
const focus = MOCK_TRANSACTIONS.find((t) => t.status === "qualification") ?? MOCK_TRANSACTIONS[0]!;

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Espace SANAD</p>
          <h1 className="text-[clamp(30px,4vw,44px)]">Bonjour, {MOCK_USER.nom}.</h1>
          <p className="mt-1 text-ink-soft">
            {MOCK_USER.structure} · {MOCK_USER.pays}
          </p>
        </div>
        <Link href="/app/transactions/new" className="btn-primary">
          Nouveau brief
        </Link>
      </div>

      {/* Suggestion de l'assistant */}
      <section className="on-ink relative overflow-hidden rounded-2xl bg-ink-section p-6 text-bg md:p-8" aria-labelledby="next-action">
        <div className="relative flex flex-wrap items-center justify-between gap-6">
          <div className="max-w-2xl">
            <p className="mb-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[.16em] text-gold">
              <Sparkles className="h-4 w-4" aria-hidden="true" /> Prochaine meilleure action · suggestion de l’assistant
            </p>
            <h2 id="next-action" className="mb-2 font-display text-2xl text-bg md:text-3xl">
              {focus.ref} · {focus.nextAction}
            </h2>
            <p className="text-bg/75">
              Sans code SH, le régime ZLECAf (préférentiel ou droit commun) ne peut pas être déterminé et la qualification reste bloquée.
            </p>
          </div>
          <Link href={`/app/transactions/${focus.id}`} className="btn-gold group">
            Ouvrir la transaction
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
          </Link>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard label="Transactions actives" value={active.length} icon={BriefcaseBusiness} sub={`${MOCK_TRANSACTIONS.length} au total`} />
        <KpiCard label="Valeur en cours" value={`${formatAmount(valueInProgress)} $`} icon={TrendingUp} sub="Somme des transactions actives" />
        <KpiCard label="Commission WASSALA potentielle" value={`${formatAmount(potential)} $`} icon={CircleDollarSign} sub="Si toutes aboutissent · règle illustrative" />
        <div className="card p-5 md:p-6">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm text-ink-soft">Score de préparation</p>
            <Gauge className="h-4 w-4 text-gold-text" aria-hidden="true" />
          </div>
          <ScoreBadge score={MOCK_USER.score_preparation ?? 0} label="Profil" />
          <Link href="/app/matching" className="mt-3 inline-block text-xs font-semibold text-forest hover:underline">
            L’améliorer →
          </Link>
        </div>
      </div>

      <section className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
        <div className="card p-6">
          <h2 className="mb-5 font-sans text-base font-semibold">Pipeline par étape</h2>
          <ul className="space-y-3">
            {byStatus.map((s) => (
              <li key={s.id} className="grid grid-cols-[110px_1fr_24px] items-center gap-3 text-sm">
                <span className="text-ink-soft">{s.label}</span>
                <span className="h-2.5 overflow-hidden rounded-full bg-ink/10">
                  <span
                    className="block h-full origin-left rounded-full bg-forest"
                    style={{ width: `${(s.count / maxCount) * 100}%`, animation: "score-grow 1s cubic-bezier(.2,.7,.2,1) both" }}
                  />
                </span>
                <span className="text-end font-semibold">{s.count}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {(
            [
              ["/app/matching", "Matching et score", "Trouver des contreparties, évaluer sa préparation."],
              ["/app/veille", "Veille", "Appels d’offres africains résumés par l’IA."],
              ["/app/kyc", "KYC / KYB", "Vérifier une entreprise, compléter son profil."],
              ["/app/market-intel", "Market Intelligence", "Corridors actifs, tickets moyens, tendances."],
            ] as const
          ).map(([href, title, body]) => (
            <Link key={href} href={href} className="spotlight card card-lift group block p-5">
              <h3 className="mb-1 flex items-center justify-between font-sans text-base font-semibold">
                {title}
                <ArrowRight className="h-4 w-4 text-ink-soft transition-transform group-hover:translate-x-1 group-hover:text-forest rtl:-scale-x-100" aria-hidden="true" />
              </h3>
              <p className="text-sm text-ink-soft">{body}</p>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-sans text-lg font-semibold">Transactions récentes</h2>
          <Link href="/app/transactions" className="text-sm font-semibold text-forest underline-offset-4 hover:underline">
            Tout voir
          </Link>
        </div>
        <TransactionTable rows={MOCK_TRANSACTIONS.slice(0, 4)} />
      </section>
    </div>
  );
}
