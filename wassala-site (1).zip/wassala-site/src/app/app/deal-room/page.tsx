import type { Metadata } from "next";
import { DealRoom } from "@/components/app/DealRoom";

export const metadata: Metadata = { title: "Deal Room" };

export default function DealRoomPage() {
  return <DealRoom />;
}
