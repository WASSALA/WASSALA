import type { Metadata } from "next";
import { NotificationSettings } from "@/components/app/NotificationSettings";
import { LanguageSwitcher } from "@/components/shared/LanguageSwitcher";
import { MOCK_USER } from "@/lib/api/mock";

export const metadata: Metadata = { title: "Réglages" };

export default function SettingsPage() {
  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="text-[clamp(30px,4vw,44px)]">Réglages</h1>
      <section className="card space-y-4 p-5 md:p-6" aria-labelledby="lang-title">
        <h2 id="lang-title" className="font-sans text-base font-semibold">
          Langue
        </h2>
        <LanguageSwitcher variant="full" className="flex-wrap" />
        <p className="text-sm text-ink-soft">Interface disponible en français, anglais, portugais, arabe et swahili. Contenu détaillé en français ; traductions en cours de relecture.</p>
      </section>
      <NotificationSettings />
      <section className="card p-5 md:p-6" aria-labelledby="account-title">
        <h2 id="account-title" className="mb-4 font-sans text-base font-semibold">
          Compte
        </h2>
        <dl className="divide-y divide-line text-sm">
          {(
            [
              ["Nom", MOCK_USER.nom],
              ["Structure", MOCK_USER.structure],
              ["Pays", MOCK_USER.pays],
              ["Vérification", MOCK_USER.kyc === "verifie" ? "KYC/KYB vérifié" : "À compléter"],
            ] as const
          ).map(([k, v]) => (
            <div key={k} className="flex justify-between gap-4 py-2.5">
              <dt className="text-ink-soft">{k}</dt>
              <dd className="font-semibold">{v}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-3 text-xs text-ink-soft">[Authentification et gestion du compte à brancher sur le backend réel.]</p>
      </section>
    </div>
  );
}
