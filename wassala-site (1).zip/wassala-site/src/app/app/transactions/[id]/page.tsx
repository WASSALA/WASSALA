import { ArrowLeft, FileText, MessageSquare, Settings2, Stamp } from "lucide-react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AccordRecap } from "@/components/app/AccordRecap";
import { EscrowTranches } from "@/components/app/EscrowTranches";
import { StatusBadge } from "@/components/app/TransactionRow";
import { MOCK_FIL, MOCK_MANDATS, getTransaction } from "@/lib/api/mock";
import { TRANSACTION_STATUSES } from "@/lib/api/types";
import { DAMAN_COVER_RANGE, computeCommission } from "@/lib/sanad/commission";
import { cn, formatAmount } from "@/lib/utils";

type Params = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  const tx = getTransaction(id);
  return { title: tx ? `${tx.ref} · Transactions` : "Transaction" };
}

const SILSILA = [
  { label: "Apporteur", key: "apporteur", cls: "bg-forest" },
  { label: "Agent local", key: "agentLocal", cls: "bg-forest/70" },
  { label: "Témoins", key: "temoins", cls: "bg-sea" },
  { label: "Fonds DAMAN", key: "daman", cls: "bg-gold/60" },
  { label: "WASSALA", key: "wassala", cls: "bg-gold" },
] as const;

const KIND_ICON = { message: MessageSquare, document: FileText, system: Settings2 } as const;
const dt = (iso: string) => new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" }).format(new Date(iso));

export default async function TransactionDetailPage({ params }: Params) {
  const { id } = await params;
  const tx = getTransaction(id);
  if (!tx) notFound();
  const c = computeCommission(tx.valeur, tx.taux);
  const step = TRANSACTION_STATUSES.findIndex((s) => s.id === tx.status);
  const fil = MOCK_FIL[tx.id] ?? [];
  const mandat = MOCK_MANDATS[tx.id] ?? { vendeur: null, acheteur: null };
  const day = (d: string) => new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }).format(new Date(d));

  return (
    <div className="space-y-6">
      <Link href="/app/transactions" className="inline-flex min-h-10 items-center gap-2 text-sm text-ink-soft hover:text-forest">
        <ArrowLeft className="h-4 w-4 rtl:-scale-x-100" aria-hidden="true" /> Transactions
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="mb-1 font-mono text-sm text-ink-soft">{tx.ref}</p>
          <h1 className="text-[clamp(26px,3.4vw,38px)]">
            {tx.vendeur} → {tx.acheteur}
          </h1>
          <p className="mt-1 text-ink-soft">
            {tx.corridor} · {tx.secteur} · <b className="text-ink">{formatAmount(tx.valeur)} {tx.devise}</b>
          </p>
        </div>
        <StatusBadge status={tx.status} />
      </div>

      {/* Frise de suivi horizontale */}
      <section className="card p-5 md:p-6" aria-labelledby="suivi-title">
        <h2 id="suivi-title" className="mb-5 font-sans text-base font-semibold">
          Suivi en direct
        </h2>
        <ol className="grid grid-cols-7 gap-1">
          {TRANSACTION_STATUSES.map((s, i) => {
            const done = i < step;
            const current = i === step;
            return (
              <li key={s.id} className="min-w-0">
                <span className={cn("block h-1.5 rounded-full", done ? "bg-forest" : current ? "bg-gold" : "bg-ink/10")} />
                <span className={cn("mt-2 block truncate text-[11px] md:text-xs", current ? "font-semibold text-ink" : "text-ink-soft")} title={s.label}>
                  {s.label}
                </span>
              </li>
            );
          })}
        </ol>
        <p className="mt-4 rounded-md bg-section px-4 py-3 text-sm">
          <b>Prochaine action :</b> {tx.nextAction}
        </p>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-6" aria-labelledby="silsila-title">
          <h2 id="silsila-title" className="mb-1 font-sans text-base font-semibold">
            SILSILA · répartition de la commission
          </h2>
          <p className="mb-5 text-sm text-ink-soft">
            {tx.taux.toLocaleString("fr-FR")} % de {formatAmount(tx.valeur)} {tx.devise} = <b className="text-ink">{formatAmount(c.total)} {tx.devise}</b>
          </p>
          <div className="mb-4 flex h-3 overflow-hidden rounded-full">
            {SILSILA.map((p) => (
              <span key={p.key} className={p.cls} style={{ width: `${(c[p.key] / c.total) * 100}%` }} />
            ))}
          </div>
          <dl className="divide-y divide-line text-sm">
            {SILSILA.map((p) => (
              <div key={p.key} className="flex justify-between py-2">
                <dt className="flex items-center gap-2">
                  <span aria-hidden="true" className={cn("h-2.5 w-2.5 rounded-sm", p.cls)} />
                  {p.label}
                </dt>
                <dd className="font-semibold">
                  {formatAmount(c[p.key])} {tx.devise}
                </dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-xs text-ink-soft">[Répartition illustrative, règle à confirmer]</p>
        </section>

        <section className="card p-6" aria-label="AMANA">
          <EscrowTranches valeur={tx.valeur} devise={tx.devise} initiallyDone={tx.status === "commission" ? 3 : tx.status === "accord" ? 1 : 0} />
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
        <section className="card p-6" aria-labelledby="fil-title">
          <h2 id="fil-title" className="mb-5 font-sans text-base font-semibold">
            Le Fil · journal horodaté
          </h2>
          {fil.length ? (
            <ol className="relative space-y-5 before:absolute before:bottom-2 before:start-[15px] before:top-2 before:w-px before:bg-line">
              {fil.map((e, i) => {
                const Icon = KIND_ICON[e.kind];
                return (
                  <li key={e.at} id={`fil-${i + 1}`} className="fil-item relative flex scroll-mt-24 gap-4 rounded-lg transition-colors duration-500">
                    <span className="relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line bg-bg">
                      <Icon className="h-4 w-4 text-gold-text" aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs text-ink-soft">
                        <span className="font-mono text-gold-text">#{i + 1}</span> · <span className="font-semibold text-ink">{e.actor}</span> · <time dateTime={e.at}>{dt(e.at)}</time>
                      </p>
                      <p className="text-[15px]">{e.text}</p>
                    </div>
                  </li>
                );
              })}
            </ol>
          ) : (
            <p className="text-sm text-ink-soft">Le fil de cette transaction de démonstration est vide.</p>
          )}
        </section>

        <div className="space-y-6">
          <section className="card p-6" aria-labelledby="mandat-title">
            <h2 id="mandat-title" className="mb-2 flex items-center gap-2 font-sans text-base font-semibold">
              <Stamp className="h-4 w-4 text-gold-text" aria-hidden="true" /> Mandat SANAD
            </h2>
            <p className="mb-4 text-sm text-ink-soft">
              Chaque partie accepte le mandat avant d’être présentée à l’autre : il fixe la commission, due uniquement si la transaction aboutit. [Texte du mandat à valider
              par un juriste.]
            </p>
            <ul className="space-y-2 text-sm">
              {(["vendeur", "acheteur"] as const).map((k) => {
                const d = mandat[k];
                return (
                  <li key={k} className="flex items-center justify-between gap-3 border-b border-line pb-2 last:border-0">
                    <span className="capitalize">{k}</span>
                    {d ? <span className="font-semibold text-forest">Accepté le {day(d)}</span> : <span className="text-gold-text">À recueillir avant la présentation</span>}
                  </li>
                );
              })}
            </ul>
          </section>
          <section className="card p-6" aria-labelledby="docs-title">
            <h2 id="docs-title" className="mb-4 font-sans text-base font-semibold">
              Documents · CHAHID
            </h2>
            <ul className="space-y-2 text-sm">
              {["Facture proforma", "Contrat-type", "Certificat d’origine ZLECAf (délivré par les autorités nationales, vérifié par CHAHID)"].map((d) => (
                <li key={d} className="flex gap-3">
                  <FileText className="mt-0.5 h-4 w-4 shrink-0 text-gold-text" aria-hidden="true" />
                  <span>{d}</span>
                </li>
              ))}
            </ul>
            <Link href="/app/deal-room" className="btn-outline mt-5 min-h-10 w-full text-sm">
              Ouvrir la Deal Room
            </Link>
          </section>
          <section className="card border-gold/70 p-6" aria-labelledby="daman-title">
            <h2 id="daman-title" className="mb-2 font-sans text-base font-semibold">
              DAMAN · fonds de garantie
            </h2>
            <p className="text-sm text-ink-soft">
              Contribution : {formatAmount(c.daman)} {tx.devise} (0,4 %, illustratif). Première perte couverte jusqu’à{" "}
              {formatAmount((tx.valeur * DAMAN_COVER_RANGE[0]) / 100)} à {formatAmount((tx.valeur * DAMAN_COVER_RANGE[1]) / 100)} {tx.devise}, sur litige
              constaté par témoin. <strong className="text-ink">Au-delà, rien n’est garanti.</strong>
            </p>
          </section>
        </div>
      </div>

      <AccordRecap
        transactionId={tx.id}
        available={step >= TRANSACTION_STATUSES.findIndex((s) => s.id === "negociation")}
        messageCount={fil.length}
        mandat={mandat}
      />
    </div>
  );
}
