import type { Metadata } from "next";
import { Suspense } from "react";
import { BriefForm } from "@/components/app/BriefForm";

export const metadata: Metadata = { title: "Nouveau brief" };

/** Cible des appels à l'action « Devenir exportateur » / « Devenir acheteur » (paramètre ?role=). */
export default function NewTransactionPage() {
  return (
    <Suspense fallback={<div className="h-96 animate-pulse rounded-2xl bg-section" aria-hidden="true" />}>
      <BriefForm />
    </Suspense>
  );
}
