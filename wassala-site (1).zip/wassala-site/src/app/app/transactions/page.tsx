import type { Metadata } from "next";
import Link from "next/link";
import { TransactionsExplorer } from "@/components/app/TransactionsExplorer";

export const metadata: Metadata = { title: "Transactions" };

export default function TransactionsPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[clamp(30px,4vw,44px)]">Transactions</h1>
          <p className="mt-1 text-ink-soft">Chaque transaction a son fil, ses témoins et son séquestre.</p>
        </div>
        <Link href="/app/transactions/new" className="btn-primary">
          Nouveau brief
        </Link>
      </div>
      <TransactionsExplorer />
    </div>
  );
}
