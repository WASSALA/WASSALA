import type { Metadata } from "next";
import { CoachingChat } from "@/components/app/CoachingChat";

export const metadata: Metadata = { title: "Coaching IA" };

export default function CoachingPage() {
  return <CoachingChat />;
}
