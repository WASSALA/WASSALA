import type { Metadata } from "next";
import { MarketIntel } from "@/components/app/MarketIntel";

export const metadata: Metadata = { title: "Market Intelligence" };

export default function MarketIntelPage() {
  return <MarketIntel />;
}
