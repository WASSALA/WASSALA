export default function Loading() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Chargement">
      <div className="h-10 w-1/3 animate-pulse rounded-md bg-section" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="h-28 animate-pulse rounded-lg bg-section" />
        ))}
      </div>
      <div className="h-72 animate-pulse rounded-lg bg-section" />
    </div>
  );
}
