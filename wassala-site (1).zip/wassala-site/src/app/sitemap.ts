import type { MetadataRoute } from "next";

const BASE = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    { url: `${BASE}/`, lastModified: now, changeFrequency: "monthly", priority: 1 },
    { url: `${BASE}/sanad`, lastModified: now, changeFrequency: "monthly", priority: 0.9 },
    { url: `${BASE}/heritage`, lastModified: now, changeFrequency: "yearly", priority: 0.7 },
    { url: `${BASE}/projets-continentaux`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${BASE}/mentions-legales`, lastModified: now, changeFrequency: "yearly", priority: 0.2 },
  ];
}
