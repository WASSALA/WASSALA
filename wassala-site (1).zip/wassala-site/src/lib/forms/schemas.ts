import { z } from "zod";
import { FORM_COUNTRIES } from "@/data/countries";

/** Schémas partagés entre les formulaires (client) et les routes API (serveur) : une seule source de vérité. */

const countries = FORM_COUNTRIES as unknown as [string, ...string[]];

/** Champ piège : invisible pour un humain, rempli par les robots. Doit rester vide. */
const honeypot = z.string().max(0).optional().or(z.literal(""));

export const CONTACT_SUBJECTS = [
  "Devenir exportateur (SANAD)",
  "Devenir acheteur (SANAD)",
  "Projets continentaux",
  "Partenariat institutionnel",
  "Presse",
  "Autre",
] as const;

export const contactSchema = z.object({
  nom: z.string({ required_error: "Indiquez votre nom." }).trim().min(2, "Indiquez votre nom.").max(120),
  structure: z.string().trim().max(160).optional().or(z.literal("")),
  email: z.string().trim().email("Adresse email invalide.").max(160),
  telephone: z
    .string()
    .trim()
    .max(40)
    .regex(/^[+()\d\s.-]*$/, "Numéro invalide.")
    .optional()
    .or(z.literal("")),
  pays: z.enum(countries, { errorMap: () => ({ message: "Choisissez un pays." }) }),
  objet: z.enum(CONTACT_SUBJECTS, { errorMap: () => ({ message: "Choisissez un objet." }) }),
  message: z.string({ required_error: "Écrivez votre message." }).trim().min(20, "Le message doit faire au moins 20 caractères.").max(3000, "3 000 caractères au maximum."),
  consent: z.literal(true, { errorMap: () => ({ message: "Votre accord est nécessaire pour que nous puissions vous répondre." }) }),
  website: honeypot,
});
export type ContactInput = z.infer<typeof contactSchema>;

export const PLATFORM_IDS = ["incubation", "formation", "investissement", "placement"] as const;

export const notifySchema = z.object({
  email: z.string().trim().email("Adresse email invalide.").max(160),
  platforms: z.array(z.enum(PLATFORM_IDS)).max(4).default([]),
  website: honeypot,
});
export type NotifyInput = z.infer<typeof notifySchema>;

export const ROLES = ["exportateur", "acheteur"] as const;
export type Role = (typeof ROLES)[number];

export const SECTORS = [
  "Agroalimentaire",
  "Matériaux et BTP",
  "Pharmacie et santé",
  "Machinisme agricole",
  "Industrie et équipements",
  "Énergie et solaire",
  "Électroménager et électronique",
  "Textile et cuir",
  "Plastique et emballage",
  "Chimie et engrais",
  "Logistique et services",
  "Autre",
] as const;
export type Sector = (typeof SECTORS)[number];

export const INCOTERMS = ["EXW", "FCA", "FOB", "CFR", "CIF", "CPT", "CIP", "DAP", "DPU", "DDP"] as const;

export const briefSchema = z.object({
  role: z.enum(ROLES),
  entreprise: z.string().trim().min(2, "Indiquez votre société.").max(160),
  ville: z.string().trim().max(120).optional().or(z.literal("")),
  paysOrigine: z.enum(countries, { errorMap: () => ({ message: "Choisissez le pays d’origine." }) }),
  paysDestination: z.enum(countries, { errorMap: () => ({ message: "Choisissez le pays de destination." }) }),
  secteur: z.enum(SECTORS, { errorMap: () => ({ message: "Choisissez un secteur." }) }),
  produit: z.string().trim().min(2, "Décrivez le produit.").max(200),
  codeSH: z
    .string()
    .trim()
    .regex(/^(\d{4}(\.?\d{2}){0,3})?$/, "Code SH : 4 à 10 chiffres.")
    .optional()
    .or(z.literal("")),
  quantite: z.string().trim().max(80).optional().or(z.literal("")),
  valeur: z.coerce.number({ invalid_type_error: "Indiquez une valeur." }).positive("La valeur doit être positive.").max(1_000_000_000),
  incoterm: z.enum(INCOTERMS).optional().or(z.literal("")),
  delai: z.string().trim().max(80).optional().or(z.literal("")),
  email: z.string().trim().email("Adresse email invalide.").max(160),
  telephone: z.string().trim().max(40).optional().or(z.literal("")),
  description: z.string().trim().min(20, "Au moins 20 caractères.").max(3000),
  consent: z.literal(true, { errorMap: () => ({ message: "Votre accord est nécessaire." }) }),
  website: honeypot,
});
export type BriefInput = z.infer<typeof briefSchema>;
