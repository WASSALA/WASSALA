import "server-only";

/**
 * Transmet un envoi de formulaire validé au webhook configuré (FORMS_WEBHOOK_URL) :
 * Make, Zapier, n8n, CRM… Sans webhook, l'envoi est seulement journalisé (développement).
 */
export async function forwardSubmission(kind: "contact" | "notify" | "brief", payload: Record<string, unknown>): Promise<{ ok: boolean; reference: string }> {
  const reference = `${kind.toUpperCase()}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  const body = { kind, reference, receivedAt: new Date().toISOString(), payload };
  const url = process.env.FORMS_WEBHOOK_URL;
  if (!url) {
    console.info(`[forms] ${kind} reçu (aucun FORMS_WEBHOOK_URL configuré)`, JSON.stringify(body));
    return { ok: true, reference };
  }
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) {
      console.error(`[forms] webhook ${kind} : HTTP ${res.status}`);
      return { ok: false, reference };
    }
    return { ok: true, reference };
  } catch (err) {
    console.error(`[forms] webhook ${kind} : échec`, err);
    return { ok: false, reference };
  }
}
