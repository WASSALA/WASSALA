import { KNOWLEDGE, type KnowledgeEntry } from "@/data/knowledge";
import { normalize } from "@/lib/utils";

const STOP = new Set(["le", "la", "les", "de", "des", "du", "un", "une", "et", "ou", "a", "au", "aux", "en", "est", "ce", "que", "qui", "quoi", "comment", "pour", "par", "sur", "je", "vous", "nous", "il", "elle", "on", "ma", "mon", "mes", "votre", "vos", "d", "l", "s", "y"]);

export interface Hit {
  entry: KnowledgeEntry;
  score: number;
}

/**
 * Recherche par mots-clés pondérés : une expression complète (« devenir exportateur ») pèse plus qu'un mot isolé,
 * et un mot de la question affichée compte un peu. Simple, prévisible, sans dépendance.
 */
export function retrieve(query: string, k = 3): Hit[] {
  const q = ` ${normalize(query).replace(/[^\p{L}\p{N}%'\s-]/gu, " ").replace(/\s+/g, " ")} `;
  const tokens = q.trim().split(" ").filter((t) => t.length > 1 && !STOP.has(t));
  const hits: Hit[] = [];
  for (const entry of KNOWLEDGE) {
    let score = 0;
    for (const kw of entry.keywords) {
      const n = normalize(kw);
      if (n.includes(" ")) {
        if (q.includes(` ${n}`)) score += 3 + n.split(" ").length;
      } else if (n.length <= 3) {
        if (q.includes(` ${n} `) || q.includes(` ${n}?`)) score += 2;
      } else if (tokens.some((t) => t.startsWith(n) || (t.length > 4 && n.startsWith(t)))) {
        score += 2.5;
      }
    }
    const title = normalize(entry.question);
    for (const t of tokens) if (t.length > 3 && title.includes(t)) score += 0.75;
    if (score > 0) hits.push({ entry, score });
  }
  return hits.sort((a, b) => b.score - a.score).slice(0, k);
}

/** Seuil à partir duquel une fiche répond vraiment à la question. */
export const MIN_SCORE = 2.5;
