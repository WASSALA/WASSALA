import type { AssistantAction } from "./local-answer";

/**
 * Protocole de flux de /api/assistant : une ligne JSON par événement (NDJSON).
 *   { t: "meta", mode, actions }  → une fois, en premier
 *   { t: "text", v }              → morceaux de réponse, à concaténer
 *   { t: "done" } | { t: "error", v }
 */
export type AssistantMode = "live" | "local";

export type StreamEvent =
  | { t: "meta"; mode: AssistantMode; actions: AssistantAction[] }
  | { t: "text"; v: string }
  | { t: "done" }
  | { t: "error"; v: string };

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
