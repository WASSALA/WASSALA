"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { AssistantAction } from "./local-answer";
import type { AssistantMode, StreamEvent } from "./protocol";

export interface AssistantMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  actions?: AssistantAction[];
  streaming?: boolean;
  error?: boolean;
}

const uid = () => Math.random().toString(36).slice(2, 10);

function load(key: string | undefined): AssistantMessage[] {
  if (!key) return [];
  try {
    const raw = sessionStorage.getItem(key);
    return raw ? (JSON.parse(raw) as AssistantMessage[]).map((m) => ({ ...m, streaming: false })) : [];
  } catch {
    return [];
  }
}

function save(key: string | undefined, messages: AssistantMessage[]) {
  if (!key) return;
  try {
    sessionStorage.setItem(key, JSON.stringify(messages.slice(-30)));
  } catch {
    /* stockage indisponible : la conversation reste en mémoire */
  }
}

interface Options {
  /** Clé de stockage de session ; absente = conversation non conservée. */
  storageKey?: string;
  pathname: string;
  locale: string;
  /** Contexte ajouté en tête de la première question (ex. « coaching »). */
  context?: string;
}

/**
 * Conversation avec /api/assistant : envoi, lecture du flux NDJSON, arrêt, réinitialisation.
 * Partagé par le panneau flottant et la page de coaching.
 */
export function useAssistant({ storageKey, pathname, locale, context }: Options) {
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<AssistantMode | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const messagesRef = useRef<AssistantMessage[]>([]);

  useEffect(() => {
    const initial = load(storageKey);
    setMessages(initial);
    messagesRef.current = initial;
  }, [storageKey]);

  useEffect(() => {
    messagesRef.current = messages;
    if (!messages.some((m) => m.streaming)) save(storageKey, messages);
  }, [messages, storageKey]);

  const loadMode = useCallback(() => {
    if (mode) return;
    fetch("/api/assistant")
      .then((r) => r.json() as Promise<{ mode: AssistantMode }>)
      .then((d) => setMode(d.mode))
      .catch(() => setMode("local"));
  }, [mode]);

  const patch = (id: string, fn: (m: AssistantMessage) => AssistantMessage) => setMessages((list) => list.map((m) => (m.id === id ? fn(m) : m)));

  const ask = useCallback(
    async (question: string) => {
      const q = question.trim();
      if (!q || abortRef.current) return;
      const user: AssistantMessage = { id: uid(), role: "user", content: q };
      const reply: AssistantMessage = { id: uid(), role: "assistant", content: "", streaming: true };
      const prior = messagesRef.current.filter((m) => !m.error && m.content).map(({ role, content }) => ({ role, content }));
      const firstContent = prior.length === 0 && context ? `${context}\n\n${q}` : q;
      const history = [...prior, { role: "user" as const, content: firstContent }].slice(-10);
      setMessages((list) => [...list, user, reply]);
      setBusy(true);
      const controller = new AbortController();
      abortRef.current = controller;
      try {
        const res = await fetch("/api/assistant", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ messages: history, pathname, locale }),
          signal: controller.signal,
        });
        if (!res.ok || !res.body) {
          const err = (await res.json().catch(() => ({}))) as { error?: string };
          throw new Error(err.error ?? "L’assistant est indisponible pour le moment.");
        }
        const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
        let buffer = "";
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += value;
          let nl: number;
          while ((nl = buffer.indexOf("\n")) >= 0) {
            const line = buffer.slice(0, nl);
            buffer = buffer.slice(nl + 1);
            if (!line.trim()) continue;
            const evt = JSON.parse(line) as StreamEvent;
            if (evt.t === "meta") {
              setMode(evt.mode);
              patch(reply.id, (m) => ({ ...m, actions: evt.actions }));
            } else if (evt.t === "text") {
              patch(reply.id, (m) => ({ ...m, content: m.content + evt.v }));
            } else if (evt.t === "error") {
              patch(reply.id, (m) => ({ ...m, content: m.content || evt.v, error: !m.content }));
            }
          }
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          patch(reply.id, (m) => ({ ...m, content: (err as Error).message, error: true }));
        }
      } finally {
        patch(reply.id, (m) => ({ ...m, streaming: false }));
        setBusy(false);
        abortRef.current = null;
      }
    },
    [context, locale, pathname],
  );

  const stop = useCallback(() => abortRef.current?.abort(), []);
  const reset = useCallback(() => {
    abortRef.current?.abort();
    setMessages([]);
  }, []);

  return { messages, busy, mode, ask, stop, reset, loadMode };
}
