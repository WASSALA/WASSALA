import { briefHref, describeIntent, isBriefIntent, type BriefIntent } from "./intent";
import { MIN_SCORE, type Hit } from "./retrieve";

export interface AssistantAction {
  label: string;
  href: string;
  primary?: boolean;
}

export const FALLBACK_ANSWER =
  "Je n’ai pas d’information fiable sur ce point. Je réponds sur WASSALA, SANAD et ses six mécanismes, le périmètre ZLECAf, l’héritage d’Alger et les projets continentaux. Pour toute autre question, l’équipe vous répond via le formulaire de contact.";

/** Actions proposées sous la réponse : brief pré-rempli si un projet est détecté, puis les liens des fiches. */
export function actionsFor(intent: BriefIntent, hits: Hit[], text: string): AssistantAction[] {
  const actions: AssistantAction[] = [];
  if (isBriefIntent(intent)) {
    actions.push({ label: `Préparer mon brief · ${describeIntent(intent)}`, href: briefHref(intent, text), primary: true });
  }
  for (const h of hits.filter((h) => h.score >= MIN_SCORE).slice(0, 2)) {
    for (const l of h.entry.links ?? []) {
      if (!actions.some((a) => a.href === l.href) && actions.length < 3) actions.push({ label: l.label, href: l.href });
    }
  }
  if (actions.length === 0 && hits.every((h) => h.score < MIN_SCORE)) actions.push({ label: "Nous contacter", href: "/#contact" });
  return actions;
}

/** Réponse sans modèle de langage : fiche la plus proche, ou réponse orientée brief si un projet est décrit. */
export function localAnswer(intent: BriefIntent, hits: Hit[]): string {
  const best = hits[0];
  const strongKb = best && best.score >= MIN_SCORE;
  if (isBriefIntent(intent) && (!strongKb || intent.confidence >= 0.6)) {
    const who = intent.role === "acheteur" ? "acheter" : intent.role === "exportateur" ? "exporter" : "conclure une transaction";
    const what = intent.produit ?? intent.secteur?.toLowerCase() ?? "vos produits";
    const where = intent.paysDestination ? ` (${intent.paysOrigine ?? "Algérie"} → ${intent.paysDestination})` : "";
    const lines = [
      `Vous souhaitez ${who} : **${what}**${where}. C’est exactement ce que SANAD conduit, de l’introduction jusqu’au paiement, avec une rémunération seulement si la transaction aboutit.`,
      intent.role === "acheteur"
        ? "Vos fonds resteront en séquestre chez une banque partenaire (AMANA) et ne seront débloqués qu’aux étapes constatées par un témoin CHAHID."
        : "Vous serez payé par tranches depuis un séquestre bancaire (AMANA) : 30 % à l’inspection, 40 % au chargement, 30 % à la réception.",
      "J’ai préparé votre brief avec ce que j’ai compris : vérifiez et complétez les champs, un agent prend ensuite le relais.",
    ];
    return lines.join("\n\n");
  }
  if (strongKb) return best.entry.answer;
  return FALLBACK_ANSWER;
}
