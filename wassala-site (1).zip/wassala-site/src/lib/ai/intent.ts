import { AFRICAN_COUNTRIES } from "@/data/countries";
import { SECTORS, type Role, type Sector } from "@/lib/forms/schemas";
import { normalize } from "@/lib/utils";

/**
 * Détection d'intention, sans IA externe : à partir d'une phrase libre (« J'exporte des dattes vers le Sénégal »),
 * on déduit le rôle, le secteur, le produit, les pays, la valeur et la quantité pour pré-remplir un brief SANAD.
 * Déterministe, instantané, testable (tests/unit/intent.test.ts). L'API Claude, si elle est configurée, vient en plus.
 */
export interface BriefIntent {
  role: Role | null;
  secteur: Sector | null;
  produit: string | null;
  paysOrigine: string | null;
  paysDestination: string | null;
  valeur: number | null;
  devise: "USD" | "EUR" | "DZD" | null;
  quantite: string | null;
  /** 0 à 1 : part des informations utiles trouvées. */
  confidence: number;
}

const SECTOR_KEYWORDS: ReadonlyArray<[Sector, readonly string[]]> = [
  ["Machinisme agricole", ["tracteur", "moissonneuse", "machine agricole", "machines agricoles", "materiel agricole", "irrigation", "motoculteur"]],
  ["Agroalimentaire", ["datte", "huile", "olive", "cereale", "ble", "farine", "semoule", "sucre", "lait", "fromage", "fruit", "legume", "conserve", "tomate", "pate", "couscous", "boisson", "jus", "eau minerale", "biscuit", "chocolat", "cafe", "epice", "miel", "viande", "poisson", "agroalimentaire", "alimentaire", "agro"]],
  ["Matériaux et BTP", ["ciment", "clinker", "beton", "acier", "rond a beton", "fer", "carrelage", "ceramique", "brique", "platre", "verre", "peinture", "materiaux", "btp", "construction"]],
  ["Pharmacie et santé", ["medicament", "pharmaceutique", "pharma", "generique", "medical", "vaccin", "sante"]],
  ["Énergie et solaire", ["solaire", "panneau", "photovoltaique", "energie", "batterie", "onduleur", "gaz"]],
  ["Électroménager et électronique", ["electromenager", "refrigerateur", "frigo", "climatiseur", "televiseur", "television", "smartphone", "electronique", "cuisiniere"]],
  ["Textile et cuir", ["textile", "tissu", "vetement", "cuir", "chaussure", "coton"]],
  ["Plastique et emballage", ["plastique", "emballage", "carton", "polyethylene", "bouteille"]],
  ["Chimie et engrais", ["engrais", "uree", "ammoniac", "phosphate", "chimique", "detergent"]],
  ["Industrie et équipements", ["equipement", "piece detachee", "pieces detachees", "moteur", "cable", "transformateur", "pompe", "industriel", "machine"]],
  ["Logistique et services", ["logistique", "fret", "transitaire", "entreposage", "stockage", "transport"]],
];

const EXPORT_SEEKING = /cherch\w*\s+(?:des\s+|un\s+|une\s+|de\s+nouveaux\s+)?(?:acheteur|client|debouche|importateur|distributeur)/;
const IMPORT_SEEKING = /cherch\w*\s+(?:des\s+|un\s+|une\s+)?(?:fournisseur|producteur|fabricant|usine)/;
const EXPORT_VERBS = /\b(export\w*|vend(?:s|re|ons|ez)?|ecoul\w*|je produis|nous produisons|producteur|fabricant|on fabrique|nous fabriquons)\b/;
const IMPORT_VERBS = /\b(achet\w*|achat|import\w*|sourcing|approvisionn\w*|commander|acquerir|j'ai besoin|nous avons besoin|besoin de)\b/;

const ALGERIA = "Algérie";

interface Mention {
  country: string;
  at: number;
  before: string;
}

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Trouve les pays (et villes) cités, dans l'ordre, sans doublon. Les noms longs passent d'abord (Guinée-Bissau avant Guinée). */
function findCountries(text: string): Mention[] {
  const terms: Array<{ term: string; country: string }> = [];
  for (const c of AFRICAN_COUNTRIES) {
    for (const t of [c.name, ...c.aliases, ...c.cities]) terms.push({ term: normalize(t), country: c.name });
  }
  terms.sort((a, b) => b.term.length - a.term.length);
  let masked = text;
  const found: Mention[] = [];
  for (const { term, country } of terms) {
    const re = new RegExp(`(^|[^a-z])(${escapeRe(term)})(?=$|[^a-z])`, "g");
    let m: RegExpExecArray | null;
    while ((m = re.exec(masked))) {
      const at = m.index + m[1]!.length;
      found.push({ country, at, before: masked.slice(Math.max(0, at - 22), at) });
      masked = masked.slice(0, at) + "#".repeat(term.length) + masked.slice(at + term.length);
    }
  }
  found.sort((a, b) => a.at - b.at);
  const seen = new Set<string>();
  return found.filter((f) => (seen.has(f.country) ? false : (seen.add(f.country), true)));
}

const TO_RE = /(vers|pour|a destination d[eu]|destination|livr\w* (?:a|au|en)|au|aux)\s*(?:l'|le |la |les )?\s*$/;
const FROM_RE = /(depuis|de|d'|du|en provenance d[eu]|provenance|origine|fabrique en|produit en|en)\s*(?:l'|le |la |les )?\s*$/;

function parseNumber(raw: string): number | null {
  const cleaned = raw.replace(/[\s  ]/g, "");
  // 1.200.000 ou 1,200,000 (séparateurs de milliers) vs 1,2 (décimale)
  let n: number;
  if (/^\d{1,3}([.,]\d{3})+$/.test(cleaned)) n = Number(cleaned.replace(/[.,]/g, ""));
  else n = Number(cleaned.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

const MULT: Record<string, number> = { k: 1e3, mille: 1e3, millier: 1e3, milliers: 1e3, m: 1e6, million: 1e6, millions: 1e6, md: 1e9, milliard: 1e9, milliards: 1e9 };
const QTY_UNITS = "tonnes?|t|kg|kilos?|conteneurs?|containers?|unites|pieces|palettes|sacs|litres?|m3|cartons|camions";

function findQuantity(text: string): { label: string; span: [number, number] } | null {
  const re = new RegExp(`(\\d[\\d\\s.,\\u00a0\\u202f]*)\\s*(${QTY_UNITS})(?=$|[^a-z])`);
  const m = re.exec(text);
  if (!m) return null;
  const n = parseNumber(m[1]!);
  if (n === null) return null;
  const unit = m[2]!;
  const label = `${new Intl.NumberFormat("fr-FR").format(n).replace(/[\u202f\u00a0]/g, " ")} ${unit === "t" ? "tonnes" : unit}`;
  return { label, span: [m.index, m.index + m[0].length] };
}

function findValue(text: string, skip: [number, number] | null): { value: number; devise: BriefIntent["devise"] } | null {
  const re = /(\d[\d\s.,  ]*)\s*(k|m|md|mille|milliers?|millions?|milliards?)?\s*(\$|usd|dollars?|€|eur|euros?|dzd|da|dinars?)?(?=$|[^a-z])/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (skip && m.index >= skip[0] && m.index < skip[1]) continue;
    const mult = m[2] ? MULT[m[2]] ?? 1 : 1;
    const cur = m[3];
    if (!cur && !m[2]) continue; // un nombre nu n'est pas une valeur (année, quantité…)
    const n = parseNumber(m[1]!);
    if (n === null || n <= 0) continue;
    const devise: BriefIntent["devise"] = !cur || /\$|usd|dollar/.test(cur) ? "USD" : /€|eur/.test(cur) ? "EUR" : "DZD";
    return { value: Math.round(n * mult), devise };
  }
  return null;
}

function findProduct(original: string, norm: string): { secteur: Sector | null; produit: string | null } {
  for (const [sector, words] of SECTOR_KEYWORDS) {
    for (const w of words) {
      const re = new RegExp(`(^|[^a-z])(${escapeRe(w)}[a-z]*)`);
      const m = re.exec(norm);
      if (m) {
        const start = m.index + m[1]!.length;
        // Le texte normalisé garde les longueurs du texte d'origine (accents retirés un à un), on peut donc découper l'original.
        const produit = original.slice(start, start + m[2]!.length);
        const generic = ["agro", "alimentaire", "agroalimentaire", "btp", "construction", "materiaux", "energie", "industriel", "machine", "transport", "logistique", "sante"].includes(w);
        return { secteur: sector, produit: generic ? null : produit };
      }
    }
  }
  return { secteur: null, produit: null };
}

export function detectIntent(text: string): BriefIntent {
  const original = text.normalize("NFC").replace(/[’`]/g, "'");
  const norm = normalize(original);

  let role: Role | null = null;
  if (EXPORT_SEEKING.test(norm)) role = "exportateur";
  else if (IMPORT_SEEKING.test(norm)) role = "acheteur";
  else {
    const ex = norm.search(EXPORT_VERBS);
    const im = norm.search(IMPORT_VERBS);
    if (ex >= 0 && (im < 0 || ex <= im)) role = "exportateur";
    else if (im >= 0) role = "acheteur";
  }

  const { secteur, produit } = findProduct(original, norm);

  let paysOrigine: string | null = null;
  let paysDestination: string | null = null;
  const mentions = findCountries(norm);
  for (const m of mentions) {
    if (TO_RE.test(m.before) && !paysDestination) paysDestination = m.country;
    else if (FROM_RE.test(m.before) && !paysOrigine) paysOrigine = m.country;
  }
  for (const m of mentions) {
    if (m.country === paysOrigine || m.country === paysDestination) continue;
    if (m.country === ALGERIA && !paysOrigine) paysOrigine = ALGERIA;
    else if (!paysDestination && m.country !== ALGERIA) paysDestination = m.country;
    else if (!paysOrigine) paysOrigine = m.country;
  }
  // SANAD relie d'abord des producteurs algériens à des acheteurs du reste de l'Afrique.
  if (!paysOrigine && (role || paysDestination) && paysDestination !== ALGERIA) paysOrigine = ALGERIA;
  if (paysOrigine && paysOrigine === paysDestination) paysDestination = null;

  const qty = findQuantity(norm);
  const val = findValue(norm, qty?.span ?? null);

  const confidence =
    (role ? 0.35 : 0) + (secteur || produit ? 0.25 : 0) + (paysDestination ? 0.25 : 0) + (val ? 0.1 : 0) + (qty ? 0.05 : 0);

  return {
    role,
    secteur,
    produit,
    paysOrigine,
    paysDestination,
    valeur: val?.value ?? null,
    devise: val?.devise ?? null,
    quantite: qty?.label ?? null,
    confidence: Math.round(confidence * 100) / 100,
  };
}

/** Assez d'éléments pour proposer un brief pré-rempli. */
export function isBriefIntent(i: BriefIntent): boolean {
  return (i.role !== null && (i.secteur !== null || i.paysDestination !== null)) || (i.produit !== null && i.paysDestination !== null);
}

/** Lien vers le brief SANAD pré-rempli. */
export function briefHref(i: BriefIntent, sourceText?: string): string {
  const p = new URLSearchParams();
  if (i.role) p.set("role", i.role);
  if (i.secteur) p.set("secteur", i.secteur);
  if (i.produit) p.set("produit", i.produit);
  if (i.paysOrigine) p.set("origine", i.paysOrigine);
  if (i.paysDestination) p.set("destination", i.paysDestination);
  if (i.valeur) p.set("valeur", String(i.valeur));
  if (i.quantite) p.set("quantite", i.quantite);
  if (sourceText) p.set("q", sourceText.slice(0, 300));
  return `/app/transactions/new?${p.toString()}`;
}

/** Résumé lisible : « Exportateur · Dattes · Algérie → Sénégal · 50 000 $ ». */
export function describeIntent(i: BriefIntent): string {
  const parts: string[] = [];
  if (i.role) parts.push(i.role === "exportateur" ? "Exportateur" : "Acheteur");
  if (i.produit) parts.push(i.produit.charAt(0).toUpperCase() + i.produit.slice(1));
  else if (i.secteur) parts.push(i.secteur);
  if (i.paysOrigine || i.paysDestination) parts.push(`${i.paysOrigine ?? "?"} → ${i.paysDestination ?? "?"}`);
  if (i.quantite) parts.push(i.quantite);
  if (i.valeur) parts.push(`${new Intl.NumberFormat("fr-FR").format(i.valeur)} ${i.devise === "EUR" ? "€" : i.devise === "DZD" ? "DA" : "$"}`);
  return parts.join(" · ");
}

export const SECTOR_LIST = SECTORS;
