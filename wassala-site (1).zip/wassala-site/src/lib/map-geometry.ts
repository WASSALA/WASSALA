/**
 * Géométrie pure de la carte de l'Afrique (testable, sans React).
 * Projection équirectangulaire simple : lon −20 → 56, lat −37 → 38,5, dans un viewBox 650 × 640.
 * Aucune frontière politique n'est dessinée : seulement un contour continental.
 */
export type LonLat = readonly [number, number];
export type XY = readonly [number, number];

export const VIEW_W = 650;
export const VIEW_H = 640;

const round = (n: number): number => Math.round(n);

export function project([lon, lat]: LonLat): XY {
  return [(lon + 20) * 8.3 + 8, (38.5 - lat) * 8.3 + 8];
}

export function polygonPath(points: readonly LonLat[]): string {
  return (
    "M" +
    points
      .map((p) => {
        const [x, y] = project(p);
        return `${round(x)} ${round(y)}`;
      })
      .join("L") +
    "Z"
  );
}

/** Courbe quadratique entre deux points, bombée vers le nord. */
export function quadCurve(a: XY, b: XY, bulge = 0.18): string {
  const [x1, y1] = a;
  const [x2, y2] = b;
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  let nx = y2 - y1;
  let ny = -(x2 - x1);
  if (ny > 0) {
    nx = -nx;
    ny = -ny;
  }
  return `M${round(x1)} ${round(y1)}Q${round(mx + nx * bulge)} ${round(my + ny * bulge)} ${round(x2)} ${round(y2)}`;
}

/** Spline de Catmull-Rom fermée, convertie en courbes de Bézier cubiques. */
export function closedSpline(points: readonly XY[]): string {
  const n = points.length;
  const at = (i: number): XY => points[((i % n) + n) % n] as XY;
  const first = at(0);
  let d = `M${round(first[0])} ${round(first[1])}`;
  for (let i = 0; i < n; i++) {
    const p0 = at(i - 1);
    const p1 = at(i);
    const p2 = at(i + 1);
    const p3 = at(i + 2);
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += `C${round(c1x)} ${round(c1y)} ${round(c2x)} ${round(c2y)} ${round(p2[0])} ${round(p2[1])}`;
  }
  return d + "Z";
}
