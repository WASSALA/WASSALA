import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Fusionne des classes Tailwind sans conflit. */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/** Montant formaté à la française, sans décimale : 60 000. */
export function formatAmount(value: number, locale = "fr-FR"): string {
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value);
}

/** Montant avec devise : 60 000 $ / 60 000 USD. */
export function formatMoney(value: number, currency = "USD", locale = "fr-FR"): string {
  const n = formatAmount(value, locale);
  return currency === "USD" ? `${n} $` : `${n} ${currency}`;
}

/** Borne une valeur entre min et max. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Supprime les accents et met en minuscules (recherche tolérante). */
export function normalize(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
}
