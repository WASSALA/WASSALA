export const LOCALES = ["fr", "en", "pt", "ar", "sw"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "fr";
export const LOCALE_COOKIE = "wassala-locale";

export const LOCALE_LABELS: Record<Locale, { short: string; native: string }> = {
  fr: { short: "FR", native: "Français" },
  en: { short: "EN", native: "English" },
  pt: { short: "PT", native: "Português" },
  ar: { short: "عربي", native: "العربية" },
  sw: { short: "SW", native: "Kiswahili" },
};

export function parseLocale(raw: string | undefined | null): Locale {
  return (LOCALES as readonly string[]).includes(raw ?? "") ? (raw as Locale) : DEFAULT_LOCALE;
}

export function dirOf(locale: Locale): "rtl" | "ltr" {
  return locale === "ar" ? "rtl" : "ltr";
}
