/**
 * Types partagés entre le mock et la couche API réelle.
 * Règle : aucun chiffre ni nom inventé. Toute valeur manquante = placeholder string.
 */
export type TransactionStatus =
  | "brief"
  | "qualification"
  | "presentation"
  | "rencontre"
  | "negociation"
  | "accord"
  | "commission";

export const TRANSACTION_STATUSES: ReadonlyArray<{ id: TransactionStatus; label: string }> = [
  { id: "brief",         label: "Brief reçu" },
  { id: "qualification", label: "Qualification" },
  { id: "presentation",  label: "Présentation" },
  { id: "rencontre",     label: "Rencontre" },
  { id: "negociation",   label: "Négociation" },
  { id: "accord",        label: "Accord" },
  { id: "commission",    label: "Commission" },
];

export interface Transaction {
  id: string;
  ref: string;
  vendeur: string;
  acheteur: string;
  corridor: string;
  secteur: string;
  valeur: number;
  devise: string;
  taux: number;
  status: TransactionStatus;
  nextAction: string;
  createdAt: string;
  updatedAt: string;
}

/** Événement du Fil : journal horodaté d'une transaction. */
export interface FilEvent {
  at: string;
  actor: string;
  kind: "message" | "document" | "system";
  text: string;
}

export interface Agent {
  id: string;
  nom: string;
  prenom: string;
  ville: string;
  pays: string;
  specialites: string[];
  verifie: boolean;
}

export interface Ambassade {
  id: string;
  pays: string;
  ville: string;
  adresse: string;
  horaires: string;
  services: string[];
}

export type KYCStatus = "non_commence" | "en_attente" | "verifie" | "rejete";

export interface UserProfile {
  id: string;
  nom: string;
  structure: string;
  secteur: string;
  pays: string;
  ticket_min: number;
  ticket_max: number;
  kyc: KYCStatus;
  score_preparation: number | null;
  transactions: number;
}
