import type { Agent, Ambassade, FilEvent, Transaction, UserProfile } from "./types";

/**
 * Données de DÉMONSTRATION uniquement.
 * Aucune information réelle sur des personnes ou des organisations : chaque nom est un [placeholder].
 * Remplacer par la couche API réelle (voir README, « Brancher un backend »).
 */

export const MOCK_USER: UserProfile = {
  id: "user-demo",
  nom: "[Prénom Nom]",
  structure: "[Structure]",
  secteur: "Agroalimentaire",
  pays: "Algérie",
  ticket_min: 10_000,
  ticket_max: 200_000,
  kyc: "verifie",
  score_preparation: 72,
  transactions: 3,
};

export const MOCK_TRANSACTIONS: readonly Transaction[] = [
  {
    id: "tx-001",
    ref: "TX-2026-0142",
    vendeur: "[Société A, Sétif]",
    acheteur: "[Société B, Nouakchott]",
    corridor: "Algérie → Mauritanie",
    secteur: "Agroalimentaire",
    valeur: 60_000,
    devise: "USD",
    taux: 4,
    status: "negociation",
    nextAction: "Valider la facture proforma",
    createdAt: "2026-09-01",
    updatedAt: "2026-10-22",
  },
  {
    id: "tx-002",
    ref: "TX-2026-0098",
    vendeur: "[Société C, Oran]",
    acheteur: "[Société D, Dakar]",
    corridor: "Algérie → Sénégal",
    secteur: "Industrie et équipements",
    valeur: 120_000,
    devise: "USD",
    taux: 3.5,
    status: "accord",
    nextAction: "Constat CHAHID au chargement",
    createdAt: "2026-07-15",
    updatedAt: "2026-10-19",
  },
  {
    id: "tx-003",
    ref: "TX-2026-0211",
    vendeur: "[Société E, Alger]",
    acheteur: "[Société F, Lagos]",
    corridor: "Algérie → Nigéria",
    secteur: "Pharmacie et santé",
    valeur: 85_000,
    devise: "USD",
    taux: 4,
    status: "presentation",
    nextAction: "Attente du retour de l’acheteur",
    createdAt: "2026-10-05",
    updatedAt: "2026-10-24",
  },
  {
    id: "tx-004",
    ref: "TX-2026-0230",
    vendeur: "[Société G, Biskra]",
    acheteur: "[Société H, Bamako]",
    corridor: "Algérie → Mali",
    secteur: "Agroalimentaire",
    valeur: 32_000,
    devise: "USD",
    taux: 5,
    status: "qualification",
    nextAction: "Compléter le code SH",
    createdAt: "2026-10-18",
    updatedAt: "2026-10-25",
  },
  {
    id: "tx-005",
    ref: "TX-2026-0061",
    vendeur: "[Société I, Annaba]",
    acheteur: "[Société J, Niamey]",
    corridor: "Algérie → Niger",
    secteur: "Matériaux et BTP",
    valeur: 210_000,
    devise: "USD",
    taux: 3,
    status: "commission",
    nextAction: "Transaction aboutie",
    createdAt: "2026-05-02",
    updatedAt: "2026-09-30",
  },
];

/** Le Fil : journal horodaté d'une transaction (démonstration). Les messages sont numérotés dans l'ordre (#1, #2…). */
export const MOCK_FIL: Record<string, readonly FilEvent[]> = {
  "tx-001": [
    { at: "2026-09-01T09:12:00Z", actor: "Vendeur", kind: "message", text: "Brief déposé : produits agroalimentaires, 60 000 $." },
    { at: "2026-09-03T14:40:00Z", actor: "Agent SANAD", kind: "system", text: "Brief qualifié. Corridor Algérie → Mauritanie, frontière terrestre." },
    { at: "2026-09-10T10:05:00Z", actor: "Agent SANAD", kind: "system", text: "Introduction enregistrée dans SILSILA." },
    { at: "2026-09-18T16:20:00Z", actor: "Acheteur", kind: "message", text: "Intéressé. Merci de préciser le conditionnement." },
    { at: "2026-09-24T09:30:00Z", actor: "Vendeur", kind: "message", text: "Proposition : 20 tonnes de dattes Deglet Nour, en cartons de 5 kg, à 3 000 $ la tonne, soit 60 000 $. Départ Sétif." },
    { at: "2026-09-26T11:15:00Z", actor: "Acheteur", kind: "message", text: "Prix accepté. Nous souhaitons une livraison CPT Nouakchott sous 45 jours après l’accord." },
    { at: "2026-09-28T08:50:00Z", actor: "Vendeur", kind: "message", text: "D’accord pour CPT Nouakchott sous 45 jours. Paiement par séquestre AMANA, en trois tranches." },
    { at: "2026-10-02T11:00:00Z", actor: "Témoin CHAHID", kind: "document", text: "Fiche technique et échantillon vérifiés (photos géolocalisées)." },
    { at: "2026-10-10T15:05:00Z", actor: "Assistant", kind: "system", text: "Code SH relevé : 0804.10 (dattes). Régime ZLECAf : [à confirmer selon la liste de concessions de la Mauritanie]." },
    { at: "2026-10-22T08:30:00Z", actor: "Assistant", kind: "system", text: "Facture proforma générée (FR / AR)." },
    { at: "2026-10-23T10:40:00Z", actor: "Acheteur", kind: "message", text: "Nous demandons un certificat d’analyse du laboratoire avant le chargement." },
  ],
};

/** Mandat SANAD : date d'acceptation par chaque partie, avant sa présentation à l'autre (démonstration). */
export const MOCK_MANDATS: Record<string, { vendeur: string | null; acheteur: string | null }> = {
  "tx-001": { vendeur: "2026-09-03", acheteur: "2026-09-10" },
  "tx-002": { vendeur: "2026-07-16", acheteur: "2026-07-22" },
  "tx-003": { vendeur: "2026-10-06", acheteur: "2026-10-12" },
  "tx-004": { vendeur: "2026-10-19", acheteur: null },
  "tx-005": { vendeur: "2026-05-03", acheteur: "2026-05-11" },
};

export const MOCK_AGENTS: readonly Agent[] = [
  { id: "ag-001", nom: "[Nom]", prenom: "[Prénom]", ville: "Dakar", pays: "Sénégal", specialites: ["Inspection", "Transit"], verifie: true },
  { id: "ag-002", nom: "[Nom]", prenom: "[Prénom]", ville: "Lagos", pays: "Nigéria", specialites: ["Droit", "Huissier"], verifie: true },
  { id: "ag-003", nom: "[Nom]", prenom: "[Prénom]", ville: "Nairobi", pays: "Kenya", specialites: ["Laboratoire", "Qualité"], verifie: true },
  { id: "ag-004", nom: "[Nom]", prenom: "[Prénom]", ville: "Abidjan", pays: "Côte d’Ivoire", specialites: ["Transitaire"], verifie: false },
  { id: "ag-005", nom: "[Nom]", prenom: "[Prénom]", ville: "Nouakchott", pays: "Mauritanie", specialites: ["Inspection", "Transit"], verifie: true },
  { id: "ag-006", nom: "[Nom]", prenom: "[Prénom]", ville: "Niamey", pays: "Niger", specialites: ["Huissier"], verifie: false },
];

export const MOCK_AMBASSADES: readonly Ambassade[] = [
  { id: "amb-001", pays: "Sénégal", ville: "Dakar", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Légalisation", "Visa d’affaires"] },
  { id: "amb-002", pays: "Nigéria", ville: "Abuja", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Chambre de commerce"] },
  { id: "amb-003", pays: "Kenya", ville: "Nairobi", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Légalisation"] },
  { id: "amb-004", pays: "Éthiopie", ville: "Addis-Abeba", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Visa d’affaires", "Transit"] },
  { id: "amb-005", pays: "Mauritanie", ville: "Nouakchott", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Légalisation", "Chambre de commerce"] },
  { id: "amb-006", pays: "Mali", ville: "Bamako", adresse: "[Adresse]", horaires: "[Horaires]", services: ["Légalisation"] },
];

export function getTransaction(id: string): Transaction | undefined {
  return MOCK_TRANSACTIONS.find((t) => t.id === id);
}
