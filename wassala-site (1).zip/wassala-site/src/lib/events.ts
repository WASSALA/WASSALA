/** Événements globaux du navigateur, pour relier des composants indépendants sans état partagé. */
export const OPEN_PALETTE_EVENT = "wassala:open-palette";
export const ASK_ASSISTANT_EVENT = "wassala:ask";

export interface AskAssistantDetail {
  /** Question à poser immédiatement ; vide = ouvrir seulement le panneau. */
  question?: string;
}

export function openPalette(): void {
  window.dispatchEvent(new Event(OPEN_PALETTE_EVENT));
}

export function askAssistant(question?: string): void {
  window.dispatchEvent(new CustomEvent<AskAssistantDetail>(ASK_ASSISTANT_EVENT, { detail: { question } }));
}
