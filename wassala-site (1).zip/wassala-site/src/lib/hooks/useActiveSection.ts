"use client";

import { useEffect, useState } from "react";

/**
 * Renvoie l'identifiant de l'élément le plus proche de la ligne de lecture (45 % de la hauteur d'écran).
 * Plus fiable qu'un IntersectionObserver pour le dernier élément d'une liste, qui n'atteint pas toujours le haut de l'écran.
 */
export function useActiveSection<T extends string>(ids: readonly T[], fallback: T, line = 0.45): T {
  const [active, setActive] = useState<T>(fallback);
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const target = window.innerHeight * line;
      let best: T = fallback;
      let bestDist = Infinity;
      for (const id of ids) {
        const el = document.getElementById(id);
        if (!el) continue;
        const r = el.getBoundingClientRect();
        if (r.bottom < 0 || r.top > window.innerHeight) continue;
        const dist = r.top <= target && r.bottom >= target ? 0 : Math.min(Math.abs(r.top - target), Math.abs(r.bottom - target));
        if (dist < bestDist) {
          bestDist = dist;
          best = id;
        }
      }
      if (bestDist !== Infinity) setActive(best);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(frame);
    };
  }, [ids, fallback, line]);
  return active;
}
