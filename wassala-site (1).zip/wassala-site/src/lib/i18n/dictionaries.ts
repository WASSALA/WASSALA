import type { Locale } from "@/lib/locale";

/**
 * Textes de l'interface (navigation, pied de page, boutons, assistant, palette) en cinq langues.
 * Le contenu éditorial long reste en français tant que les traductions n'ont pas été relues
 * par des locuteurs natifs : un bandeau le signale dans les autres langues (voir README, « Langues »).
 */
export interface Dictionary {
  tagline: string;
  nav: {
    home: string;
    sanad: string;
    heritage: string;
    projects: string;
    contact: string;
    search: string;
    openMenu: string;
    closeMenu: string;
    mainNav: string;
    mobileNav: string;
    language: string;
    skip: string;
    capitals: string;
    appSpace: string;
  };
  hero: { eyebrow: string; title: string; lead: string; ctaPrimary: string; ctaSecondary: string; ask: string; promptHint: string; promptLabel: string };
  footer: {
    navigation: string;
    projects: string;
    contact: string;
    legal: string;
    rights: string;
    incubation: string;
    training: string;
    investment: string;
    placement: string;
  };
  assistant: {
    open: string;
    title: string;
    subtitleLive: string;
    subtitleLocal: string;
    placeholder: string;
    send: string;
    close: string;
    reset: string;
    empty: string;
    thinking: string;
    suggestions: string;
    stop: string;
    disclaimer: string;
  };
  palette: {
    placeholder: string;
    empty: string;
    pages: string;
    app: string;
    actions: string;
    askAssistant: string;
    suggested: string;
    hint: string;
  };
  notice: string;
  common: { comingSoon: string; learnMore: string };
}

const fr: Dictionary = {
  tagline: "Le lien qui construit l’Afrique.",
  nav: {
    home: "Accueil",
    sanad: "SANAD",
    heritage: "Héritage",
    projects: "Projets continentaux",
    contact: "Nous contacter",
    search: "Rechercher ou demander",
    openMenu: "Ouvrir le menu",
    closeMenu: "Fermer le menu",
    mainNav: "Navigation principale",
    mobileNav: "Navigation mobile",
    language: "Langue",
    skip: "Aller au contenu",
    capitals: "Capitales de l’Afrique francophone",
    appSpace: "Espace SANAD",
  },
  hero: {
    eyebrow: "Coopération panafricaine · Alger · ZLECAf",
    title: "Le lien qui construit l’Afrique.",
    lead: "WASSALA transforme des entrepreneurs en opérateurs économiques de leur continent, relie les projets aux investisseurs africains et accompagne ceux qui sont prêts.",
    ctaPrimary: "Découvrir SANAD",
    ctaSecondary: "Projets continentaux",
    ask: "Demander",
    promptHint: "L’assistant répond, puis prépare votre brief si vous décrivez un projet d’export ou d’achat.",
    promptLabel: "Décrivez votre projet ou posez une question à l’assistant WASSALA",
  },
  footer: {
    navigation: "Navigation",
    projects: "Projets continentaux",
    contact: "Contact",
    legal: "Mentions légales",
    rights: "Tous droits réservés.",
    incubation: "Incubation",
    training: "Formation",
    investment: "Investissement",
    placement: "Placement éthique",
  },
  assistant: {
    open: "Assistant WASSALA",
    title: "Assistant WASSALA",
    subtitleLive: "IA connectée · ancrée sur nos documents",
    subtitleLocal: "Base de connaissances WASSALA",
    placeholder: "Votre question ou votre projet…",
    send: "Envoyer",
    close: "Fermer l’assistant",
    reset: "Nouvelle conversation",
    empty: "Je réponds sur WASSALA, SANAD, la ZLECAf et nos projets. Décrivez aussi votre besoin (« J’exporte du ciment vers la Mauritanie ») : je prépare votre brief.",
    thinking: "Réflexion…",
    suggestions: "Suggestions",
    stop: "Arrêter",
    disclaimer: "L’assistant peut se tromper. Aucun engagement contractuel : un agent confirme chaque étape.",
  },
  palette: {
    placeholder: "Rechercher une page, ou décrire un besoin…",
    empty: "Aucun résultat. Appuyez sur Entrée pour demander à l’assistant.",
    pages: "Pages",
    app: "Application SANAD",
    actions: "Action suggérée",
    askAssistant: "Demander à l’assistant",
    suggested: "Préparer un brief",
    hint: "Naviguer · Entrée pour ouvrir · Échap pour fermer",
  },
  notice: "",
  common: { comingSoon: "À venir", learnMore: "En savoir plus" },
};

const en: Dictionary = {
  tagline: "The link that builds Africa.",
  nav: {
    home: "Home",
    sanad: "SANAD",
    heritage: "Heritage",
    projects: "Continental projects",
    contact: "Contact us",
    search: "Search or ask",
    openMenu: "Open menu",
    closeMenu: "Close menu",
    mainNav: "Main navigation",
    mobileNav: "Mobile navigation",
    language: "Language",
    skip: "Skip to content",
    capitals: "Capitals of French-speaking Africa",
    appSpace: "SANAD workspace",
  },
  hero: {
    eyebrow: "Pan-African cooperation · Algiers · AfCFTA",
    title: "The link that builds Africa.",
    lead: "WASSALA turns entrepreneurs into economic operators of their continent, connects projects with African investors and supports those who are ready.",
    ctaPrimary: "Discover SANAD",
    ctaSecondary: "Continental projects",
    ask: "Ask",
    promptHint: "The assistant answers, then prepares your brief if you describe an export or purchase project.",
    promptLabel: "Describe your project or ask the WASSALA assistant",
  },
  footer: {
    navigation: "Navigation",
    projects: "Continental projects",
    contact: "Contact",
    legal: "Legal notice",
    rights: "All rights reserved.",
    incubation: "Incubation",
    training: "Training",
    investment: "Investment",
    placement: "Ethical placement",
  },
  assistant: {
    open: "WASSALA assistant",
    title: "WASSALA assistant",
    subtitleLive: "Connected AI · answers grounded in our documents",
    subtitleLocal: "WASSALA knowledge base",
    placeholder: "Your question or project…",
    send: "Send",
    close: "Close the assistant",
    reset: "New conversation",
    empty: "I answer questions about WASSALA, SANAD, the AfCFTA and our projects. Describe your need (“I export cement to Mauritania”) and I will prepare your brief.",
    thinking: "Thinking…",
    suggestions: "Suggestions",
    stop: "Stop",
    disclaimer: "The assistant can make mistakes. Nothing here is binding: an agent confirms every step.",
  },
  palette: {
    placeholder: "Search a page, or describe a need…",
    empty: "No result. Press Enter to ask the assistant.",
    pages: "Pages",
    app: "SANAD application",
    actions: "Suggested action",
    askAssistant: "Ask the assistant",
    suggested: "Prepare a brief",
    hint: "Navigate · Enter to open · Esc to close",
  },
  notice: "Detailed content is currently available in French. Full translation in progress.",
  common: { comingSoon: "Coming soon", learnMore: "Learn more" },
};

const pt: Dictionary = {
  tagline: "O elo que constrói a África.",
  nav: {
    home: "Início",
    sanad: "SANAD",
    heritage: "Herança",
    projects: "Projetos continentais",
    contact: "Contacte-nos",
    search: "Pesquisar ou perguntar",
    openMenu: "Abrir o menu",
    closeMenu: "Fechar o menu",
    mainNav: "Navegação principal",
    mobileNav: "Navegação móvel",
    language: "Idioma",
    skip: "Ir para o conteúdo",
    capitals: "Capitais da África francófona",
    appSpace: "Espaço SANAD",
  },
  hero: {
    eyebrow: "Cooperação pan-africana · Argel · ZCLCA",
    title: "O elo que constrói a África.",
    lead: "A WASSALA transforma empreendedores em operadores económicos do seu continente, liga projetos a investidores africanos e acompanha quem está pronto.",
    ctaPrimary: "Descobrir o SANAD",
    ctaSecondary: "Projetos continentais",
    ask: "Perguntar",
    promptHint: "O assistente responde e prepara o seu briefing se descrever um projeto de exportação ou de compra.",
    promptLabel: "Descreva o seu projeto ou pergunte ao assistente WASSALA",
  },
  footer: {
    navigation: "Navegação",
    projects: "Projetos continentais",
    contact: "Contacto",
    legal: "Aviso legal",
    rights: "Todos os direitos reservados.",
    incubation: "Incubação",
    training: "Formação",
    investment: "Investimento",
    placement: "Aplicação ética",
  },
  assistant: {
    open: "Assistente WASSALA",
    title: "Assistente WASSALA",
    subtitleLive: "IA ligada · respostas baseadas nos nossos documentos",
    subtitleLocal: "Base de conhecimento WASSALA",
    placeholder: "A sua pergunta ou projeto…",
    send: "Enviar",
    close: "Fechar o assistente",
    reset: "Nova conversa",
    empty: "Respondo sobre a WASSALA, o SANAD, a ZCLCA e os nossos projetos. Descreva a sua necessidade e preparo o seu briefing.",
    thinking: "A pensar…",
    suggestions: "Sugestões",
    stop: "Parar",
    disclaimer: "O assistente pode enganar-se. Nada aqui é vinculativo: um agente confirma cada etapa.",
  },
  palette: {
    placeholder: "Pesquisar uma página ou descrever uma necessidade…",
    empty: "Sem resultados. Prima Enter para perguntar ao assistente.",
    pages: "Páginas",
    app: "Aplicação SANAD",
    actions: "Ação sugerida",
    askAssistant: "Perguntar ao assistente",
    suggested: "Preparar um briefing",
    hint: "Navegar · Enter para abrir · Esc para fechar",
  },
  notice: "O conteúdo detalhado está disponível em francês. Tradução completa em curso.",
  common: { comingSoon: "Em breve", learnMore: "Saber mais" },
};

const ar: Dictionary = {
  tagline: "الرابط الذي يبني إفريقيا.",
  nav: {
    home: "الرئيسية",
    sanad: "سند",
    heritage: "الإرث",
    projects: "المشاريع القارية",
    contact: "اتصل بنا",
    search: "ابحث أو اسأل",
    openMenu: "فتح القائمة",
    closeMenu: "إغلاق القائمة",
    mainNav: "التنقل الرئيسي",
    mobileNav: "التنقل على الجوال",
    language: "اللغة",
    skip: "الانتقال إلى المحتوى",
    capitals: "عواصم إفريقيا الناطقة بالفرنسية",
    appSpace: "فضاء سند",
  },
  hero: {
    eyebrow: "تعاون إفريقي · الجزائر العاصمة · منطقة التجارة الحرة القارية",
    title: "الرابط الذي يبني إفريقيا.",
    lead: "تحوّل وصلة روّاد الأعمال إلى فاعلين اقتصاديين في قارتهم، وتربط المشاريع بالمستثمرين الأفارقة، وترافق المستعدّين منهم.",
    ctaPrimary: "اكتشف سند",
    ctaSecondary: "المشاريع القارية",
    ask: "اسأل",
    promptHint: "يجيب المساعد، ثم يُعدّ ملخّص طلبك إذا وصفت مشروع تصدير أو شراء.",
    promptLabel: "صف مشروعك أو اسأل مساعد وصلة",
  },
  footer: {
    navigation: "التنقل",
    projects: "المشاريع القارية",
    contact: "الاتصال",
    legal: "الإشعار القانوني",
    rights: "جميع الحقوق محفوظة.",
    incubation: "الاحتضان",
    training: "التكوين",
    investment: "الاستثمار",
    placement: "التوظيف المالي الأخلاقي",
  },
  assistant: {
    open: "مساعد وصلة",
    title: "مساعد وصلة",
    subtitleLive: "ذكاء اصطناعي متصل · إجابات مستندة إلى وثائقنا",
    subtitleLocal: "قاعدة معارف وصلة",
    placeholder: "اطرح سؤالك أو صف مشروعك…",
    send: "إرسال",
    close: "إغلاق المساعد",
    reset: "محادثة جديدة",
    empty: "أجيب عن أسئلتكم حول وصلة وسند ومنطقة التجارة الحرة القارية ومشاريعنا. صفوا حاجتكم وسأُعدّ ملخّص طلبكم.",
    thinking: "جارٍ التفكير…",
    suggestions: "اقتراحات",
    stop: "إيقاف",
    disclaimer: "قد يخطئ المساعد. لا شيء هنا ملزم: يؤكد وكيل كل خطوة.",
  },
  palette: {
    placeholder: "ابحث عن صفحة أو صف حاجتك…",
    empty: "لا نتائج. اضغط Enter لسؤال المساعد.",
    pages: "الصفحات",
    app: "تطبيق سند",
    actions: "إجراء مقترح",
    askAssistant: "اسأل المساعد",
    suggested: "إعداد ملخّص الطلب",
    hint: "تنقّل · Enter للفتح · Esc للإغلاق",
  },
  notice: "المحتوى التفصيلي متاح حاليًا بالفرنسية. الترجمة الكاملة قيد الإنجاز.",
  common: { comingSoon: "قريبًا", learnMore: "اعرف المزيد" },
};

const sw: Dictionary = {
  tagline: "Kiungo kinachojenga Afrika.",
  nav: {
    home: "Mwanzo",
    sanad: "SANAD",
    heritage: "Urithi",
    projects: "Miradi ya bara",
    contact: "Wasiliana nasi",
    search: "Tafuta au uliza",
    openMenu: "Fungua menyu",
    closeMenu: "Funga menyu",
    mainNav: "Urambazaji mkuu",
    mobileNav: "Urambazaji wa simu",
    language: "Lugha",
    skip: "Ruka hadi maudhui",
    capitals: "Miji mikuu ya Afrika inayozungumza Kifaransa",
    appSpace: "Eneo la SANAD",
  },
  hero: {
    eyebrow: "Ushirikiano wa Kiafrika · Algiers · AfCFTA",
    title: "Kiungo kinachojenga Afrika.",
    lead: "WASSALA inawageuza wajasiriamali kuwa waendeshaji wa kiuchumi wa bara lao, inaunganisha miradi na wawekezaji wa Kiafrika na inawasindikiza walio tayari.",
    ctaPrimary: "Gundua SANAD",
    ctaSecondary: "Miradi ya bara",
    ask: "Uliza",
    promptHint: "Msaidizi anajibu, kisha anaandaa muhtasari wako ukieleza mradi wa kuuza nje au kununua.",
    promptLabel: "Eleza mradi wako au muulize msaidizi wa WASSALA",
  },
  footer: {
    navigation: "Urambazaji",
    projects: "Miradi ya bara",
    contact: "Mawasiliano",
    legal: "Taarifa za kisheria",
    rights: "Haki zote zimehifadhiwa.",
    incubation: "Uatamizi",
    training: "Mafunzo",
    investment: "Uwekezaji",
    placement: "Uwekezaji wa kimaadili",
  },
  assistant: {
    open: "Msaidizi wa WASSALA",
    title: "Msaidizi wa WASSALA",
    subtitleLive: "AI iliyounganishwa · majibu kutoka kwa nyaraka zetu",
    subtitleLocal: "Hifadhi ya maarifa ya WASSALA",
    placeholder: "Uliza swali, au eleza mradi wako…",
    send: "Tuma",
    close: "Funga msaidizi",
    reset: "Mazungumzo mapya",
    empty: "Ninajibu kuhusu WASSALA, SANAD, AfCFTA na miradi yetu. Eleza hitaji lako nami nitaandaa muhtasari wako.",
    thinking: "Inafikiria…",
    suggestions: "Mapendekezo",
    stop: "Simamisha",
    disclaimer: "Msaidizi anaweza kukosea. Hakuna kinachofunga hapa: wakala anathibitisha kila hatua.",
  },
  palette: {
    placeholder: "Tafuta ukurasa, au eleza hitaji…",
    empty: "Hakuna matokeo. Bonyeza Enter kumuuliza msaidizi.",
    pages: "Kurasa",
    app: "Programu ya SANAD",
    actions: "Hatua inayopendekezwa",
    askAssistant: "Muulize msaidizi",
    suggested: "Andaa muhtasari",
    hint: "Abiri · Enter kufungua · Esc kufunga",
  },
  notice: "Maudhui ya kina yanapatikana kwa Kifaransa kwa sasa. Tafsiri kamili inaendelea.",
  common: { comingSoon: "Inakuja", learnMore: "Jifunze zaidi" },
};

export const DICTIONARIES: Record<Locale, Dictionary> = { fr, en, pt, ar, sw };

export function dictionaryFor(locale: Locale): Dictionary {
  return DICTIONARIES[locale];
}
