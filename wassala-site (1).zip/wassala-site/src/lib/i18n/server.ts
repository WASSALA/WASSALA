import "server-only";
import { cookies } from "next/headers";
import { LOCALE_COOKIE, parseLocale, type Locale } from "@/lib/locale";
import { dictionaryFor, type Dictionary } from "./dictionaries";

/** Langue courante, lue dans le cookie (aucun préfixe d'URL). */
export async function getLocale(): Promise<Locale> {
  const store = await cookies();
  return parseLocale(store.get(LOCALE_COOKIE)?.value ?? process.env.NEXT_PUBLIC_DEFAULT_LOCALE);
}

export async function getDictionary(): Promise<{ locale: Locale; t: Dictionary }> {
  const locale = await getLocale();
  return { locale, t: dictionaryFor(locale) };
}
