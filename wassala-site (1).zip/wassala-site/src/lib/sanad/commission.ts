/**
 * Répartition d'une commission SANAD (SILSILA).
 *
 * Règle ILLUSTRATIVE, à confirmer avant mise en production :
 * - la commission vaut 3 à 5 % de la valeur confirmée ;
 * - le fonds DAMAN reçoit 0,4 % de la valeur (milieu de la fourchette 0,3 à 0,5 %) ;
 * - le reste est réparti entre apporteur, agent local, témoins et WASSALA selon les proportions
 *   de l'exemple de référence du dossier : 60 000 $ à 4 % = 2 400 $, dont DAMAN 240 $ et
 *   apporteur 700 $, agent local 500 $, témoins 300 $, WASSALA 660 $ (reste : 2 160 $).
 */
export interface CommissionBreakdown {
  total: number;
  daman: number;
  apporteur: number;
  agentLocal: number;
  temoins: number;
  wassala: number;
  /** Part de WASSALA en % de la valeur de transaction (une décimale). */
  wassalaShare: number;
}

export const COMMISSION_RATE_MIN = 3;
export const COMMISSION_RATE_MAX = 5;
export const DAMAN_RATE = 0.4; // % de la valeur
export const DAMAN_RANGE = [0.3, 0.5] as const; // % de la valeur
export const DAMAN_COVER_RANGE = [10, 20] as const; // % de la valeur, première perte
export const AMANA_TRANCHES = [
  { pct: 30, event: "Inspection" },
  { pct: 40, event: "Chargement ou passage de la frontière" },
  { pct: 30, event: "Réception" },
] as const;

const REF_PARTS = { apporteur: 700, agentLocal: 500, temoins: 300, wassala: 660 } as const;
const REF_REST = REF_PARTS.apporteur + REF_PARTS.agentLocal + REF_PARTS.temoins + REF_PARTS.wassala; // 2 160

const cents = (n: number) => Math.round(n * 100) / 100;

/**
 * @param value Valeur de la transaction.
 * @param rate Taux de commission en pourcentage (3 à 5).
 */
export function computeCommission(value: number, rate: number): CommissionBreakdown {
  const safeValue = Math.max(0, value);
  const total = cents((safeValue * rate) / 100);
  const daman = cents((safeValue * DAMAN_RATE) / 100);
  const rest = Math.max(0, total - daman);
  const ratio = rest / REF_REST;
  const apporteur = cents(REF_PARTS.apporteur * ratio);
  const agentLocal = cents(REF_PARTS.agentLocal * ratio);
  const temoins = cents(REF_PARTS.temoins * ratio);
  const wassala = cents(rest - apporteur - agentLocal - temoins);
  return {
    total,
    daman,
    apporteur,
    agentLocal,
    temoins,
    wassala,
    wassalaShare: safeValue > 0 ? Math.round((wassala / safeValue) * 1000) / 10 : 0,
  };
}

/** Exemple de référence du dossier (60 000 $, 4 %) : sert de test de non-régression. */
export const REFERENCE_EXAMPLE = computeCommission(60_000, 4);

/** Montants des tranches AMANA pour une valeur donnée. */
export function amanaTranches(value: number) {
  return AMANA_TRANCHES.map((t) => ({ ...t, amount: cents((value * t.pct) / 100) }));
}
