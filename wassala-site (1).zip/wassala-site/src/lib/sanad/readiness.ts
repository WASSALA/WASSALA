/**
 * Score de préparation (0-100) d'un profil, ILLUSTRATIF : pondérations à valider avec l'équipe.
 * Chaque critère est expliqué : l'utilisateur sait quoi faire pour progresser.
 */
export interface ReadinessInput {
  secteur: boolean;
  corridor: boolean;
  kyc: boolean;
  ficheTechnique: boolean;
  codeSH: boolean;
  transactionsAbouties: number;
  ticket: boolean;
}

export interface ReadinessItem {
  id: keyof ReadinessInput;
  label: string;
  weight: number;
  earned: number;
  tip: string;
}

const RULES: ReadonlyArray<{ id: keyof ReadinessInput; label: string; weight: number; tip: string }> = [
  { id: "kyc", label: "Vérification KYC/KYB", weight: 25, tip: "Faites vérifier votre entreprise : sans elle, aucune présentation." },
  { id: "secteur", label: "Secteur documenté", weight: 10, tip: "Précisez votre secteur et vos produits." },
  { id: "corridor", label: "Corridor cible", weight: 10, tip: "Choisissez un pays de destination dans la ZLECAf." },
  { id: "ficheTechnique", label: "Fiche technique", weight: 15, tip: "Ajoutez une fiche technique et des photos du produit." },
  { id: "codeSH", label: "Code SH", weight: 10, tip: "Le code SH détermine le régime ZLECAf applicable." },
  { id: "ticket", label: "Ticket précisé", weight: 10, tip: "Indiquez une fourchette de valeur par transaction." },
  { id: "transactionsAbouties", label: "Transactions abouties", weight: 20, tip: "Chaque transaction menée à terme enrichit votre passeport." },
];

export function readiness(input: ReadinessInput): { score: number; items: ReadinessItem[] } {
  const items = RULES.map((r) => {
    const v = input[r.id];
    const ratio = r.id === "transactionsAbouties" ? Math.min(1, Number(v) / 3) : v ? 1 : 0;
    return { ...r, earned: Math.round(r.weight * ratio) };
  });
  return { score: items.reduce((a, i) => a + i.earned, 0), items };
}
