import { z } from "zod";
import type { FilEvent, Transaction } from "@/lib/api/types";
import { DAMAN_COVER_RANGE, amanaTranches, computeCommission } from "./commission";

/**
 * Récapitulatif d'accord SANAD.
 *
 * Généré à partir du Fil une fois la négociation engagée, il fixe pour WASSALA la base de la commission,
 * les tranches AMANA et les missions CHAHID. C'est un document INTERNE : il ne vaut ni facture,
 * ni contrat de vente entre les parties. Chaque terme renvoie aux messages du Fil dont il est tiré ;
 * ce qui n'a pas été écrit dans le Fil reste « manquant » : rien n'est inventé.
 */
export const ACCORD_DISCLAIMER =
  "Document interne SANAD. Il récapitule les termes convenus dans le Fil pour établir la base de la commission, les tranches AMANA et les missions CHAHID. Il ne vaut ni facture, ni contrat de vente entre les parties.";

export const CLAUSES = [
  { id: "produit", label: "Produit" },
  { id: "quantite", label: "Quantité" },
  { id: "conditionnement", label: "Conditionnement" },
  { id: "prixUnitaire", label: "Prix unitaire" },
  { id: "valeur", label: "Valeur convenue" },
  { id: "incoterm", label: "Incoterm et lieu" },
  { id: "delai", label: "Délai de livraison" },
  { id: "codeSH", label: "Code SH" },
  { id: "regime", label: "Régime ZLECAf" },
  { id: "paiement", label: "Paiement" },
] as const;

export type ClauseId = (typeof CLAUSES)[number]["id"];
export type ClauseStatus = "trouvé" | "à confirmer" | "manquant";

export interface Clause {
  id: ClauseId;
  label: string;
  value: string | null;
  /** Numéros des messages du Fil (1 = premier message). */
  sources: number[];
  status: ClauseStatus;
}

export interface Condition {
  text: string;
  sources: number[];
}

export interface AccordRecap {
  reference: string;
  transactionId: string;
  transactionRef: string;
  generatedAt: string;
  mode: "live" | "local";
  vendeur: string;
  acheteur: string;
  corridor: string;
  secteur: string;
  devise: string;
  clauses: Clause[];
  conditions: Condition[];
  /** Libellés des termes absents du Fil, à faire préciser par les parties. */
  missing: string[];
  commission: { taux: number; base: number; baseSource: "fil" | "brief"; total: number; wassala: number; daman: number };
  tranches: Array<{ pct: number; event: string; amount: number }>;
  damanCover: readonly [number, number];
  messageCount: number;
}

type Found = { value: string; sources: number[] };

const SPACES = /[\s  ]/g;
const toNumber = (s: string): number => Number(s.replace(SPACES, "").replace(",", "."));
const fmt = (n: number): string => new Intl.NumberFormat("fr-FR").format(n).replace(/ /g, " ");
const CURRENCY: Record<string, string> = { $: "$", usd: "$", "€": "€", eur: "€", dzd: "DZD" };
const currency = (c: string) => CURRENCY[c.toLowerCase()] ?? c;

/** Parcourt les messages et regroupe les valeurs identiques : une valeur reprise par les deux parties cumule ses sources. */
function collect(fil: readonly FilEvent[], re: RegExp, build: (m: RegExpMatchArray) => string | null): Found | null {
  const byValue = new Map<string, Found>();
  let last: Found | null = null;
  for (const [i, e] of fil.entries()) {
    const m = e.text.match(re);
    if (!m) continue;
    const value = build(m);
    if (!value) continue;
    const key = value.toLowerCase();
    const f = byValue.get(key) ?? { value, sources: [] };
    f.sources.push(i + 1);
    byValue.set(key, f);
    // La dernière valeur écrite fait foi (une contre-proposition remplace la précédente).
    last = f;
  }
  return last;
}

const INCOTERM = /\b(EXW|FCA|FAS|FOB|CFR|CIF|CPT|CIP|DAP|DPU|DDP)\b(?:\s+([A-ZÀ-Ý][\p{L}’'-]+(?:\s[A-ZÀ-Ý][\p{L}’'-]+)*))?/u;
const DELAI = /\bsous\s+(\d{1,3})\s+jours(\s+après\s+l[’']accord)?/i;
const CODE_SH = /code\s+SH[^\d]{0,20}(\d{4}(?:\.\d{2}){0,2})/i;
const QTE_PRODUIT = /(\d[\d\s .,]*)\s*(tonnes?|kg|cartons?|unités?|conteneurs?|sacs?)\s+de\s+([^,.;:]+)/i;
const CONDITIONNEMENT = /\b(cartons?|sacs?|palettes?|fûts?|bidons?|caisses?)\s+de\s+(\d+(?:[.,]\d+)?)\s*(kg|g|l)\b/i;
const PRIX = /(\d[\d\s .,]*)\s*(\$|USD|€|EUR|DZD)\s+(?:la|le|par)\s+(tonne|kg|unité|carton)/i;
const VALEUR = /\bsoit\s+(\d[\d\s .,]*)\s*(\$|USD|€|EUR|DZD)/i;
const REGIME = /régime\s+ZLECAf\s*:\s*([^.\n]+)/i;
const CONDITION = /\b(demandons|exigeons|souhaitons|merci de|à condition)\b.*\b(certificat|analyse|laboratoire|échantillon|inspection|norme|étiquetage|emballage)/i;

/** Extraction locale, déterministe : expressions régulières sur le Fil, sources conservées. */
export function extractLocal(fil: readonly FilEvent[]): { clauses: Partial<Record<ClauseId, Found>>; conditions: Condition[] } {
  const parties = fil.filter((e) => e.actor === "Vendeur" || e.actor === "Acheteur");
  const out: Partial<Record<ClauseId, Found>> = {};
  const qp = collect(fil, QTE_PRODUIT, (m) => `${fmt(toNumber(m[1]!))} ${m[2]!.toLowerCase()}|${m[3]!.trim()}`);
  if (qp) {
    const [q, p] = qp.value.split("|") as [string, string];
    out.quantite = { value: q, sources: qp.sources };
    out.produit = { value: p, sources: qp.sources };
  }
  const cond = collect(fil, CONDITIONNEMENT, (m) => `${m[1]!.toLowerCase()} de ${m[2]} ${m[3]!.toLowerCase()}`);
  if (cond) out.conditionnement = cond;
  const prix = collect(fil, PRIX, (m) => `${fmt(toNumber(m[1]!))} ${currency(m[2]!)} ${m[3] === "tonne" ? "la" : "le"} ${m[3]}`);
  if (prix) out.prixUnitaire = prix;
  const valeur = collect(fil, VALEUR, (m) => `${fmt(toNumber(m[1]!))} ${currency(m[2]!)}`);
  if (valeur) out.valeur = valeur;
  const inc = collect(fil, INCOTERM, (m) => (m[2] ? `${m[1]} ${m[2]}` : m[1]!));
  if (inc) out.incoterm = inc;
  const delai = collect(fil, DELAI, (m) => `${m[1]} jours${m[2] ? " après l’accord" : ""}`);
  if (delai) {
    // « sous 45 jours » et « sous 45 jours après l'accord » désignent le même délai : on garde la formulation complète.
    const all = fil.map((e, i) => (DELAI.test(e.text) ? i + 1 : 0)).filter(Boolean);
    const full = fil.map((e) => e.text.match(DELAI)).find((m) => m && m[1] === delai.value.split(" ")[0] && m[2]);
    out.delai = { value: full ? `${full[1]} jours après l’accord` : delai.value, sources: all };
  }
  const sh = collect(fil, CODE_SH, (m) => m[1]!);
  if (sh) out.codeSH = sh;
  const regime = collect(fil, REGIME, (m) => m[1]!.trim());
  if (regime) out.regime = regime;
  const amana = fil.map((e, i) => (/AMANA|séquestre/i.test(e.text) && parties.includes(e) ? i + 1 : 0)).filter(Boolean);
  if (amana.length) {
    out.paiement = {
      value: "Séquestre AMANA, trois tranches : 30 % à l’inspection, 40 % au chargement ou au passage de la frontière, 30 % à la réception",
      sources: amana,
    };
  }
  const conditions = fil
    .map((e, i) => ({ e, n: i + 1 }))
    .filter(({ e }) => parties.includes(e) && CONDITION.test(e.text))
    .map(({ e, n }) => ({ text: e.text, sources: [n] }));
  return { clauses: out, conditions };
}

/** Montant lu dans une valeur (« 60 000 $ » → 60000). */
export function parseAmount(value: string | null | undefined): number | null {
  const m = value?.match(/\d[\d\s  .,]*/);
  if (!m) return null;
  const n = toNumber(m[0].trim());
  return Number.isFinite(n) && n > 0 ? n : null;
}

const statusOf = (value: string | null): ClauseStatus => (value === null ? "manquant" : /\[[^\]]*\]/.test(value) ? "à confirmer" : "trouvé");

/** Assemble le récapitulatif : termes extraits du Fil, et calculs SANAD (commission, tranches) faits par le code, jamais par l'IA. */
export function buildRecap(
  tx: Transaction,
  fil: readonly FilEvent[],
  found: Partial<Record<ClauseId, Found>>,
  conditions: Condition[],
  mode: "live" | "local",
  now = new Date(),
): AccordRecap {
  const clauses: Clause[] = CLAUSES.map(({ id, label }) => {
    const f = found[id];
    const value = f?.value ?? null;
    return { id, label, value, sources: f?.sources ?? [], status: statusOf(value) };
  });
  const filValue = parseAmount(found.valeur?.value);
  const base = filValue ?? tx.valeur;
  const c = computeCommission(base, tx.taux);
  if (!filValue) {
    const v = clauses.find((x) => x.id === "valeur")!;
    v.value = `${fmt(tx.valeur)} ${currency(tx.devise)} [valeur du brief, à confirmer dans le Fil]`;
    v.status = "à confirmer";
  }
  return {
    reference: `RA-${tx.ref.replace(/^TX-/, "")}`,
    transactionId: tx.id,
    transactionRef: tx.ref,
    generatedAt: now.toISOString(),
    mode,
    vendeur: tx.vendeur,
    acheteur: tx.acheteur,
    corridor: tx.corridor,
    secteur: tx.secteur,
    devise: tx.devise,
    clauses,
    conditions,
    missing: clauses.filter((x) => x.status === "manquant").map((x) => x.label),
    commission: { taux: tx.taux, base, baseSource: filValue ? "fil" : "brief", total: c.total, wassala: c.wassala, daman: c.daman },
    tranches: amanaTranches(base).map((t) => ({ pct: t.pct, event: t.event, amount: t.amount })),
    damanCover: DAMAN_COVER_RANGE,
    messageCount: fil.length,
  };
}

/** Réponse attendue du modèle : chaque valeur doit citer au moins un message du Fil. */
const aiClause = z.object({ value: z.string().trim().min(1).max(200).nullable(), sources: z.array(z.number().int().positive()).max(12).default([]) });
export const aiAccordSchema = z.object({
  clauses: z.object(Object.fromEntries(CLAUSES.map((c) => [c.id, aiClause.optional()])) as Record<ClauseId, z.ZodOptional<typeof aiClause>>),
  conditions: z.array(z.object({ text: z.string().trim().min(3).max(300), sources: z.array(z.number().int().positive()).min(1).max(6) })).max(8).default([]),
});
export type AiAccord = z.infer<typeof aiAccordSchema>;

/**
 * Fusionne la réponse du modèle avec l'extraction locale. Une valeur du modèle n'est retenue que si elle cite
 * des messages qui existent ; sinon l'extraction locale (ou « manquant ») est conservée.
 */
export function mergeAi(local: Partial<Record<ClauseId, Found>>, ai: AiAccord, messageCount: number): Partial<Record<ClauseId, Found>> {
  const valid = (s: number[]) => [...new Set(s.filter((n) => n >= 1 && n <= messageCount))].sort((a, b) => a - b);
  const out: Partial<Record<ClauseId, Found>> = { ...local };
  for (const { id } of CLAUSES) {
    const a = ai.clauses[id];
    if (!a || a.value === null) continue;
    const sources = valid(a.sources);
    if (sources.length) out[id] = { value: a.value, sources };
  }
  return out;
}

export function validConditions(conditions: AiAccord["conditions"], messageCount: number): Condition[] {
  return conditions
    .map((c) => ({ text: c.text, sources: c.sources.filter((n) => n >= 1 && n <= messageCount) }))
    .filter((c) => c.sources.length > 0);
}

/** Le Fil numéroté, tel qu'il est transmis au modèle. */
export function numberedThread(fil: readonly FilEvent[]): string {
  return fil.map((e, i) => `#${i + 1} [${e.at.slice(0, 10)}] ${e.actor} (${e.kind}) : ${e.text}`).join("\n");
}
