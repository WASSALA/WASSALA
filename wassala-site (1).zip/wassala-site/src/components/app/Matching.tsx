"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Check, Circle, Sparkles } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ScoreBadge } from "@/components/shared/ScoreBadge";
import { SECTORS } from "@/lib/forms/schemas";
import { readiness, type ReadinessInput } from "@/lib/sanad/readiness";
import { cn } from "@/lib/utils";

const TARGETS = ["Mauritanie", "Sénégal", "Mali", "Niger", "Nigéria", "Côte d’Ivoire", "Tunisie", "Tchad"] as const;

/** Contreparties ILLUSTRATIVES (noms en placeholder). */
const MATCHES = [
  { id: "m1", nom: "[Société A]", pays: "Sénégal", secteur: "Agroalimentaire", ticket: "50 000 à 120 000 $", base: 80, raisons: ["Secteur commun", "Capitale portuaire", "Ticket compatible"] },
  { id: "m2", nom: "[Société B]", pays: "Mauritanie", secteur: "Agroalimentaire", ticket: "30 000 à 90 000 $", base: 76, raisons: ["Pays frontalier", "Secteur commun"] },
  { id: "m3", nom: "[Société C]", pays: "Nigéria", secteur: "Industrie et équipements", ticket: "80 000 à 200 000 $", base: 68, raisons: ["Hub partenaire Lagos", "Ticket compatible"] },
  { id: "m4", nom: "[Société D]", pays: "Niger", secteur: "Matériaux et BTP", ticket: "100 000 à 400 000 $", base: 64, raisons: ["Pays frontalier", "Route transsaharienne"] },
  { id: "m5", nom: "[Société E]", pays: "Côte d’Ivoire", secteur: "Pharmacie et santé", ticket: "40 000 à 150 000 $", base: 59, raisons: ["Capitale portuaire", "Secteur réglementé"] },
] as const;

export function Matching() {
  const [secteur, setSecteur] = useState<string>("Agroalimentaire");
  const [pays, setPays] = useState<string>("Sénégal");
  const [docs, setDocs] = useState<Pick<ReadinessInput, "kyc" | "ficheTechnique" | "codeSH" | "ticket">>({ kyc: true, ficheTechnique: false, codeSH: false, ticket: true });
  const r = useMemo(() => readiness({ ...docs, secteur: !!secteur, corridor: !!pays, transactionsAbouties: 1 }), [docs, secteur, pays]);
  const next = r.items.find((i) => i.earned < i.weight);

  const matches = useMemo(
    () =>
      MATCHES.map((m) => ({ ...m, score: Math.min(98, m.base + (m.secteur === secteur ? 10 : 0) + (m.pays === pays ? 8 : 0)) })).sort((a, b) => b.score - a.score),
    [secteur, pays],
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Matching et score de préparation</h1>
        <p className="mt-1 text-ink-soft">
          Votre préparation détermine les contreparties qui vous sont présentées. <span className="placeholder-tag">Pondérations illustratives</span>
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_1.1fr]">
        <section className="card p-5 md:p-6" aria-labelledby="profil-title">
          <h2 id="profil-title" className="mb-5 font-sans text-base font-semibold">
            Mon profil
          </h2>
          <div className="mb-5 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="m-secteur" className="field-label">
                Secteur
              </label>
              <select id="m-secteur" value={secteur} onChange={(e) => setSecteur(e.target.value)} className="field">
                {SECTORS.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="m-pays" className="field-label">
                Pays cible
              </label>
              <select id="m-pays" value={pays} onChange={(e) => setPays(e.target.value)} className="field">
                {TARGETS.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
            </div>
          </div>
          <fieldset>
            <legend className="mb-2 text-sm font-semibold">Pièces fournies</legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {(
                [
                  ["kyc", "KYC/KYB vérifié"],
                  ["ficheTechnique", "Fiche technique"],
                  ["codeSH", "Code SH"],
                  ["ticket", "Ticket précisé"],
                ] as const
              ).map(([k, label]) => (
                <label key={k} className={cn("flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border px-3 text-sm transition-colors", docs[k] ? "border-forest bg-forest/5" : "border-line")}>
                  <input type="checkbox" checked={docs[k]} onChange={(e) => setDocs((d) => ({ ...d, [k]: e.target.checked }))} className="h-4 w-4" />
                  {label}
                </label>
              ))}
            </div>
          </fieldset>
        </section>

        <section className="card p-5 md:p-6" aria-labelledby="score-title">
          <h2 id="score-title" className="mb-4 font-sans text-base font-semibold">
            Score de préparation
          </h2>
          <ScoreBadge key={r.score} score={r.score} label="Global" />
          <ul className="mt-5 space-y-2 text-sm">
            {r.items.map((i) => (
              <li key={i.id} className="flex items-center gap-3">
                {i.earned >= i.weight ? <Check className="h-4 w-4 text-forest" aria-hidden="true" /> : <Circle className="h-4 w-4 text-ink-soft/50" aria-hidden="true" />}
                <span className={cn("flex-1", i.earned >= i.weight ? "" : "text-ink-soft")}>{i.label}</span>
                <span className="tabular-nums text-ink-soft">
                  {i.earned}/{i.weight}
                </span>
              </li>
            ))}
          </ul>
          <AnimatePresence mode="wait">
            {next ? (
              <motion.p key={next.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-5 flex gap-2 rounded-lg bg-ink p-4 text-sm text-bg">
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
                <span>
                  <b className="text-gold">Prochain pas (+{next.weight - next.earned} pts) :</b> {next.tip}
                </span>
              </motion.p>
            ) : null}
          </AnimatePresence>
        </section>
      </div>

      <section aria-labelledby="matches-title">
        <h2 id="matches-title" className="mb-4 font-sans text-lg font-semibold">
          Contreparties suggérées
        </h2>
        <motion.ul layout className="grid gap-4 md:grid-cols-2">
          {matches.map((m) => (
            <motion.li layout key={m.id} className="card flex flex-col p-5">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-sans text-base font-semibold">{m.nom}</h3>
                  <p className="text-sm text-ink-soft">
                    {m.pays} · {m.secteur}
                  </p>
                  <p className="text-sm text-ink-soft">{m.ticket}</p>
                </div>
              </div>
              <ScoreBadge score={m.score} label="Compatibilité" />
              <ul className="mt-3 flex flex-wrap gap-1.5">
                {m.raisons.map((x) => (
                  <li key={x} className="rounded-full border border-line px-2.5 py-0.5 text-xs text-ink-soft">
                    {x}
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => toast.success(`Demande d’introduction envoyée pour ${m.nom} (démonstration). Elle sera enregistrée dans SILSILA.`)}
                  className="btn-primary min-h-10 px-4 text-sm"
                >
                  Demander l’introduction
                </button>
                <Link
                  href={`/app/transactions/new?${new URLSearchParams({ role: "exportateur", secteur: m.secteur, destination: m.pays, origine: "Algérie" }).toString()}`}
                  className="btn-outline min-h-10 px-4 text-sm"
                >
                  Préparer un brief
                </Link>
              </div>
            </motion.li>
          ))}
        </motion.ul>
      </section>
    </div>
  );
}
