"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Check, Landmark, Loader2, Send, ShieldCheck, Sparkles, Wand2 } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { ScoreBadge } from "@/components/shared/ScoreBadge";
import { FORM_COUNTRIES } from "@/data/countries";
import { SITE } from "@/data/site";
import type { BriefIntent } from "@/lib/ai/intent";
import { INCOTERMS, ROLES, SECTORS, briefSchema, type Role } from "@/lib/forms/schemas";
import { AMANA_TRANCHES, COMMISSION_RATE_MAX, COMMISSION_RATE_MIN } from "@/lib/sanad/commission";
import { cn, formatAmount } from "@/lib/utils";

const countries = FORM_COUNTRIES as readonly string[];
const isCountry = (v: string | null): v is (typeof FORM_COUNTRIES)[number] => !!v && countries.includes(v);
const isSector = (v: string | null): v is (typeof SECTORS)[number] => !!v && (SECTORS as readonly string[]).includes(v);

type FieldName = "entreprise" | "ville" | "paysOrigine" | "paysDestination" | "secteur" | "produit" | "codeSH" | "quantite" | "valeur" | "incoterm" | "delai" | "email" | "telephone" | "description";

const READINESS: ReadonlyArray<[FieldName, number]> = [
  ["entreprise", 10],
  ["paysOrigine", 8],
  ["paysDestination", 12],
  ["secteur", 10],
  ["produit", 12],
  ["valeur", 12],
  ["quantite", 8],
  ["codeSH", 10],
  ["incoterm", 5],
  ["email", 8],
  ["description", 5],
];

/**
 * Brief SANAD (devenir exportateur / devenir acheteur).
 * Une phrase libre suffit pour démarrer : l'IA pré-remplit les champs (détection locale, complétée par Claude si configuré),
 * l'utilisateur vérifie, le récapitulatif se met à jour en direct.
 */
export function BriefForm() {
  const params = useSearchParams();
  const router = useRouter();
  const reduce = useReducedMotion();
  const initialRole: Role = params.get("role") === "acheteur" ? "acheteur" : "exportateur";
  const [sentence, setSentence] = useState(params.get("q") ?? "");
  const [extracting, setExtracting] = useState(false);
  const [aiFilled, setAiFilled] = useState<Set<string>>(new Set());
  const [sent, setSent] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(briefSchema),
    defaultValues: {
      role: initialRole,
      entreprise: "",
      ville: "",
      produit: params.get("produit") ?? "",
      codeSH: "",
      quantite: params.get("quantite") ?? "",
      delai: "",
      email: "",
      telephone: "",
      description: "",
      website: "",
      ...(isCountry(params.get("origine")) ? { paysOrigine: params.get("origine") as (typeof FORM_COUNTRIES)[number] } : initialRole === "exportateur" ? { paysOrigine: "Algérie" as const } : {}),
      ...(isCountry(params.get("destination")) ? { paysDestination: params.get("destination") as (typeof FORM_COUNTRIES)[number] } : {}),
      ...(isSector(params.get("secteur")) ? { secteur: params.get("secteur") as (typeof SECTORS)[number] } : {}),
      ...(Number(params.get("valeur")) > 0 ? { valeur: Number(params.get("valeur")) } : {}),
    },
  });

  const v = watch();
  const role = v.role as Role;

  useEffect(() => {
    if (!aiFilled.size) return;
    const id = window.setTimeout(() => setAiFilled(new Set()), 2600);
    return () => window.clearTimeout(id);
  }, [aiFilled]);

  const readiness = useMemo(() => {
    let score = 0;
    for (const [k, w] of READINESS) {
      const val = v[k];
      if (val !== undefined && val !== null && String(val).trim() !== "" && !(k === "valeur" && !(Number(val) > 0))) score += w;
    }
    return score;
  }, [v]);

  const value = Number(v.valeur) > 0 ? Number(v.valeur) : 0;

  const prefill = async () => {
    if (sentence.trim().length < 3) return;
    setExtracting(true);
    try {
      const res = await fetch("/api/brief/extract", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ text: sentence }) });
      const { intent } = (await res.json()) as { intent: BriefIntent };
      const filled = new Set<string>();
      const opts = { shouldDirty: true } as const;
      if (intent.role) {
        setValue("role", intent.role, opts);
        filled.add("role");
      }
      if (isSector(intent.secteur)) {
        setValue("secteur", intent.secteur, opts);
        filled.add("secteur");
      }
      if (intent.produit) {
        setValue("produit", intent.produit, opts);
        filled.add("produit");
      }
      if (isCountry(intent.paysOrigine)) {
        setValue("paysOrigine", intent.paysOrigine, opts);
        filled.add("paysOrigine");
      }
      if (isCountry(intent.paysDestination)) {
        setValue("paysDestination", intent.paysDestination, opts);
        filled.add("paysDestination");
      }
      if (intent.valeur && intent.devise === "USD") {
        setValue("valeur", intent.valeur, opts);
        filled.add("valeur");
      }
      if (intent.quantite) {
        setValue("quantite", intent.quantite, opts);
        filled.add("quantite");
      }
      if (!v.description) {
        setValue("description", sentence.trim(), opts);
        filled.add("description");
      }
      setAiFilled(filled);
      toast.success(filled.size ? `${filled.size} champ${filled.size > 1 ? "s" : ""} pré-rempli${filled.size > 1 ? "s" : ""}. Vérifiez-les.` : "Je n’ai rien pu déduire : complétez le formulaire.");
    } catch {
      toast.error("Pré-remplissage indisponible. Complétez le formulaire.");
    } finally {
      setExtracting(false);
    }
  };

  const onSubmit = handleSubmit(async (data) => {
    try {
      const res = await fetch("/api/brief", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });
      const json = (await res.json()) as { ok: boolean; reference?: string; error?: string };
      if (!res.ok || !json.ok) throw new Error(json.error ?? "Envoi impossible.");
      setSent(json.reference ?? "OK");
      window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Envoi impossible.");
    }
  });

  const hl = (name: string) => (aiFilled.has(name) ? "ring-2 ring-gold ring-offset-2 ring-offset-card transition-shadow" : "transition-shadow");
  const err = (name: keyof typeof errors) =>
    errors[name]?.message ? (
      <p id={`${name}-err`} role="alert" className="mt-1.5 text-sm text-danger">
        {String(errors[name]?.message)}
      </p>
    ) : null;
  const a = (name: keyof typeof errors) => ({ "aria-invalid": errors[name] ? true : undefined, "aria-describedby": errors[name] ? `${name}-err` : undefined });

  if (sent) {
    return (
      <motion.div initial={reduce ? false : { opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-2xl py-6 text-center" role="status">
        <motion.span
          className="mx-auto mb-8 flex h-20 w-20 items-center justify-center rounded-full bg-forest text-white"
          initial={reduce ? false : { scale: 0, rotate: -45 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 240, damping: 15 }}
        >
          <Check className="h-10 w-10" aria-hidden="true" />
        </motion.span>
        <h1 className="mb-3 text-[clamp(30px,4vw,44px)]">Brief reçu.</h1>
        <p className="mb-2 text-lg text-ink-soft">Un agent SANAD le qualifie et vous contacte sous {SITE.responseDelay}.</p>
        <p className="mb-10 text-sm text-ink-soft">
          Référence : <span className="font-mono text-ink">{sent}</span>
        </p>
        <ol className="mb-10 grid gap-3 text-start sm:grid-cols-3">
          {["Qualification par un agent", "Présentation d’une contrepartie", "Fil ouvert, avec un témoin"].map((s, i) => (
            <li key={s} className="card p-4">
              <span className="mb-2 block font-display text-2xl text-gold-read">0{i + 1}</span>
              <span className="text-sm">{s}</span>
            </li>
          ))}
        </ol>
        <div className="flex flex-wrap justify-center gap-3">
          <Link href="/app/transactions" className="btn-primary">
            Mes transactions
          </Link>
          <button
            type="button"
            onClick={() => {
              reset();
              setSentence("");
              setSent(null);
              router.replace("/app/transactions/new");
            }}
            className="btn-outline"
          >
            Nouveau brief
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <form onSubmit={onSubmit} noValidate className="grid items-start gap-6 lg:grid-cols-[1fr_340px]">
      <div className="space-y-6">
        {/* Rôle */}
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-[clamp(30px,4vw,44px)]">{role === "acheteur" ? "Devenir acheteur" : "Devenir exportateur"}</h1>
            <p className="mt-1 text-ink-soft">Un brief clair fait gagner des semaines. Comptez cinq minutes.</p>
          </div>
          <fieldset className={cn("inline-flex rounded-full border border-line bg-card p-1", hl("role"))}>
            <legend className="sr-only">Vous êtes</legend>
            {ROLES.map((r) => (
              <label key={r} className="relative cursor-pointer">
                <input type="radio" value={r} className="peer sr-only" {...register("role")} />
                <span className="relative z-10 inline-flex min-h-10 items-center rounded-full px-4 text-sm font-semibold text-ink-soft transition-colors peer-checked:text-bg peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-forest">
                  {r === "exportateur" ? "Exportateur" : "Acheteur"}
                </span>
                {role === r ? <motion.span layoutId="role-pill" className="absolute inset-0 rounded-full bg-ink" transition={{ type: "spring", stiffness: 400, damping: 34 }} /> : null}
              </label>
            ))}
          </fieldset>
        </div>

        {/* Assistant de pré-remplissage */}
        <section className="on-ink rounded-2xl bg-ink-section p-5 text-bg md:p-6" aria-labelledby="ai-title">
          <h2 id="ai-title" className="mb-1 flex items-center gap-2 font-sans text-base font-semibold text-bg">
            <Sparkles className="h-4 w-4 text-gold" aria-hidden="true" /> Décrivez votre besoin en une phrase
          </h2>
          <p className="mb-4 text-sm text-bg/70">L’assistant remplit le formulaire ; vous vérifiez. Rien n’est envoyé sans votre accord.</p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <label htmlFor="sentence" className="sr-only">
              Votre besoin en une phrase
            </label>
            <textarea
              id="sentence"
              value={sentence}
              onChange={(e) => setSentence(e.target.value)}
              rows={2}
              maxLength={1200}
              placeholder={
                role === "acheteur"
                  ? "Ex. : Je cherche 5 000 tonnes de ciment en Algérie, livrées à Nouakchott, budget 400 000 $."
                  : "Ex. : J’exporte des dattes de Biskra vers le Sénégal, 20 tonnes par mois, environ 60 000 $."
              }
              className="min-h-[56px] flex-1 resize-none rounded-xl border border-line-dark bg-white/[.06] px-4 py-3 text-[15px] text-bg outline-none placeholder:text-bg/45 focus:border-gold"
            />
            <button type="button" onClick={prefill} disabled={extracting || sentence.trim().length < 3} className="btn-gold shrink-0 self-stretch disabled:opacity-60 sm:self-auto">
              {extracting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Wand2 className="h-4 w-4" aria-hidden="true" />}
              Pré-remplir
            </button>
          </div>
        </section>

        {/* Vous */}
        <section className="card p-5 md:p-7" aria-labelledby="vous-title">
          <h2 id="vous-title" className="mb-5 font-sans text-base font-semibold">
            1 · Vous
          </h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="entreprise" className="field-label">
                Société *
              </label>
              <input id="entreprise" autoComplete="organization" className="field" {...register("entreprise")} {...a("entreprise")} />
              {err("entreprise")}
            </div>
            <div>
              <label htmlFor="ville" className="field-label">
                Ville
              </label>
              <input id="ville" autoComplete="address-level2" className="field" {...register("ville")} />
            </div>
          </div>
        </section>

        {/* Marchandise */}
        <section className="card p-5 md:p-7" aria-labelledby="marchandise-title">
          <h2 id="marchandise-title" className="mb-5 font-sans text-base font-semibold">
            2 · La marchandise
          </h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="secteur" className="field-label">
                Secteur *
              </label>
              <select id="secteur" defaultValue="" className={cn("field", hl("secteur"))} {...register("secteur")} {...a("secteur")}>
                <option value="" disabled>
                  Choisir
                </option>
                {SECTORS.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
              {err("secteur")}
            </div>
            <div>
              <label htmlFor="produit" className="field-label">
                Produit *
              </label>
              <input id="produit" className={cn("field", hl("produit"))} placeholder="Ex. : dattes Deglet Nour" {...register("produit")} {...a("produit")} />
              {err("produit")}
            </div>
            <div>
              <label htmlFor="quantite" className="field-label">
                Quantité
              </label>
              <input id="quantite" className={cn("field", hl("quantite"))} placeholder="Ex. : 20 tonnes" {...register("quantite")} />
            </div>
            <div>
              <label htmlFor="codeSH" className="field-label">
                Code SH <span className="font-normal text-ink-soft">(si connu)</span>
              </label>
              <input id="codeSH" inputMode="numeric" className="field" placeholder="Ex. : 0804.10" {...register("codeSH")} {...a("codeSH")} />
              {err("codeSH")}
            </div>
          </div>
        </section>

        {/* Corridor et valeur */}
        <section className="card p-5 md:p-7" aria-labelledby="corridor-title">
          <h2 id="corridor-title" className="mb-5 font-sans text-base font-semibold">
            3 · Le corridor et la valeur
          </h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="paysOrigine" className="field-label">
                Pays d’origine *
              </label>
              <select id="paysOrigine" defaultValue="" className={cn("field", hl("paysOrigine"))} {...register("paysOrigine")} {...a("paysOrigine")}>
                <option value="" disabled>
                  Choisir
                </option>
                {FORM_COUNTRIES.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
              {err("paysOrigine")}
            </div>
            <div>
              <label htmlFor="paysDestination" className="field-label">
                Pays de destination *
              </label>
              <select id="paysDestination" defaultValue="" className={cn("field", hl("paysDestination"))} {...register("paysDestination")} {...a("paysDestination")}>
                <option value="" disabled>
                  Choisir
                </option>
                {FORM_COUNTRIES.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
              {err("paysDestination")}
            </div>
            <div>
              <label htmlFor="valeur" className="field-label">
                Valeur estimée (USD) *
              </label>
              <input id="valeur" type="number" min={0} step={1000} inputMode="numeric" className={cn("field", hl("valeur"))} {...register("valeur")} {...a("valeur")} />
              {err("valeur")}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="incoterm" className="field-label">
                  Incoterm
                </label>
                <select id="incoterm" defaultValue="" className="field" {...register("incoterm")}>
                  <option value="">—</option>
                  {INCOTERMS.map((i) => (
                    <option key={i}>{i}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="delai" className="field-label">
                  Délai
                </label>
                <input id="delai" className="field" placeholder="Ex. : 2 mois" {...register("delai")} />
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="card p-5 md:p-7" aria-labelledby="contact-title">
          <h2 id="contact-title" className="mb-5 font-sans text-base font-semibold">
            4 · Contact et précisions
          </h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="b-email" className="field-label">
                Email *
              </label>
              <input id="b-email" type="email" autoComplete="email" className="field" {...register("email")} {...a("email")} />
              {err("email")}
            </div>
            <div>
              <label htmlFor="b-tel" className="field-label">
                Téléphone / WhatsApp
              </label>
              <input id="b-tel" type="tel" autoComplete="tel" className="field" {...register("telephone")} />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="description" className="field-label">
                Description *
              </label>
              <textarea id="description" rows={4} className={cn("field resize-y", hl("description"))} {...register("description")} {...a("description")} />
              {err("description")}
            </div>
            <div aria-hidden="true" className="absolute -start-[9999px] h-px w-px overflow-hidden">
              <input tabIndex={-1} autoComplete="off" {...register("website")} />
            </div>
            <div className="sm:col-span-2">
              <label className="flex cursor-pointer items-start gap-3 text-sm text-ink-soft">
                <input type="checkbox" className="mt-0.5 h-5 w-5 shrink-0" {...register("consent")} {...a("consent")} />
                J’accepte que WASSALA utilise ces informations pour qualifier ma demande et me présenter des contreparties.
              </label>
              {err("consent")}
            </div>
          </div>
        </section>
      </div>

      {/* Récapitulatif en direct */}
      <aside className="space-y-4 lg:sticky lg:top-4" aria-label="Récapitulatif du brief">
        <div className="card p-5">
          <p className="mb-4 text-xs font-semibold uppercase tracking-[.16em] text-gold-text">Votre brief</p>
          <ScoreBadge score={readiness} label="Complétude" />
          <dl className="mt-5 space-y-2.5 text-sm">
            <div className="flex justify-between gap-3">
              <dt className="text-ink-soft">Rôle</dt>
              <dd className="font-semibold">{role === "acheteur" ? "Acheteur" : "Exportateur"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-ink-soft">Corridor</dt>
              <dd className="text-end font-semibold">
                {v.paysOrigine || "?"} → {v.paysDestination || "?"}
              </dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-ink-soft">Produit</dt>
              <dd className="truncate text-end font-semibold">{v.produit || v.secteur || "?"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-ink-soft">Valeur</dt>
              <dd className="font-semibold">{value ? `${formatAmount(value)} $` : "?"}</dd>
            </div>
            <div className="flex justify-between gap-3">
              <dt className="text-ink-soft">Régime ZLECAf</dt>
              <dd className="text-end font-semibold">{v.codeSH ? "Vérifié par l’agent" : "Selon le code SH"}</dd>
            </div>
          </dl>
        </div>

        <AnimatePresence initial={false}>
          {value ? (
            <motion.div key="money" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="card space-y-4 p-5">
                <div>
                  <p className="mb-1 text-xs font-semibold uppercase tracking-[.16em] text-gold-text">Commission SANAD</p>
                  <p className="text-sm text-ink-soft">
                    {COMMISSION_RATE_MIN} à {COMMISSION_RATE_MAX} % si la transaction aboutit :{" "}
                    <b className="text-ink">
                      {formatAmount((value * COMMISSION_RATE_MIN) / 100)} à {formatAmount((value * COMMISSION_RATE_MAX) / 100)} $
                    </b>
                  </p>
                </div>
                <div>
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[.16em] text-gold-text">
                    <Landmark className="h-3.5 w-3.5" aria-hidden="true" /> AMANA
                  </p>
                  <ul className="space-y-1 text-sm">
                    {AMANA_TRANCHES.map((t) => (
                      <li key={t.event} className="flex justify-between gap-2">
                        <span className="text-ink-soft">
                          {t.pct} % · {t.event.split(" ")[0]}
                        </span>
                        <b>{formatAmount((value * t.pct) / 100)} $</b>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        <div className="rounded-lg border border-gold/70 bg-card p-4 text-sm">
          <p className="mb-1 flex items-center gap-2 font-semibold">
            <ShieldCheck className="h-4 w-4 text-gold-text" aria-hidden="true" /> Vos garanties
          </p>
          <p className="text-ink-soft">Fonds en séquestre chez une banque partenaire, débloqués sur constat d’un témoin. WASSALA ne détient jamais les fonds.</p>
        </div>

        <button type="submit" disabled={isSubmitting} className="btn-primary w-full">
          {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Send className="h-4 w-4 rtl:-scale-x-100" aria-hidden="true" />}
          Envoyer le brief
          <ArrowRight className="h-4 w-4 rtl:-scale-x-100" aria-hidden="true" />
        </button>
      </aside>
    </form>
  );
}
