"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Bell, Sparkles } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { cn, formatAmount } from "@/lib/utils";

/** Appels d'offres ILLUSTRATIFS : à brancher sur une source réelle (portails des marchés publics, chambres de commerce). */
const OFFERS = [
  { id: "v1", title: "[Appel d’offres : fourniture de produits agroalimentaires]", pays: "Sénégal", secteur: "Agroalimentaire", ticket: 100_000, date: "[JJ/MM/AAAA]", score: 84, why: ["Secteur de votre profil", "Corridor déjà couvert", "Ticket dans votre fourchette"] },
  { id: "v2", title: "[Appel d’offres : équipements industriels]", pays: "Nigéria", secteur: "Industrie et équipements", ticket: 250_000, date: "[JJ/MM/AAAA]", score: 67, why: ["Hub partenaire Lagos", "Ticket au-dessus de votre fourchette"] },
  { id: "v3", title: "[Marché public : produits pharmaceutiques]", pays: "Burkina Faso", secteur: "Pharmacie et santé", ticket: 50_000, date: "[JJ/MM/AAAA]", score: 72, why: ["Pays ZLECAf", "Secteur adjacent"] },
  { id: "v4", title: "[Appel d’offres : ciment et matériaux]", pays: "Mauritanie", secteur: "Matériaux et BTP", ticket: 400_000, date: "[JJ/MM/AAAA]", score: 61, why: ["Pays frontalier", "Volume important"] },
] as const;

const FILTERS = ["Tous", "Agroalimentaire", "Industrie et équipements", "Pharmacie et santé", "Matériaux et BTP"] as const;

export function TenderWatch() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("Tous");
  const [open, setOpen] = useState<string | null>(null);
  const list = useMemo(() => OFFERS.filter((o) => filter === "Tous" || o.secteur === filter).sort((a, b) => b.score - a.score), [filter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[clamp(30px,4vw,44px)]">Veille · appels d’offres</h1>
          <p className="mt-1 text-ink-soft">
            Opportunités ZLECAf classées par pertinence pour votre profil. <span className="placeholder-tag">Données illustratives</span>
          </p>
        </div>
        <button type="button" className="btn-outline min-h-10 px-4 text-sm" onClick={() => setOpen("alert")}>
          <Bell className="h-4 w-4" aria-hidden="true" /> Créer une alerte
        </button>
      </div>
      {open === "alert" ? (
        <p role="status" className="rounded-lg border border-gold/70 bg-card px-4 py-3 text-sm">
          Alerte de démonstration créée pour « {filter} ». Les alertes réelles nécessitent une source de données branchée.
        </p>
      ) : null}

      <div className="no-scrollbar flex gap-2 overflow-x-auto" role="group" aria-label="Filtrer par secteur">
        {FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            aria-pressed={filter === f}
            onClick={() => setFilter(f)}
            className={cn("min-h-10 shrink-0 rounded-full border px-4 text-sm font-semibold transition-colors", filter === f ? "border-ink bg-ink text-bg" : "border-line hover:border-gold")}
          >
            {f}
          </button>
        ))}
      </div>

      <motion.ul layout className="space-y-4">
        <AnimatePresence initial={false}>
          {list.map((o) => (
            <motion.li key={o.id} layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.98 }} className="card p-5 md:p-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <h2 className="mb-1 font-sans text-lg font-semibold">{o.title}</h2>
                  <p className="text-sm text-ink-soft">
                    {o.pays} · {o.secteur} · {formatAmount(o.ticket)} $ · publié le {o.date}
                  </p>
                </div>
                <div className="text-end">
                  <p className={cn("font-display text-3xl", o.score >= 75 ? "text-forest" : "text-ink")}>{o.score}</p>
                  <p className="text-xs text-ink-soft">pertinence / 100</p>
                </div>
              </div>
              <div className="mt-4 rounded-lg bg-section p-4 text-sm">
                <p className="mb-2 flex items-center gap-1.5 font-semibold">
                  <Sparkles className="h-4 w-4 text-gold-text" aria-hidden="true" /> Pourquoi cette opportunité
                </p>
                <ul className="flex flex-wrap gap-2">
                  {o.why.map((w) => (
                    <li key={w} className="rounded-full border border-line bg-card px-3 py-1 text-xs">
                      {w}
                    </li>
                  ))}
                </ul>
                <p className="mt-3 text-xs text-ink-soft">[Résumé généré par l’IA à partir du dossier de l’appel d’offres : volume, délais, conditions. À brancher sur la source réelle.]</p>
              </div>
              <Link
                href={`/app/transactions/new?${new URLSearchParams({ role: "exportateur", secteur: o.secteur, destination: o.pays, valeur: String(o.ticket), origine: "Algérie" }).toString()}`}
                className="btn-primary group mt-4 min-h-10 px-5 text-sm"
              >
                Créer un brief
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
              </Link>
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>
    </div>
  );
}
