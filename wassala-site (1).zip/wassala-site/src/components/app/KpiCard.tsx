import { cn } from "@/lib/utils";

interface KpiCardProps {
  label: string;
  value: React.ReactNode;
  sub?: React.ReactNode;
  icon?: React.ComponentType<{ className?: string }>;
  className?: string;
}

export function KpiCard({ label, value, sub, icon: Icon, className }: KpiCardProps) {
  return (
    <div className={cn("card p-5 md:p-6", className)}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-sm text-ink-soft">{label}</p>
        {Icon ? <Icon className="h-4 w-4 text-gold-text" aria-hidden="true" /> : null}
      </div>
      <p className="font-display text-[34px] leading-none text-ink">{value}</p>
      {sub ? <p className="mt-2 text-xs text-ink-soft">{sub}</p> : null}
    </div>
  );
}
