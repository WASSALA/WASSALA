"use client";

import {
  BarChart3,
  BookOpen,
  Building2,
  FileText,
  Home,
  LineChart,
  MessageSquare,
  Plus,
  Settings,
  Shield,
  Smartphone,
  Target,
  Users,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/shared/Logo";
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const GROUPS: ReadonlyArray<{ heading: string; items: readonly NavItem[] }> = [
  {
    heading: "Principal",
    items: [
      { href: "/app", label: "Tableau de bord", icon: Home },
      { href: "/app/transactions", label: "Transactions", icon: FileText },
    ],
  },
  {
    heading: "Intelligence",
    items: [
      { href: "/app/matching", label: "Matching et score", icon: Target },
      { href: "/app/veille", label: "Veille", icon: BarChart3 },
      { href: "/app/coaching", label: "Coaching IA", icon: MessageSquare },
    ],
  },
  {
    heading: "Confiance",
    items: [
      { href: "/app/kyc", label: "KYC / KYB", icon: Shield },
      { href: "/app/deal-house", label: "Deal House", icon: Users },
      { href: "/app/deal-room", label: "Deal Room", icon: BookOpen },
    ],
  },
  {
    heading: "Annuaires",
    items: [
      { href: "/app/annuaire/agents", label: "Agents locaux", icon: Users },
      { href: "/app/annuaire/ambassades", label: "Ambassades", icon: Building2 },
    ],
  },
  {
    heading: "Données",
    items: [{ href: "/app/market-intel", label: "Market Intelligence", icon: LineChart }],
  },
  {
    heading: "Accès",
    items: [
      { href: "/app/offline", label: "Mode SMS / USSD", icon: Smartphone },
      { href: "/app/settings", label: "Réglages", icon: Settings },
    ],
  },
];

export function Sidebar({ onNavigate, className }: { onNavigate?: () => void; className?: string }) {
  const pathname = usePathname();
  const isActive = (href: string) => (href === "/app" ? pathname === href : pathname === href || pathname.startsWith(`${href}/`));

  return (
    <aside className={cn("flex h-full w-64 flex-col border-e border-line bg-bg", className)} aria-label="Navigation de l’application">
      <div className="flex items-center justify-between border-b border-line px-4 py-4">
        <Link href="/app" aria-label="WASSALA, tableau de bord" onClick={onNavigate}>
          <Logo size={30} />
        </Link>
        <span className="rounded-full border border-gold px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[.12em] text-gold-text">SANAD</span>
      </div>
      <div className="px-3 pt-4">
        <Link href="/app/transactions/new" onClick={onNavigate} className="btn-primary min-h-11 w-full justify-start gap-2 px-4 text-sm">
          <Plus className="h-4 w-4" aria-hidden="true" />
          Nouveau brief
        </Link>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {GROUPS.map((g) => (
          <div key={g.heading} className="mb-5">
            <p className="mb-1 px-3 text-[11px] font-semibold uppercase tracking-[.16em] text-gold-text">{g.heading}</p>
            {g.items.map((it) => {
              const active = isActive(it.href);
              return (
                <Link
                  key={it.href}
                  href={it.href}
                  onClick={onNavigate}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "flex min-h-10 items-center gap-3 rounded-md px-3 text-[14.5px] transition-colors",
                    active ? "bg-ink font-semibold text-bg" : "text-ink-soft hover:bg-section hover:text-ink",
                  )}
                >
                  <it.icon className={cn("h-[18px] w-[18px]", active ? "text-gold" : "")} aria-hidden="true" />
                  {it.label}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>
      <div className="border-t border-line px-4 py-3">
        <Link href="/" className="flex min-h-10 items-center justify-between text-sm text-ink-soft hover:text-forest" onClick={onNavigate}>
          Retour au site
          <span aria-hidden="true">↗</span>
        </Link>
      </div>
    </aside>
  );
}
