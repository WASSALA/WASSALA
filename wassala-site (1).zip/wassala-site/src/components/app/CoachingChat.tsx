"use client";

import { RotateCcw, Sparkles } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";
import { ChatComposer } from "@/components/shared/ChatComposer";
import { ChatThread } from "@/components/shared/ChatThread";
import { suggestionsFor } from "@/data/knowledge";
import { useAssistant } from "@/lib/ai/useAssistant";
import { useI18n } from "@/lib/i18n/I18nProvider";

const CONTEXT = "Contexte : je suis dans le module de coaching SANAD, je prépare une mise en relation commerciale.";

/** Coaching à la mise en relation : conversation pleine page avec l'assistant, orientée préparation des échanges. */
export function CoachingChat() {
  const pathname = usePathname();
  const { t, locale } = useI18n();
  const { messages, busy, mode, ask, stop, reset, loadMode } = useAssistant({ storageKey: "wassala-coaching-v1", pathname, locale, context: CONTEXT });
  const listRef = useRef<HTMLDivElement>(null);
  const suggestions = [...suggestionsFor(pathname, 3), { id: "silsila-q", question: "Comment éviter le contournement dans SILSILA ?" }];

  useEffect(() => loadMode(), [loadMode]);
  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  return (
    <div className="flex h-[calc(100dvh-10rem)] flex-col">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[clamp(30px,4vw,44px)]">Coaching IA</h1>
          <p className="mt-1 flex items-center gap-2 text-ink-soft">
            <span className={`h-1.5 w-1.5 rounded-full ${mode === "live" ? "bg-forest" : "bg-gold"}`} aria-hidden="true" />
            Préparez vos échanges : premier message, questions, documents.
          </p>
        </div>
        {messages.length ? (
          <button type="button" onClick={reset} className="btn-outline min-h-10 px-4 text-sm">
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Nouvelle séance
          </button>
        ) : null}
      </div>

      <div className="card flex min-h-0 flex-1 flex-col overflow-hidden">
        <div ref={listRef} className="flex-1 space-y-5 overflow-y-auto p-5 md:p-7" aria-live="polite" aria-busy={busy}>
          {messages.length === 0 ? (
            <div className="mx-auto max-w-xl py-10 text-center">
              <span className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-ink text-gold">
                <Sparkles className="h-6 w-6" aria-hidden="true" />
              </span>
              <p className="mb-2 font-display text-3xl">Par quoi commençons-nous ?</p>
              <p className="text-ink-soft">Choisissez une question ci-dessous ou décrivez la mise en relation que vous préparez.</p>
            </div>
          ) : null}
          <ChatThread messages={messages} thinkingLabel={t.assistant.thinking} />
        </div>
        <div className="border-t border-line p-4">
          {!busy ? (
            <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto">
              {suggestions.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => void ask(s.question)}
                  className="min-h-9 shrink-0 rounded-full border border-line bg-bg px-3.5 text-[13px] text-ink-soft transition-colors hover:border-gold hover:text-ink"
                >
                  {s.question}
                </button>
              ))}
            </div>
          ) : null}
          <ChatComposer id="coach-input" busy={busy} placeholder={t.assistant.placeholder} sendLabel={t.assistant.send} stopLabel={t.assistant.stop} onSend={(x) => void ask(x)} onStop={stop} />
          <p className="mt-2 text-center text-[11px] text-ink-soft">{t.assistant.disclaimer}</p>
        </div>
      </div>
    </div>
  );
}
