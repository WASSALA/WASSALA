"use client";

import { Check, Landmark } from "lucide-react";
import { useState } from "react";
import { AMANA_TRANCHES } from "@/lib/sanad/commission";
import { cn, formatAmount } from "@/lib/utils";

const WITNESS = ["Inspection constatée par CHAHID", "Chargement ou frontière constatés", "Réception confirmée par l’acheteur"] as const;

/** AMANA : les trois tranches du séquestre. « Constater » est une action de démonstration. */
export function EscrowTranches({ valeur, devise = "USD", initiallyDone = 0 }: { valeur: number; devise?: string; initiallyDone?: number }) {
  const [done, setDone] = useState(initiallyDone);
  const released = AMANA_TRANCHES.slice(0, done).reduce((a, t) => a + (valeur * t.pct) / 100, 0);
  return (
    <div>
      <div className="mb-1 flex items-center gap-2">
        <Landmark className="h-4 w-4 text-gold-text" aria-hidden="true" />
        <h2 className="font-sans text-base font-semibold">AMANA · séquestre à étapes</h2>
      </div>
      <p className="mb-5 text-sm text-ink-soft">Les fonds sont chez la banque partenaire. WASSALA ne détient jamais les fonds.</p>
      <div className="mb-5 flex h-3 overflow-hidden rounded-full bg-ink/10" aria-hidden="true">
        {AMANA_TRANCHES.map((t, i) => (
          <span key={t.event} className={cn("h-full border-e-2 border-bg transition-colors duration-500 last:border-0", i < done ? "bg-forest" : "bg-transparent")} style={{ width: `${t.pct}%` }} />
        ))}
      </div>
      <ol className="space-y-2.5">
        {AMANA_TRANCHES.map((t, i) => {
          const isDone = i < done;
          const isNext = i === done;
          return (
            <li key={t.event} className={cn("flex items-center justify-between gap-4 rounded-lg border p-3.5 transition-colors", isDone ? "border-forest/50 bg-forest/5" : "border-line")}>
              <div className="min-w-0">
                <p className="text-sm font-semibold">
                  Tranche {i + 1} · {t.pct} %
                </p>
                <p className="truncate text-xs text-ink-soft">{WITNESS[i]}</p>
              </div>
              <div className="shrink-0 text-end">
                <p className="text-sm font-semibold">
                  {formatAmount((valeur * t.pct) / 100)} {devise}
                </p>
                {isDone ? (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-forest">
                    <Check className="h-3.5 w-3.5" aria-hidden="true" /> Débloquée
                  </span>
                ) : isNext ? (
                  <button type="button" onClick={() => setDone((d) => d + 1)} className="text-xs font-semibold text-forest underline-offset-2 hover:underline">
                    Constater (démo)
                  </button>
                ) : (
                  <span className="text-xs text-ink-soft">En attente</span>
                )}
              </div>
            </li>
          );
        })}
      </ol>
      <p className="mt-4 text-sm" aria-live="polite">
        Débloqué : <b>{formatAmount(released)} {devise}</b> sur {formatAmount(valeur)} {devise}
      </p>
    </div>
  );
}
