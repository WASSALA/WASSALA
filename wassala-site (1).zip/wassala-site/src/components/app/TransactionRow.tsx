import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { TRANSACTION_STATUSES, type Transaction, type TransactionStatus } from "@/lib/api/types";
import { computeCommission } from "@/lib/sanad/commission";
import { cn, formatAmount } from "@/lib/utils";

const STATUS_COLORS: Record<TransactionStatus, string> = {
  brief: "bg-ink/10 text-ink-soft",
  qualification: "bg-gold/25 text-gold-text",
  presentation: "bg-gold/35 text-gold-text",
  rencontre: "bg-forest/10 text-forest",
  negociation: "bg-forest/20 text-forest-dark",
  accord: "bg-forest text-white",
  commission: "bg-ink text-gold",
};

export function StatusBadge({ status }: { status: TransactionStatus }) {
  const label = TRANSACTION_STATUSES.find((s) => s.id === status)?.label ?? status;
  return <span className={cn("inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", STATUS_COLORS[status])}>{label}</span>;
}

export function TransactionTable({ rows }: { rows: readonly Transaction[] }) {
  return (
    <div className="card overflow-x-auto">
      <table className="w-full min-w-[820px] text-start text-sm">
        <thead className="border-b border-line bg-section/70 text-[11px] font-semibold uppercase tracking-[.12em] text-ink-soft">
          <tr>
            {["Référence", "Corridor", "Secteur", "Valeur", "Commission", "Statut", "Prochaine action", ""].map((h) => (
              <th key={h || "actions"} scope="col" className="px-4 py-3 text-start">
                {h ? h : <span className="sr-only">Actions</span>}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((tx) => (
            <TransactionRow key={tx.id} tx={tx} />
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function TransactionRow({ tx }: { tx: Transaction }) {
  const c = computeCommission(tx.valeur, tx.taux);
  return (
    <tr className="group border-b border-line transition-colors last:border-0 hover:bg-section/50">
      <td className="px-4 py-4 font-mono text-[13px]">{tx.ref}</td>
      <td className="px-4 py-4">{tx.corridor}</td>
      <td className="px-4 py-4 text-ink-soft">{tx.secteur}</td>
      <td className="px-4 py-4 font-semibold">
        {formatAmount(tx.valeur)} {tx.devise}
      </td>
      <td className="px-4 py-4 text-ink-soft">
        {formatAmount(c.total)} {tx.devise} <span className="text-xs">({tx.taux.toLocaleString("fr-FR")} %)</span>
      </td>
      <td className="px-4 py-4">
        <StatusBadge status={tx.status} />
      </td>
      <td className="px-4 py-4 text-ink-soft">{tx.nextAction}</td>
      <td className="px-4 py-4 text-end">
        <Link href={`/app/transactions/${tx.id}`} className="inline-flex min-h-10 items-center gap-1 rounded-md px-2 font-semibold text-forest hover:bg-forest/10" aria-label={`Ouvrir ${tx.ref}`}>
          Ouvrir
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 rtl:-scale-x-100" aria-hidden="true" />
        </Link>
      </td>
    </tr>
  );
}
