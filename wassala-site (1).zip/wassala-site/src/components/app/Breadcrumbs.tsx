"use client";

import { ChevronRight } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { getTransaction } from "@/lib/api/mock";

const LABELS: Record<string, string> = {
  app: "Espace SANAD",
  transactions: "Transactions",
  new: "Nouveau brief",
  matching: "Matching et score",
  veille: "Veille",
  coaching: "Coaching IA",
  kyc: "KYC / KYB",
  "deal-house": "Deal House",
  "deal-room": "Deal Room",
  annuaire: "Annuaires",
  agents: "Agents locaux",
  ambassades: "Ambassades",
  "market-intel": "Market Intelligence",
  offline: "Mode SMS / USSD",
  settings: "Réglages",
};

/** Fil d'Ariane de l'application, déduit de l'URL. */
export function Breadcrumbs() {
  const pathname = usePathname();
  const parts = pathname.split("/").filter(Boolean);
  const crumbs = parts.map((p, i) => {
    const href = `/${parts.slice(0, i + 1).join("/")}`;
    const label = LABELS[p] ?? getTransaction(p)?.ref ?? p;
    return { href, label, clickable: p !== "annuaire" };
  });
  return (
    <nav aria-label="Fil d’Ariane" className="min-w-0">
      <ol className="flex items-center gap-1.5 overflow-hidden text-sm text-ink-soft">
        {crumbs.map((c, i) => {
          const last = i === crumbs.length - 1;
          return (
            <li key={c.href} className={`flex min-w-0 items-center gap-1.5 ${i < crumbs.length - 2 ? "max-sm:hidden" : ""}`}>
              {i > 0 ? <ChevronRight className="h-3.5 w-3.5 shrink-0 rtl:-scale-x-100" aria-hidden="true" /> : null}
              {last || !c.clickable ? (
                <span aria-current={last ? "page" : undefined} className={`truncate ${last ? "font-semibold text-ink" : ""}`}>
                  {c.label}
                </span>
              ) : (
                <Link href={c.href} className="truncate hover:text-forest">
                  {c.label}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
