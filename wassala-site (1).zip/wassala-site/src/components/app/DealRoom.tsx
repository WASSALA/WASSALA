"use client";

import { Download, FileText, Lock, Upload } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { MOCK_TRANSACTIONS } from "@/lib/api/mock";

const DOCS = [
  { id: "d1", nom: "Contrat-type_v3.pdf", date: "22/10 · 10:42", role: "Vendeur", statut: "Signé" },
  { id: "d2", nom: "Facture_proforma.pdf", date: "22/10 · 08:30", role: "Agent SANAD", statut: "Validé" },
  { id: "d3", nom: "Certificat_origine_ZLECAf.pdf", date: "19/10 · 15:05", role: "Témoin CHAHID", statut: "Vérifié par CHAHID" },
] as const;

/** Deal Room : documents confidentiels filigranés et journal des accès (démonstration). */
export function DealRoom() {
  const [tx, setTx] = useState(MOCK_TRANSACTIONS[0]!.id);
  const [log, setLog] = useState([
    { at: "22/10 · 10:42", action: "Contrat-type_v3.pdf téléversé", who: "Vendeur" },
    { at: "22/10 · 08:30", action: "Facture proforma validée", who: "Agent SANAD" },
    { at: "19/10 · 15:05", action: "Certificat d’origine vérifié", who: "Témoin CHAHID" },
    { at: "18/10 · 09:00", action: "Deal Room ouverte", who: "WASSALA" },
  ]);
  const current = MOCK_TRANSACTIONS.find((t) => t.id === tx)!;
  const stamp = () => new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date()).replace(" ", " · ");

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[clamp(30px,4vw,44px)]">Deal Room</h1>
          <p className="mt-1 flex items-center gap-2 text-ink-soft">
            <Lock className="h-4 w-4 text-gold-text" aria-hidden="true" /> Chaque accès est journalisé. Les documents portent un filigrane nominatif.
          </p>
        </div>
        <div>
          <label htmlFor="dr-tx" className="sr-only">
            Transaction
          </label>
          <select id="dr-tx" value={tx} onChange={(e) => setTx(e.target.value)} className="field min-w-[260px]">
            {MOCK_TRANSACTIONS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.ref} · {t.corridor}
              </option>
            ))}
          </select>
        </div>
      </div>

      <section className="card overflow-hidden" aria-labelledby="docs-title">
        <div className="flex items-center justify-between border-b border-line bg-section/70 px-5 py-3">
          <h2 id="docs-title" className="font-sans text-base font-semibold">
            Documents · {current.ref}
          </h2>
          <span className="rounded border border-gold px-2 py-0.5 text-[11px] font-semibold uppercase tracking-[.12em] text-gold-text">Confidentiel</span>
        </div>
        <ul className="watermark-confidential divide-y divide-line">
          {DOCS.map((d) => (
            <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <div className="flex min-w-0 items-center gap-3">
                <FileText className="h-5 w-5 shrink-0 text-gold-text" aria-hidden="true" />
                <div className="min-w-0">
                  <p className="truncate font-semibold">{d.nom}</p>
                  <p className="text-sm text-ink-soft">
                    {d.role} · {d.date}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold text-forest">{d.statut}</span>
                <button
                  type="button"
                  onClick={() => {
                    setLog((l) => [{ at: stamp(), action: `${d.nom} consulté`, who: "Vous" }, ...l]);
                    toast("Téléchargement de démonstration : accès ajouté au journal.");
                  }}
                  className="inline-flex min-h-10 items-center gap-1.5 rounded-md border border-line px-3 text-sm hover:border-gold"
                >
                  <Download className="h-4 w-4" aria-hidden="true" /> Télécharger
                </button>
              </div>
            </li>
          ))}
        </ul>
        <div className="border-t border-line px-5 py-4">
          <label htmlFor="dr-file" className="mb-2 block text-sm font-semibold">
            Ajouter un document
          </label>
          <div className="flex flex-wrap items-center gap-3">
            <input
              id="dr-file"
              type="file"
              accept=".pdf"
              className="text-sm text-ink-soft file:me-3 file:min-h-10 file:rounded-md file:border file:border-line file:bg-section file:px-3 file:font-semibold"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setLog((l) => [{ at: stamp(), action: `${f.name} téléversé (démonstration)`, who: "Vous" }, ...l]);
                  toast.success("Ajouté au journal (démonstration : le fichier n’est pas envoyé).");
                }
              }}
            />
            <Upload className="h-4 w-4 text-ink-soft" aria-hidden="true" />
          </div>
          <p className="mt-2 text-xs text-ink-soft">SANAD ne délivre jamais le certificat d’origine ZLECAf : prérogative des autorités nationales.</p>
        </div>
      </section>

      <section className="card p-5" aria-labelledby="log-title">
        <h2 id="log-title" className="mb-4 font-sans text-base font-semibold">
          Journal des accès et modifications
        </h2>
        <ol className="space-y-2 text-sm" aria-live="polite">
          {log.map((l, i) => (
            <li key={`${l.at}-${i}`} className="flex flex-wrap gap-x-4 border-b border-line pb-2 last:border-0">
              <span className="w-28 shrink-0 font-mono text-ink-soft">{l.at}</span>
              <span className="flex-1">{l.action}</span>
              <span className="text-ink-soft">{l.who}</span>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
