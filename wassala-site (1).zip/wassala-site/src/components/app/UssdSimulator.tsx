"use client";

import { Delete, Phone, PhoneOff } from "lucide-react";
import { useMemo, useState } from "react";
import { describeIntent, detectIntent, isBriefIntent } from "@/lib/ai/intent";
import { cn } from "@/lib/utils";

type Screen = "idle" | "menu" | "secteur" | "pays" | "valeur" | "ok" | "statut" | "agent" | "bye";

const SECTEURS = ["Agroalimentaire", "Matériaux et BTP", "Pharmacie et santé", "Autre"] as const;
const PAYS = ["Mauritanie", "Sénégal", "Mali", "Niger"] as const;

/** Simulation d'un parcours USSD : brief, statut et rappel, sans données mobiles. */
export function UssdSimulator() {
  const [screen, setScreen] = useState<Screen>("idle");
  const [input, setInput] = useState("");
  const [brief, setBrief] = useState<{ secteur?: string; pays?: string; valeur?: string }>({});
  const [ref] = useState(() => `BRF-${Math.random().toString(36).slice(2, 6).toUpperCase()}`);

  const text: Record<Screen, string> = {
    idle: "Composez *XXX# puis appuyez sur Appeler.\n\n[Code USSD à attribuer par l’opérateur]",
    menu: "WASSALA SANAD\n1. Nouveau brief\n2. Statut de ma transaction\n3. Être rappelé par mon agent\n0. Quitter",
    secteur: `Secteur ?\n${SECTEURS.map((s, i) => `${i + 1}. ${s}`).join("\n")}`,
    pays: `Pays de destination ?\n${PAYS.map((p, i) => `${i + 1}. ${p}`).join("\n")}`,
    valeur: "Valeur estimée en USD ?\nTapez le montant puis Envoyer.",
    ok: `Brief enregistré.\nRéf. ${ref}\n${brief.secteur ?? ""} → ${brief.pays ?? ""}\n${brief.valeur ?? ""} USD\nUn agent vous rappelle.`,
    statut: "TX-2026-0142\nÉtape : Négociation\nProchaine action : valider la facture proforma.\n\n0. Menu",
    agent: "Demande enregistrée.\nVotre agent vous rappelle.\n[Délai à préciser]\n\n0. Menu",
    bye: "Merci. À bientôt.",
  };

  const send = () => {
    const v = input.trim();
    setInput("");
    if (screen === "menu") setScreen(v === "1" ? "secteur" : v === "2" ? "statut" : v === "3" ? "agent" : v === "0" ? "bye" : "menu");
    else if (screen === "secteur") {
      const s = SECTEURS[Number(v) - 1];
      if (s) {
        setBrief((b) => ({ ...b, secteur: s }));
        setScreen("pays");
      }
    } else if (screen === "pays") {
      const p = PAYS[Number(v) - 1];
      if (p) {
        setBrief((b) => ({ ...b, pays: p }));
        setScreen("valeur");
      }
    } else if (screen === "valeur") {
      if (/^\d{3,9}$/.test(v)) {
        setBrief((b) => ({ ...b, valeur: new Intl.NumberFormat("fr-FR").format(Number(v)) }));
        setScreen("ok");
      }
    } else if (screen === "statut" || screen === "agent") {
      if (v === "0") setScreen("menu");
    }
  };

  const active = screen !== "idle" && screen !== "bye";
  return (
    <div className="mx-auto w-[300px] rounded-[42px] border-[10px] border-ink bg-ink p-1 shadow-lift">
      <div className="rounded-[30px] bg-[#0d1f16] px-5 pb-6 pt-8">
        <div className="mb-4 min-h-[210px] whitespace-pre-line rounded-xl bg-[#c9dcc7] p-4 font-mono text-[13px] leading-relaxed text-[#10261B]" aria-live="polite">
          {text[screen]}
          {active && screen !== "ok" ? (
            <p className="mt-2 border-t border-[#10261B]/30 pt-2">
              &gt; {input}
              <span className="animate-blink">▌</span>
            </p>
          ) : null}
        </div>
        <div className="grid grid-cols-3 gap-2" role="group" aria-label="Clavier">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setInput((s) => (s.length < 12 ? s + k : s))}
              className="h-11 rounded-xl bg-white/10 font-mono text-lg text-bg transition-colors hover:bg-white/20 active:bg-white/30"
            >
              {k}
            </button>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <button
            type="button"
            aria-label={active ? "Envoyer" : "Appeler"}
            onClick={() => (active ? send() : (setScreen("menu"), setInput("")))}
            className="flex h-11 items-center justify-center rounded-xl bg-forest text-white hover:bg-forest-dark"
          >
            {active ? <span className="text-sm font-semibold">OK</span> : <Phone className="h-5 w-5" aria-hidden="true" />}
          </button>
          <button type="button" aria-label="Effacer" onClick={() => setInput((s) => s.slice(0, -1))} className="flex h-11 items-center justify-center rounded-xl bg-white/10 text-bg hover:bg-white/20">
            <Delete className="h-5 w-5" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label="Raccrocher"
            onClick={() => {
              setScreen("idle");
              setInput("");
              setBrief({});
            }}
            className="flex h-11 items-center justify-center rounded-xl bg-danger text-white hover:opacity-90"
          >
            <PhoneOff className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}

/** Brief par SMS : l'IA comprend un message libre et en tire un brief structuré. */
export function SmsBrief() {
  const [sms, setSms] = useState("BRIEF ciment vers Nouakchott 400000 $");
  const intent = useMemo(() => detectIntent(sms), [sms]);
  return (
    <div className="card p-5 md:p-6">
      <h2 className="mb-1 font-sans text-base font-semibold">Brief par SMS</h2>
      <p className="mb-4 text-sm text-ink-soft">Écrivez librement : l’assistant en déduit un brief. <span className="placeholder-tag">Numéro court à préciser</span></p>
      <label htmlFor="sms" className="sr-only">
        Message SMS
      </label>
      <textarea id="sms" rows={3} maxLength={160} value={sms} onChange={(e) => setSms(e.target.value)} className="field resize-none font-mono text-sm" />
      <p className="mt-1 text-end text-xs text-ink-soft">{sms.length}/160</p>
      <div className={cn("mt-3 rounded-lg p-4 text-sm", isBriefIntent(intent) ? "bg-forest/10" : "bg-section")} aria-live="polite">
        <p className="mb-1 font-semibold">{isBriefIntent(intent) ? "Brief compris" : "Encore un peu vague"}</p>
        <p className="text-ink-soft">{describeIntent(intent) || "Indiquez au moins un produit et un pays."}</p>
      </div>
    </div>
  );
}
