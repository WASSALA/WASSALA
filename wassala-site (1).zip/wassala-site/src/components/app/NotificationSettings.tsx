"use client";

import { useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const ITEMS = [
  { id: "step", label: "Nouvelle étape sur une transaction", hint: "Qualification, présentation, accord…" },
  { id: "doc", label: "Document ajouté en Deal Room", hint: "Avec le nom de l’auteur." },
  { id: "amana", label: "Tranche AMANA débloquée", hint: "Après constat du témoin." },
  { id: "veille", label: "Nouvel appel d’offres pertinent", hint: "Score de pertinence supérieur à 75." },
] as const;

/** Préférences de notification (démonstration : conservées dans l'onglet). */
export function NotificationSettings() {
  const [on, setOn] = useState<Record<string, boolean>>({ step: true, doc: true, amana: true, veille: false });
  return (
    <section className="card p-5 md:p-6" aria-labelledby="notif-title">
      <h2 id="notif-title" className="mb-4 font-sans text-base font-semibold">
        Notifications
      </h2>
      <ul className="divide-y divide-line">
        {ITEMS.map((it) => {
          const checked = !!on[it.id];
          return (
            <li key={it.id} className="flex items-center justify-between gap-4 py-3">
              <div>
                <p id={`n-${it.id}`} className="text-sm font-semibold">
                  {it.label}
                </p>
                <p className="text-xs text-ink-soft">{it.hint}</p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={checked}
                aria-labelledby={`n-${it.id}`}
                onClick={() => {
                  setOn((s) => ({ ...s, [it.id]: !checked }));
                  toast(`${it.label} : ${checked ? "désactivé" : "activé"}`);
                }}
                className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", checked ? "bg-forest" : "bg-ink/20")}
              >
                <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-[inset-inline-start] duration-300 ease-brand", checked ? "start-6" : "start-1")} />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
