"use client";

import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatAmount } from "@/lib/utils";

/** Données ILLUSTRATIVES : à remplacer par l'agrégation des transactions réelles. */
const MONTHLY = [
  { mois: "Mai", deals: 3, valeur: 180_000 },
  { mois: "Juin", deals: 4, valeur: 240_000 },
  { mois: "Juil.", deals: 4, valeur: 260_000 },
  { mois: "Août", deals: 6, valeur: 390_000 },
  { mois: "Sept.", deals: 9, valeur: 570_000 },
  { mois: "Oct.", deals: 7, valeur: 460_000 },
];
const SECTORS = [
  { secteur: "Agroalimentaire", ticket: 62_000 },
  { secteur: "Pharmacie", ticket: 95_000 },
  { secteur: "Industrie", ticket: 78_000 },
  { secteur: "Matériaux", ticket: 130_000 },
];
const CORRIDORS = [
  { c: "Algérie → Mauritanie", tag: "Actif", delai: "[à documenter]", share: 34 },
  { c: "Algérie → Sénégal", tag: "Actif", delai: "[à documenter]", share: 26 },
  { c: "Algérie → Niger", tag: "En croissance", delai: "[à documenter]", share: 18 },
  { c: "Algérie → Nigéria", tag: "En croissance", delai: "[à documenter]", share: 14 },
  { c: "Algérie → Mali", tag: "Émergent", delai: "[à documenter]", share: 8 },
];

const AXIS = { fontSize: 12, fill: "#51675A" } as const;
const tooltipStyle = { borderRadius: 10, border: "1px solid rgba(16,38,27,.14)", background: "#F8FBF5", fontSize: 13 } as const;

export function MarketIntel() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Market Intelligence</h1>
        <p className="mt-1 text-ink-soft">
          Corridors, volumes, tickets moyens. <span className="placeholder-tag">Données illustratives</span>
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="card p-5 md:p-6" aria-labelledby="mi-deals">
          <h2 id="mi-deals" className="mb-4 font-sans text-base font-semibold">
            Transactions par mois
          </h2>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MONTHLY} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="rgba(16,38,27,.08)" />
                <XAxis dataKey="mois" tick={AXIS} axisLine={false} tickLine={false} />
                <YAxis tick={AXIS} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(227,182,91,.15)" }} />
                <Bar dataKey="deals" name="Transactions" fill="#1F7A4D" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card p-5 md:p-6" aria-labelledby="mi-value">
          <h2 id="mi-value" className="mb-4 font-sans text-base font-semibold">
            Valeur traitée (USD)
          </h2>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MONTHLY} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
                <defs>
                  <linearGradient id="mi-gold" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0" stopColor="#E3B65B" stopOpacity={0.5} />
                    <stop offset="1" stopColor="#E3B65B" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="rgba(16,38,27,.08)" />
                <XAxis dataKey="mois" tick={AXIS} axisLine={false} tickLine={false} />
                <YAxis tick={AXIS} axisLine={false} tickLine={false} tickFormatter={(v) => `${Number(v) / 1000}k`} width={44} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v) => `${formatAmount(Number(v))} $`} />
                <Area type="monotone" dataKey="valeur" name="Valeur" stroke="#C9963A" strokeWidth={2} fill="url(#mi-gold)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card p-5 md:p-6" aria-labelledby="mi-ticket">
          <h2 id="mi-ticket" className="mb-4 font-sans text-base font-semibold">
            Ticket moyen par secteur
          </h2>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={SECTORS} layout="vertical" margin={{ top: 0, right: 8, left: 8, bottom: 0 }}>
                <CartesianGrid horizontal={false} stroke="rgba(16,38,27,.08)" />
                <XAxis type="number" tick={AXIS} axisLine={false} tickLine={false} tickFormatter={(v) => `${Number(v) / 1000}k`} />
                <YAxis type="category" dataKey="secteur" tick={AXIS} axisLine={false} tickLine={false} width={110} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v) => `${formatAmount(Number(v))} $`} cursor={{ fill: "rgba(227,182,91,.15)" }} />
                <Bar dataKey="ticket" name="Ticket moyen" fill="#155F3B" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="card p-5 md:p-6" aria-labelledby="mi-corridors">
          <h2 id="mi-corridors" className="mb-4 font-sans text-base font-semibold">
            Corridors actifs
          </h2>
          <ul className="space-y-3">
            {CORRIDORS.map((c) => (
              <li key={c.c}>
                <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                  <span className="font-semibold">{c.c}</span>
                  <span className="rounded-full bg-section px-2 py-0.5 text-xs text-ink-soft">{c.tag}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-ink/10">
                  <div className="h-full origin-left rounded-full bg-gold" style={{ width: `${c.share}%`, animation: "score-grow 1.2s cubic-bezier(.2,.7,.2,1) both" }} />
                </div>
                <p className="mt-1 text-xs text-ink-soft">
                  {c.share} % des transactions · délai moyen {c.delai}
                </p>
              </li>
            ))}
          </ul>
        </section>
      </div>
      <p className="text-sm text-ink-soft">
        À terme, ces tableaux s’alimentent des cartes de frictions de corridor documentées par les témoins CHAHID : coûts réels, délais, obstacles.
      </p>
    </div>
  );
}
