"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Menu, Sparkles, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { MOCK_USER } from "@/lib/api/mock";
import { askAssistant, openPalette } from "@/lib/events";
import { Breadcrumbs } from "./Breadcrumbs";
import { Sidebar } from "./Sidebar";

/** Coquille de l'application SANAD : barre latérale (tiroir sur mobile), barre du haut, contenu. */
export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const reduce = useReducedMotion();
  const [drawer, setDrawer] = useState(false);

  useEffect(() => setDrawer(false), [pathname]);
  useEffect(() => {
    if (!drawer) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setDrawer(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawer]);

  const initials = MOCK_USER.nom.replace(/[[\]]/g, "").split(" ").map((w) => w[0]).join("").slice(0, 2) || "?";

  return (
    <div className="flex h-dvh overflow-hidden">
      <a href="#app-main" className="skip-link">
        Aller au contenu
      </a>
      <Sidebar className="hidden lg:flex" />

      <AnimatePresence>
        {drawer ? (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-ink/40 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDrawer(false)}
              aria-hidden="true"
            />
            <motion.div
              className="fixed inset-y-0 start-0 z-50 lg:hidden"
              initial={reduce ? { opacity: 0 } : { x: "-100%" }}
              animate={reduce ? { opacity: 1 } : { x: 0 }}
              exit={reduce ? { opacity: 0 } : { x: "-100%" }}
              transition={{ duration: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
              role="dialog"
              aria-label="Menu de l’application"
            >
              <Sidebar onNavigate={() => setDrawer(false)} className="shadow-lift" />
              <button
                type="button"
                onClick={() => setDrawer(false)}
                className="absolute end-[-52px] top-3 inline-flex h-11 w-11 items-center justify-center rounded-md bg-bg"
                aria-label="Fermer le menu"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </motion.div>
          </>
        ) : null}
      </AnimatePresence>

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <header className="flex h-16 shrink-0 items-center gap-3 border-b border-line bg-bg/95 px-4 backdrop-blur md:px-6">
          <button
            type="button"
            onClick={() => setDrawer(true)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-line lg:hidden"
            aria-label="Ouvrir le menu"
            aria-expanded={drawer}
          >
            <Menu className="h-5 w-5" aria-hidden="true" />
          </button>
          <div className="min-w-0 flex-1">
            <Breadcrumbs />
          </div>
          <span className="hidden rounded-full border border-dashed border-gold-read/60 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[.1em] text-gold-text md:inline">
            Démonstration · données fictives
          </span>
          <button
            type="button"
            onClick={openPalette}
            className="hidden min-h-10 items-center gap-2 rounded-full border border-line px-3 text-sm text-ink-soft hover:border-gold hover:text-ink sm:inline-flex"
          >
            <Sparkles className="h-4 w-4 text-gold-text" aria-hidden="true" />
            Rechercher
            <kbd className="rounded border border-line px-1 text-[10px]">⌘K</kbd>
          </button>
          <button
            type="button"
            onClick={() => askAssistant()}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-ink text-gold sm:hidden"
            aria-label="Ouvrir l’assistant"
          >
            <Sparkles className="h-4 w-4" aria-hidden="true" />
          </button>
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gold/25 text-sm font-semibold text-gold-text" title={MOCK_USER.nom}>
            {initials}
          </span>
        </header>
        <main id="app-main" tabIndex={-1} className="flex-1 overflow-y-auto px-4 py-6 outline-none md:px-8 md:py-8">
          <div className="mx-auto max-w-6xl">{children}</div>
        </main>
      </div>
    </div>
  );
}
