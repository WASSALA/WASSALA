"use client";

import { BadgeCheck, MapPin, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { MOCK_AGENTS, MOCK_AMBASSADES } from "@/lib/api/mock";
import { cn, normalize } from "@/lib/utils";

/** Annuaire des agents locaux (témoins CHAHID potentiels) : recherche, filtre par spécialité, vérifiés seulement. */
export function AgentsDirectory() {
  const [q, setQ] = useState("");
  const [spec, setSpec] = useState("Toutes");
  const [onlyVerified, setOnlyVerified] = useState(false);
  const specs = useMemo(() => ["Toutes", ...Array.from(new Set(MOCK_AGENTS.flatMap((a) => a.specialites)))], []);
  const list = MOCK_AGENTS.filter(
    (a) =>
      (spec === "Toutes" || a.specialites.includes(spec)) &&
      (!onlyVerified || a.verifie) &&
      (!q || normalize(`${a.ville} ${a.pays} ${a.specialites.join(" ")}`).includes(normalize(q))),
  );
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" aria-hidden="true" />
          <label htmlFor="ag-q" className="sr-only">
            Rechercher une ville ou un pays
          </label>
          <input id="ag-q" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ville, pays…" className="field ps-10" />
        </div>
        <label htmlFor="ag-spec" className="sr-only">
          Spécialité
        </label>
        <select id="ag-spec" value={spec} onChange={(e) => setSpec(e.target.value)} className="field w-auto">
          {specs.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <label className="flex min-h-12 cursor-pointer items-center gap-2 rounded-md border border-line px-3 text-sm">
          <input type="checkbox" checked={onlyVerified} onChange={(e) => setOnlyVerified(e.target.checked)} className="h-4 w-4" />
          Vérifiés uniquement
        </label>
      </div>
      <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((a) => (
          <li key={a.id} className="card card-lift flex flex-col p-5">
            <div className="mb-2 flex items-start justify-between gap-3">
              <p className="font-semibold">
                {a.prenom} {a.nom}
              </p>
              {a.verifie ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-forest/10 px-2.5 py-0.5 text-xs font-semibold text-forest">
                  <BadgeCheck className="h-3.5 w-3.5" aria-hidden="true" /> Vérifié
                </span>
              ) : (
                <span className="rounded-full bg-ink/10 px-2.5 py-0.5 text-xs text-ink-soft">En cours</span>
              )}
            </div>
            <p className="mb-3 flex items-center gap-1.5 text-sm text-ink-soft">
              <MapPin className="h-3.5 w-3.5" aria-hidden="true" /> {a.ville}, {a.pays}
            </p>
            <ul className="mb-4 flex flex-wrap gap-1.5">
              {a.specialites.map((s) => (
                <li key={s} className="rounded-full border border-line px-2.5 py-0.5 text-xs">
                  {s}
                </li>
              ))}
            </ul>
            <button type="button" onClick={() => toast("Demande de mission envoyée (démonstration).")} className="btn-outline mt-auto min-h-10 text-sm">
              Proposer une mission
            </button>
          </li>
        ))}
      </ul>
      {list.length === 0 ? <p className="card p-6 text-center text-ink-soft">Aucun agent ne correspond.</p> : null}
    </div>
  );
}

export function EmbassiesDirectory() {
  const [q, setQ] = useState("");
  const list = MOCK_AMBASSADES.filter((a) => !q || normalize(`${a.pays} ${a.ville}`).includes(normalize(q)));
  return (
    <div className="space-y-5">
      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" aria-hidden="true" />
        <label htmlFor="amb-q" className="sr-only">
          Rechercher un pays
        </label>
        <input id="amb-q" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pays, ville…" className="field ps-10" />
      </div>
      <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((a) => (
          <li key={a.id} className="card p-5">
            <p className="text-lg font-semibold">{a.pays}</p>
            <p className="mb-4 text-sm text-ink-soft">{a.ville}</p>
            <dl className="mb-4 space-y-2 text-sm">
              <div>
                <dt className="font-semibold">Adresse</dt>
                <dd className={cn(a.adresse.startsWith("[") ? "text-gold-text" : "text-ink-soft")}>{a.adresse}</dd>
              </div>
              <div>
                <dt className="font-semibold">Horaires</dt>
                <dd className={cn(a.horaires.startsWith("[") ? "text-gold-text" : "text-ink-soft")}>{a.horaires}</dd>
              </div>
            </dl>
            <ul className="flex flex-wrap gap-1.5">
              {a.services.map((s) => (
                <li key={s} className="rounded-full border border-line px-2.5 py-0.5 text-xs">
                  {s}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
}
