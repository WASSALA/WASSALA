"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Check, CircleAlert, FileText, Printer, RefreshCw, Send, ShieldCheck, Sparkles } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { WAW_PATH, WAW_VIEWBOX } from "@/components/shared/waw-path";
import { ACCORD_DISCLAIMER, type AccordRecap as Recap, type Clause } from "@/lib/sanad/accord";
import { cn, formatAmount } from "@/lib/utils";

type Stage = "draft" | "validated" | "sent";

interface Props {
  transactionId: string;
  /** false avant l'étape Négociation : le bouton est désactivé et la raison affichée. */
  available: boolean;
  messageCount: number;
  mandat: { vendeur: string | null; acheteur: string | null };
}

const day = (iso: string) => new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(iso));
const STAGES: ReadonlyArray<{ id: Stage; label: string }> = [
  { id: "draft", label: "Brouillon généré" },
  { id: "validated", label: "Validé par l’agent" },
  { id: "sent", label: "Envoyé aux parties" },
];

/** Amène le message cité à l'écran dans le Fil et le met en évidence un instant. */
function showSource(n: number) {
  const el = document.getElementById(`fil-${n}`);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.add("fil-flash");
  window.setTimeout(() => el.classList.remove("fil-flash"), 1600);
}

function Sources({ list }: { list: number[] }) {
  if (!list.length) return <span className="text-ink-soft">·</span>;
  return (
    <span className="flex gap-1">
      {list.map((n) => (
        <button
          key={n}
          type="button"
          onClick={() => showSource(n)}
          className="rounded-full border border-line bg-bg px-2 py-0.5 font-mono text-[11px] text-gold-text transition-colors hover:border-forest hover:text-forest"
          aria-label={`Voir le message ${n} du Fil`}
        >
          #{n}
        </button>
      ))}
    </span>
  );
}

const STATUS_CLS: Record<Clause["status"], string> = {
  trouvé: "bg-forest/10 text-forest",
  "à confirmer": "bg-gold/25 text-gold-text",
  manquant: "bg-danger/10 text-danger",
};

/**
 * Récapitulatif d'accord SANAD : généré par l'IA à partir du Fil, validé par un agent, puis soumis aux parties.
 * Document interne : il ne vaut ni facture, ni contrat de vente entre les parties.
 */
export function AccordRecap({ transactionId, available, messageCount, mandat }: Props) {
  const reduce = useReducedMotion();
  const [recap, setRecap] = useState<Recap | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>("draft");
  const [scan, setScan] = useState(0);
  const docRef = useRef<HTMLDivElement>(null);

  // Pendant la génération, un curseur parcourt les messages du Fil (lecture visible, pas un simple chargement).
  useEffect(() => {
    if (!loading || reduce || messageCount === 0) return;
    const t = window.setInterval(() => setScan((s) => (s % messageCount) + 1), 140);
    return () => window.clearInterval(t);
  }, [loading, reduce, messageCount]);

  const generate = useCallback(async () => {
    setLoading(true);
    setError(null);
    setScan(1);
    try {
      const res = await fetch("/api/accord", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: transactionId }) });
      const data = (await res.json()) as Recap & { error?: string };
      if (!res.ok) throw new Error(data.error ?? "La génération a échoué.");
      setRecap(data);
      setStage("draft");
      window.setTimeout(() => docRef.current?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }), 60);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
      setScan(0);
    }
  }, [transactionId, reduce]);

  const print = () => {
    document.body.classList.add("printing-accord");
    const done = () => {
      document.body.classList.remove("printing-accord");
      window.removeEventListener("afterprint", done);
    };
    window.addEventListener("afterprint", done);
    window.print();
  };

  const askMissing = (labels: string[]) =>
    toast.success("Demande ajoutée au Fil (démonstration)", { description: `« Merci de préciser : ${labels.join(", ").toLowerCase()}. »` });

  const found = recap?.clauses.filter((c) => c.status !== "manquant").length ?? 0;

  return (
    <section className="card p-6 md:p-8" aria-labelledby="accord-title">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-2xl">
          <p className="mb-2 inline-flex items-center gap-2 text-[13px] font-semibold uppercase tracking-[.18em] text-gold-text">
            <Sparkles className="h-4 w-4" aria-hidden="true" /> Généré par l’IA à partir du Fil
          </p>
          <h2 id="accord-title" className="text-[clamp(22px,2.6vw,30px)]">
            Récapitulatif d’accord SANAD
          </h2>
          <p className="mt-2 text-[15px] text-ink-soft">
            Une fois la négociation engagée, l’IA relit le Fil et rassemble les termes convenus entre l’acheteur et le vendeur. Chaque terme renvoie au message
            d’où il vient ; ce qui n’a pas été écrit reste à compléter. L’agent valide, puis le document est soumis aux parties.
          </p>
        </div>
        <span className="rounded-full border border-gold/60 bg-gold/10 px-3 py-1.5 text-xs font-semibold text-gold-text">Document interne · ne vaut pas facture</span>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <button type="button" onClick={generate} disabled={!available || loading} className="btn-primary min-h-11 disabled:cursor-not-allowed disabled:opacity-50">
          {recap ? <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} aria-hidden="true" /> : <Sparkles className="h-4 w-4" aria-hidden="true" />}
          {loading ? "Lecture du Fil…" : recap ? "Régénérer" : "Générer le récapitulatif"}
        </button>
        {!available && <p className="text-sm text-ink-soft">Disponible à partir de l’étape Négociation.</p>}
        {loading && messageCount > 0 && (
          <p className="font-mono text-sm text-ink-soft" aria-live="polite">
            message #{scan || 1} / {messageCount}
          </p>
        )}
      </div>
      {error && (
        <p role="alert" className="mt-4 rounded-md bg-danger/10 px-4 py-3 text-sm text-danger">
          {error}
        </p>
      )}

      <AnimatePresence>
        {recap && (
          <motion.div
            key={recap.generatedAt}
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.2, 0.7, 0.2, 1] }}
            className="mt-8"
          >
            {/* Circuit de validation */}
            <ol className="no-print mb-5 grid gap-2 sm:grid-cols-3" aria-label="Circuit de validation">
              {STAGES.map((s, i) => {
                const idx = STAGES.findIndex((x) => x.id === stage);
                return (
                  <li key={s.id} className={cn("flex items-center gap-2 rounded-lg border px-3 py-2.5 text-sm", i <= idx ? "border-forest/40 bg-forest/5 font-semibold" : "border-line text-ink-soft")}>
                    <span className={cn("flex h-6 w-6 items-center justify-center rounded-full text-xs", i <= idx ? "bg-forest text-white" : "bg-ink/10")}>
                      {i < idx || (i === idx && stage === "sent") ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : i + 1}
                    </span>
                    {s.label}
                  </li>
                );
              })}
            </ol>

            {/* Le document */}
            <div ref={docRef} className="print-doc relative overflow-hidden rounded-2xl border border-line bg-card shadow-lift">
              <p aria-hidden="true" className="pointer-events-none absolute inset-0 flex select-none items-center justify-center text-center font-display text-[clamp(28px,5vw,64px)] leading-tight text-ink/[.045] [transform:rotate(-24deg)]">
                DOCUMENT INTERNE
                <br />
                NE VAUT PAS FACTURE
              </p>

              <div className="relative flex flex-wrap items-start justify-between gap-4 border-b border-line bg-ink px-6 py-5 text-bg md:px-8">
                <div className="flex items-center gap-3">
                  <svg viewBox={WAW_VIEWBOX} className="h-8 w-8 fill-gold" aria-hidden="true">
                    <path fillRule="evenodd" d={WAW_PATH} />
                  </svg>
                  <div>
                    <p className="font-sans text-sm font-semibold uppercase tracking-[.04em]">WASSALA · SANAD</p>
                    <p className="text-xs text-bg/70">Le lien qui construit l’Afrique.</p>
                  </div>
                </div>
                <div className="text-end">
                  <p className="font-display text-xl">Récapitulatif d’accord</p>
                  <p className="font-mono text-xs text-bg/70">
                    {recap.reference} · {day(recap.generatedAt)}
                  </p>
                </div>
              </div>

              <div className="relative space-y-7 px-6 py-6 md:px-8 md:py-7">
                <p className="rounded-lg border border-gold/60 bg-gold/10 px-4 py-3 text-sm text-ink">
                  <FileText className="me-2 inline h-4 w-4 text-gold-text" aria-hidden="true" />
                  {ACCORD_DISCLAIMER}
                </p>

                <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
                  {[
                    ["Vendeur", recap.vendeur],
                    ["Acheteur", recap.acheteur],
                    ["Corridor", recap.corridor],
                    ["Secteur", recap.secteur],
                    ["Transaction", recap.transactionRef],
                    [
                      "Mandat SANAD",
                      mandat.vendeur && mandat.acheteur
                        ? `accepté par le vendeur le ${day(mandat.vendeur)} et par l’acheteur le ${day(mandat.acheteur)}`
                        : "[à recueillir auprès des deux parties]",
                    ],
                  ].map(([k, v]) => (
                    <div key={k} className="flex flex-col border-b border-line pb-2">
                      <dt className="text-xs font-semibold uppercase tracking-[.12em] text-ink-soft">{k}</dt>
                      <dd className="mt-0.5">{v}</dd>
                    </div>
                  ))}
                </dl>

                <div>
                  <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="font-sans text-base font-semibold">Termes convenus dans le Fil</h3>
                    <p className="text-xs text-ink-soft">
                      {found} terme{found > 1 ? "s" : ""} sur {recap.clauses.length} · {recap.messageCount} messages lus ·{" "}
                      {recap.mode === "live" ? "extraction par Claude, vérifiée" : "extraction locale"}
                    </p>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[560px] text-sm">
                      <thead>
                        <tr className="border-b border-line text-start text-xs uppercase tracking-[.1em] text-ink-soft">
                          <th className="py-2 pe-3 text-start font-semibold">Terme</th>
                          <th className="py-2 pe-3 text-start font-semibold">Valeur</th>
                          <th className="py-2 pe-3 text-start font-semibold">Source</th>
                          <th className="py-2 text-start font-semibold">Statut</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recap.clauses.map((c, i) => (
                          <motion.tr
                            key={c.id}
                            initial={reduce ? false : { opacity: 0, x: -8 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: reduce ? 0 : 0.05 * i, duration: 0.35 }}
                            className="border-b border-line align-top"
                          >
                            <td className="py-2.5 pe-3 font-semibold">{c.label}</td>
                            <td className={cn("py-2.5 pe-3", !c.value && "italic text-ink-soft")}>{c.value ?? "Non précisé dans le Fil"}</td>
                            <td className="whitespace-nowrap py-2.5 pe-3">
                              <Sources list={c.sources} />
                            </td>
                            <td className="py-2.5">
                              <span className={cn("whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-semibold", STATUS_CLS[c.status])}>{c.status}</span>
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {recap.missing.length > 0 && (
                    <div className="no-print mt-3 flex flex-wrap items-center gap-3 rounded-lg bg-danger/5 px-4 py-3 text-sm">
                      <CircleAlert className="h-4 w-4 text-danger" aria-hidden="true" />
                      <span>
                        À faire préciser par les parties : <b>{recap.missing.join(", ")}</b>.
                      </span>
                      <button type="button" onClick={() => askMissing(recap.missing)} className="btn-outline ms-auto min-h-9 px-4 text-sm">
                        Demander dans le Fil
                      </button>
                    </div>
                  )}
                </div>

                {recap.conditions.length > 0 && (
                  <div>
                    <h3 className="mb-2 font-sans text-base font-semibold">Conditions particulières</h3>
                    <ul className="space-y-2 text-sm">
                      {recap.conditions.map((c) => (
                        <li key={c.text} className="flex flex-wrap items-start gap-2">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rotate-45 bg-gold" aria-hidden="true" />
                          <span className="flex-1">{c.text}</span>
                          <Sources list={c.sources} />
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="grid gap-6 md:grid-cols-2">
                  <div className="rounded-xl bg-section p-5">
                    <h3 className="mb-3 font-sans text-base font-semibold">Commission SANAD</h3>
                    <p className="font-display text-3xl text-forest">
                      {formatAmount(recap.commission.total)} {recap.devise}
                    </p>
                    <p className="mt-1 text-sm text-ink-soft">
                      {recap.commission.taux.toLocaleString("fr-FR")} % de {formatAmount(recap.commission.base)} {recap.devise}{" "}
                      {recap.commission.baseSource === "fil" ? "(valeur convenue dans le Fil)" : "(valeur du brief, à confirmer)"}. Due uniquement si la transaction aboutit.
                    </p>
                    <p className="mt-3 text-xs text-ink-soft">
                      Dont fonds DAMAN {formatAmount(recap.commission.daman)} {recap.devise} et WASSALA {formatAmount(recap.commission.wassala)} {recap.devise}. [Répartition
                      SILSILA illustrative, règle à confirmer.]
                    </p>
                  </div>
                  <div className="rounded-xl bg-section p-5">
                    <h3 className="mb-3 font-sans text-base font-semibold">Séquestre AMANA et missions CHAHID</h3>
                    <ol className="space-y-2 text-sm">
                      {recap.tranches.map((t, i) => (
                        <li key={t.event} className="flex items-baseline justify-between gap-3 border-b border-line pb-1.5 last:border-0">
                          <span>
                            <b>{t.pct} %</b> · {t.event}
                            <span className="block text-xs text-ink-soft">
                              {["Constat CHAHID de l’inspection", "Constat CHAHID du chargement ou du passage", "Confirmation de réception"][i]}
                            </span>
                          </span>
                          <span className="whitespace-nowrap font-semibold">
                            {formatAmount(t.amount)} {recap.devise}
                          </span>
                        </li>
                      ))}
                    </ol>
                    <p className="mt-3 text-xs text-ink-soft">
                      DAMAN couvre une première perte de {recap.damanCover[0]} à {recap.damanCover[1]} % de la valeur, sur litige constaté. Au-delà, rien n’est garanti.
                    </p>
                  </div>
                </div>

                <ul className="grid gap-2 text-xs text-ink-soft sm:grid-cols-3">
                  <li>WASSALA ne détient jamais les fonds : ils restent chez la banque partenaire.</li>
                  <li>SANAD ne délivre pas le certificat d’origine : le témoin CHAHID le vérifie.</li>
                  <li>Le contrat de vente et la facture restent établis par les parties.</li>
                </ul>

                <div className="grid gap-3 border-t border-line pt-4 text-xs text-ink-soft sm:grid-cols-3">
                  <p>
                    <b className="text-ink">Généré</b> le {day(recap.generatedAt)} par {recap.mode === "live" ? "l’IA (Claude)" : "l’extraction locale"}.
                  </p>
                  <p>
                    <b className="text-ink">Agent SANAD</b> : {stage === "draft" ? "validation en attente" : "[Prénom Nom], validé"}
                  </p>
                  <p>
                    <b className="text-ink">Parties</b> : {stage === "sent" ? "acceptation demandée" : "non encore soumis"}
                  </p>
                </div>
              </div>
            </div>

            <div className="no-print mt-5 flex flex-wrap gap-3">
              {stage === "draft" && (
                <button
                  type="button"
                  onClick={() => {
                    setStage("validated");
                    toast.success("Récapitulatif validé par l’agent (démonstration)");
                  }}
                  className="btn-primary min-h-11"
                >
                  <ShieldCheck className="h-4 w-4" aria-hidden="true" /> Valider (agent SANAD)
                </button>
              )}
              {stage === "validated" && (
                <button
                  type="button"
                  onClick={() => {
                    setStage("sent");
                    toast.success("Envoyé aux deux parties pour acceptation (démonstration)", {
                      description: "La signature électronique sera branchée sur un prestataire [à choisir].",
                    });
                  }}
                  className="btn-primary min-h-11"
                >
                  <Send className="h-4 w-4" aria-hidden="true" /> Soumettre aux parties
                </button>
              )}
              <button type="button" onClick={print} className="btn-outline min-h-11">
                <Printer className="h-4 w-4" aria-hidden="true" /> Imprimer ou enregistrer en PDF
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
