"use client";

import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { MOCK_TRANSACTIONS } from "@/lib/api/mock";
import { TRANSACTION_STATUSES, type TransactionStatus } from "@/lib/api/types";
import { cn, normalize } from "@/lib/utils";
import { TransactionTable } from "./TransactionRow";

/** Liste filtrable des transactions : recherche libre et filtre par étape. */
export function TransactionsExplorer() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<TransactionStatus | "all">("all");
  const rows = useMemo(() => {
    const n = normalize(q.trim());
    return MOCK_TRANSACTIONS.filter(
      (t) => (status === "all" || t.status === status) && (!n || normalize(`${t.ref} ${t.corridor} ${t.secteur} ${t.vendeur} ${t.acheteur}`).includes(n)),
    );
  }, [q, status]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[240px] flex-1">
          <Search className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-soft" aria-hidden="true" />
          <label htmlFor="tx-search" className="sr-only">
            Rechercher une transaction
          </label>
          <input id="tx-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Référence, corridor, secteur…" className="field ps-10" />
        </div>
      </div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto" role="group" aria-label="Filtrer par étape">
        {[{ id: "all" as const, label: "Toutes" }, ...TRANSACTION_STATUSES].map((s) => (
          <button
            key={s.id}
            type="button"
            aria-pressed={status === s.id}
            onClick={() => setStatus(s.id)}
            className={cn(
              "min-h-10 shrink-0 rounded-full border px-4 text-sm font-semibold transition-colors",
              status === s.id ? "border-ink bg-ink text-bg" : "border-line hover:border-gold",
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
      {rows.length ? (
        <TransactionTable rows={rows} />
      ) : (
        <p className="card p-8 text-center text-ink-soft" role="status">
          Aucune transaction ne correspond.
        </p>
      )}
    </div>
  );
}
