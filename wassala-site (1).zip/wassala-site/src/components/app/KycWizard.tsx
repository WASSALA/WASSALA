"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Check, Lock, UploadCloud } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { FORM_COUNTRIES } from "@/data/countries";
import { cn } from "@/lib/utils";

const STEPS = ["Identité", "Entreprise", "Documents"] as const;

/** Vérification KYC/KYB en trois étapes. Démonstration : aucun fichier n'est envoyé. */
export function KycWizard() {
  const reduce = useReducedMotion();
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  const [files, setFiles] = useState<Record<string, string>>({});

  const next = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!e.currentTarget.checkValidity()) {
      e.currentTarget.reportValidity();
      return;
    }
    if (step === 2 && (!files.kbis || !files.piece)) {
      toast.error("Ajoutez les deux documents demandés.");
      return;
    }
    if (step < STEPS.length - 1) setStep((s) => s + 1);
    else {
      setDone(true);
      toast.success("Dossier soumis. Un agent l’examine.");
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <div>
        <h1 className="text-[clamp(30px,4vw,44px)]">Vérification KYC / KYB</h1>
        <p className="mt-1 flex items-center gap-2 text-ink-soft">
          <Lock className="h-4 w-4 text-gold-text" aria-hidden="true" /> Indispensable avant toute présentation à une contrepartie.
        </p>
      </div>

      <ol className="flex items-center gap-2" aria-label="Étapes">
        {STEPS.map((s, i) => {
          const complete = i < step || done;
          const current = i === step && !done;
          return (
            <li key={s} className="flex flex-1 items-center gap-2">
              <span
                aria-current={current ? "step" : undefined}
                className={cn(
                  "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors",
                  complete ? "border-forest bg-forest text-white" : current ? "border-forest text-forest" : "border-line text-ink-soft",
                )}
              >
                {complete ? <Check className="h-4 w-4" aria-hidden="true" /> : i + 1}
              </span>
              <span className={cn("hidden text-sm sm:inline", current ? "font-semibold" : "text-ink-soft")}>{s}</span>
              {i < STEPS.length - 1 ? <span className={cn("h-px flex-1", complete ? "bg-forest" : "bg-line")} aria-hidden="true" /> : null}
            </li>
          );
        })}
      </ol>

      <AnimatePresence mode="wait">
        {done ? (
          <motion.div key="done" initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="card p-8 text-center" role="status">
            <span className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-forest text-white">
              <Check className="h-8 w-8" aria-hidden="true" />
            </span>
            <p className="mb-2 font-display text-3xl">Dossier soumis</p>
            <p className="text-ink-soft">
              Statut : <b className="text-ink">en attente de vérification</b>. <span className="placeholder-tag">Délai de traitement à préciser</span>
            </p>
          </motion.div>
        ) : (
          <motion.form
            key={step}
            onSubmit={next}
            noValidate
            className="card space-y-5 p-6 md:p-8"
            initial={reduce ? false : { opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, x: -24 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="font-sans text-lg font-semibold">
              Étape {step + 1} · {STEPS[step]}
            </h2>
            {step === 0 ? (
              <>
                {(
                  [
                    ["k-nom", "Nom complet", "text", "name"],
                    ["k-email", "Email professionnel", "email", "email"],
                    ["k-tel", "Téléphone", "tel", "tel"],
                  ] as const
                ).map(([id, l, t, ac]) => (
                  <div key={id}>
                    <label htmlFor={id} className="field-label">
                      {l} *
                    </label>
                    <input id={id} type={t} autoComplete={ac} required className="field" />
                  </div>
                ))}
              </>
            ) : null}
            {step === 1 ? (
              <>
                <div>
                  <label htmlFor="k-raison" className="field-label">
                    Raison sociale *
                  </label>
                  <input id="k-raison" required autoComplete="organization" className="field" />
                </div>
                <div>
                  <label htmlFor="k-rc" className="field-label">
                    Numéro de registre du commerce *
                  </label>
                  <input id="k-rc" required className="field" />
                </div>
                <div>
                  <label htmlFor="k-pays" className="field-label">
                    Pays d’enregistrement *
                  </label>
                  <select id="k-pays" required defaultValue="" className="field">
                    <option value="" disabled>
                      Choisir
                    </option>
                    {FORM_COUNTRIES.map((p) => (
                      <option key={p}>{p}</option>
                    ))}
                  </select>
                </div>
              </>
            ) : null}
            {step === 2 ? (
              <>
                {(
                  [
                    ["kbis", "Extrait du registre du commerce"],
                    ["piece", "Pièce d’identité du dirigeant"],
                  ] as const
                ).map(([id, l]) => (
                  <div key={id}>
                    <p className="field-label">{l} *</p>
                    <label
                      htmlFor={`k-${id}`}
                      className={cn(
                        "flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-5 text-center text-sm transition-colors",
                        files[id] ? "border-forest bg-forest/5" : "border-line-strong hover:border-gold",
                      )}
                    >
                      {files[id] ? <Check className="h-6 w-6 text-forest" aria-hidden="true" /> : <UploadCloud className="h-6 w-6 text-gold-text" aria-hidden="true" />}
                      <span>{files[id] ?? "Déposer un fichier ou cliquer (PDF, JPG, PNG)"}</span>
                      <input
                        id={`k-${id}`}
                        type="file"
                        accept=".pdf,.jpg,.jpeg,.png"
                        className="sr-only"
                        onChange={(e) => setFiles((f) => ({ ...f, [id]: e.target.files?.[0]?.name ?? "" }))}
                      />
                    </label>
                  </div>
                ))}
                <p className="text-xs text-ink-soft">Démonstration : aucun fichier n’est envoyé ni conservé.</p>
              </>
            ) : null}
            <div className="flex gap-3 pt-2">
              {step > 0 ? (
                <button type="button" onClick={() => setStep((s) => s - 1)} className="btn-outline min-h-11 px-5 text-sm">
                  Retour
                </button>
              ) : null}
              <button type="submit" className="btn-primary min-h-11 px-6 text-sm">
                {step < STEPS.length - 1 ? "Continuer" : "Soumettre"}
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
}
