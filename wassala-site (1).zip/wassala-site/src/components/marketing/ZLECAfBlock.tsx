import { Counter } from "@/components/motion/Counter";
import { Reveal } from "@/components/motion/Reveal";

function BorderArt() {
  return (
    <svg viewBox="0 0 240 90" className="h-auto w-full max-w-[260px]" aria-hidden="true">
      <path d="M8 70C40 20 80 18 112 46" className="fill-forest/10 stroke-forest/40" strokeWidth="1.2" />
      <path d="M128 46C160 18 200 20 232 70" className="fill-gold/15 stroke-gold" strokeWidth="1.2" />
      <path d="M120 10V84" className="stroke-ink-soft" strokeWidth="1.2" strokeDasharray="3 5" />
      <path d="M30 62C80 40 160 40 210 62" className="fill-none stroke-gold" strokeWidth="1.8" strokeLinecap="round" />
      <rect width="10" height="6" rx="1.5" className="map-pulse fill-forest-dark">
        <animateMotion dur="4s" repeatCount="indefinite" path="M25 59C80 37 160 37 205 59" rotate="auto" />
      </rect>
      <rect width="10" height="6" rx="1.5" className="map-pulse fill-[#B8860B]">
        <animateMotion dur="4s" begin="2s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear" path="M25 59C80 37 160 37 205 59" rotate="auto" />
      </rect>
    </svg>
  );
}

function PortArt() {
  return (
    <svg viewBox="0 0 240 90" className="h-auto w-full max-w-[260px]" aria-hidden="true">
      <path d="M150 20h70v40h-70z" className="fill-forest/10 stroke-forest/40" strokeWidth="1.2" />
      <path d="M160 20v-10h12v10M186 20V6h12v14" className="fill-none stroke-forest/50" strokeWidth="1.2" />
      <path d="M0 62q10-8 20 0t20 0 20 0 20 0 20 0 20 0 20 0" className="fill-none stroke-sea" strokeWidth="1.6" />
      <path d="M0 76q10-8 20 0t20 0 20 0 20 0 20 0 20 0 20 0" className="fill-none stroke-sea" strokeOpacity=".45" strokeWidth="1.6" />
      <g className="map-pulse">
        <path d="M-14 0h28l-5 8h-18z" className="fill-gold" />
        <animateMotion dur="5s" repeatCount="indefinite" path="M10 52H150" />
      </g>
    </svg>
  );
}

/** Périmètre d'action : la ZLECAf, et deux types de territoires précis. */
export function ZLECAfBlock() {
  return (
    <section className="relative bg-section py-24 md:py-32" id="perimetre" aria-labelledby="perimetre-title">
      <div className="container grid gap-14 lg:grid-cols-[1fr_1.1fr]">
        <div className="lg:sticky lg:top-40 lg:self-start">
          <p className="eyebrow">Notre périmètre</p>
          <h2 id="perimetre-title" className="mb-6 text-[clamp(34px,4.6vw,56px)]">
            Notre périmètre&nbsp;: la ZLECAf.
          </h2>
          <p className="mb-6 text-lg text-ink-soft">
            Wassala agit dans le périmètre de la ZLECAf, la Zone de libre-échange continentale africaine, ce marché unique de plus de
            1,3&nbsp;milliard de consommateurs où les barrières tarifaires tombent progressivement. Nous ne visons pas le continent comme une
            abstraction&nbsp;: nous ciblons deux types de territoires précis.
          </p>
          <div className="mb-8 flex items-end gap-4 border-t border-gold/60 pt-6">
            <span className="font-display text-[clamp(56px,7vw,88px)] leading-none text-forest">
              <Counter to={1.3} decimals={1} />
            </span>
            <span className="pb-2 text-ink-soft">
              milliard de consommateurs
              <br />
              dans un marché unique
            </span>
          </div>
          <p className="text-[15px] text-ink-soft">
            Ce périmètre n’est pas un choix de principe, c’est un choix opérationnel&nbsp;: à l’intérieur de la ZLECAf, les règles d’origine, les
            tarifs préférentiels et les mécanismes de règlement sont connus, documentés et opposables.
          </p>
        </div>

        <div className="space-y-5">
          <Reveal className="spotlight card card-lift p-8 md:p-10">
            <BorderArt />
            <h3 className="mb-3 mt-6 text-3xl">Les pays de zone frontalière</h3>
            <p className="text-ink-soft">
              Ceux dont la proximité géographique avec un voisin permet un commerce terrestre rapide, des coûts logistiques maîtrisés et des
              chaînes d’approvisionnement courtes.
            </p>
          </Reveal>
          <Reveal index={1} className="spotlight card card-lift p-8 md:p-10">
            <PortArt />
            <h3 className="mb-3 mt-6 text-3xl">Les capitales portuaires</h3>
            <p className="text-ink-soft">
              Ces villes qui commandent l’accès maritime du continent et où se concentrent les flux d’import-export, les banques, les assurances
              et les infrastructures de stockage.
            </p>
          </Reveal>
          <Reveal index={2} className="rounded-lg border-s-4 border-gold bg-card/60 p-8">
            <p className="font-display text-2xl leading-snug md:text-[28px]">
              C’est là que se joue la circulation réelle des marchandises, et c’est là que Wassala commence le déploiement de ses projets.
            </p>
            <p className="mt-4 text-sm text-ink-soft">
              Hors de ce périmètre, nous ne nous engageons pas&nbsp;: le risque logistique et le risque de paiement y sont trop élevés pour un
              modèle qui repose sur la traçabilité et la prévisibilité.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
