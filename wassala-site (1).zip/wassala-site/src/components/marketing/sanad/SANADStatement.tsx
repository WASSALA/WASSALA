import { ScrollWords } from "@/components/motion/ScrollWords";
import { Reveal } from "@/components/motion/Reveal";

export function SANADStatement() {
  return (
    <section className="py-24 md:py-32" aria-label="Ce que fait SANAD">
      <div className="container">
        <ScrollWords
          text="Le commerce intra-africain ne manque pas de traités. Il manque de transactions qui aboutissent."
          highlight={["aboutissent"]}
          className="mb-14 max-w-5xl font-display text-[clamp(32px,4.6vw,60px)] leading-[1.1] tracking-[-0.02em]"
        />
        <div className="grid gap-10 border-t border-gold/60 pt-10 md:grid-cols-2">
          <Reveal>
            <p className="text-lg text-ink-soft md:text-xl">
              SANAD conduit une transaction commerciale entre deux inconnus africains, <strong className="text-ink">de l’introduction jusqu’au paiement</strong>,
              et ne se rémunère que si elle arrive à son terme.
            </p>
          </Reveal>
          <Reveal index={1}>
            <p className="text-lg text-ink-soft md:text-xl">
              En arabe, <em lang="ar-Latn">sanad</em> désigne ce sur quoi l’on s’appuie, et le titre qui prouve. Une transaction est digne de
              confiance parce que la chaîne de ceux qui s’en portent garants est traçable.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
