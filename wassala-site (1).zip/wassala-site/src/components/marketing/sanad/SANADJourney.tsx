import { Reveal } from "@/components/motion/Reveal";
import { TRANSACTION_STATUSES } from "@/lib/api/types";

const DETAILS: Record<string, string> = {
  brief: "Vous décrivez votre produit, votre marché, votre volume.",
  qualification: "Un agent vérifie le besoin, les parties et le corridor.",
  presentation: "La contrepartie est présentée ; l’introduction est enregistrée.",
  rencontre: "Les parties se parlent dans le fil, avec un témoin.",
  negociation: "Proforma, contrat-type, code SH et régime ZLECAf.",
  accord: "Fonds en séquestre AMANA, tranches débloquées sur constat.",
  commission: "La transaction aboutit : la commission est répartie.",
};

/** Le parcours d'une transaction SANAD, du brief à la commission. */
export function SANADJourney() {
  return (
    <section className="bg-section py-24 md:py-32" aria-labelledby="parcours-title">
      <div className="container">
        <div className="mb-14 max-w-3xl">
          <p className="eyebrow">Le parcours</p>
          <h2 id="parcours-title" className="mb-5 text-[clamp(34px,4.6vw,56px)]">
            Du brief à la commission
          </h2>
          <p className="text-lg text-ink-soft">Sept étapes, visibles à tout moment dans votre espace. Rien n’est facturé tant que la transaction n’a pas abouti.</p>
        </div>
        <ol className="relative grid gap-4 md:grid-cols-7 md:gap-3">
          <span aria-hidden="true" className="absolute start-0 end-0 top-6 hidden h-px bg-gradient-to-r from-forest via-gold to-gold md:block" />
          {TRANSACTION_STATUSES.map((s, i) => (
            <Reveal as="li" key={s.id} index={i} className="relative flex gap-4 md:flex-col md:gap-0">
              <span className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-gold bg-bg font-display text-lg text-ink md:mb-5">
                {i + 1}
              </span>
              <div>
                <h3 className="mb-1 font-sans text-base font-semibold">{s.label}</h3>
                <p className="text-sm text-ink-soft">{DETAILS[s.id]}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}
