"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { AlertTriangle } from "lucide-react";
import { useActiveSection } from "@/lib/hooks/useActiveSection";
import { cn } from "@/lib/utils";

type MechId = "fil" | "silsila" | "amana" | "chahid" | "muqassa" | "daman";

const MECHS: ReadonlyArray<{ id: MechId; n: string; name: string; title: string; body: string; warning?: string }> = [
  {
    id: "fil",
    n: "01",
    name: "Le Fil",
    title: "La transaction comme conversation tracée",
    body: "Chaque transaction ouvre un fil numéroté avec les parties, un témoin et un assistant trilingue (français, arabe, anglais). Il génère la facture proforma, le contrat-type et la liste des pièces. Chaque message, photo et document est horodaté dans un registre. À l’issue de la négociation, l’IA en tire le récapitulatif d’accord SANAD, un document interne qui ne vaut pas facture.",
  },
  {
    id: "silsila",
    n: "02",
    name: "SILSILA",
    title: "La chaîne des apporteurs",
    body: "Chaque introduction est enregistrée. Une commission de 3 à 5 % de la valeur confirmée est répartie selon une règle fixée à l’avance entre apporteur, agent local, témoin, fonds de garantie et WASSALA. Le contournement n’est pas interdit : il est rendu peu rentable, car garantie, séquestre, financement et réputation ne sont accessibles que dans le circuit.",
  },
  {
    id: "amana",
    n: "03",
    name: "AMANA",
    title: "Le séquestre à étapes",
    body: "L’acheteur dépose les fonds chez une banque partenaire ou un agent séquestre régulé. Déblocage par tranches liées à des événements constatés par un témoin : 30 % à l’inspection, 40 % au chargement ou au passage de la frontière, 30 % à la réception.",
    warning: "WASSALA ne détient jamais les fonds.",
  },
  {
    id: "chahid",
    n: "04",
    name: "CHAHID",
    title: "Le témoin local certifié",
    body: "Inspecteurs, transitaires, avocats, huissiers, laboratoires, payés à la mission et responsables de leurs constats. Preuves à l’appui : photos géolocalisées, scans, relevés. Un faux constat entraîne l’exclusion.",
  },
  {
    id: "muqassa",
    n: "05",
    name: "MUQASSA",
    title: "La compensation de flux",
    body: "Quand un exportateur algérien vend vers un pays et qu’un exportateur de ce pays vend vers l’Algérie, les flux s’annulent en partie. Seul le solde net traverse la frontière. Service d’appariement exécuté par des banques agréées, jamais un transfert opéré par WASSALA.",
    warning: "MUQASSA est exécuté par des banques agréées, jamais par WASSALA.",
  },
  {
    id: "daman",
    n: "06",
    name: "DAMAN",
    title: "La tontine de transaction",
    body: "Chaque transaction verse 0,3 à 0,5 % dans un fonds de garantie mutuel. Il couvre une première perte plafonnée (10 à 20 % de la valeur) sur les litiges constatés par témoin.",
    warning: "Au-delà, rien n’est garanti. Cette limite est dite clairement.",
  },
];

const MECH_IDS = MECHS.map((m) => m.id);
const T = { fontFamily: "inherit" } as const;

function Visual({ id }: { id: MechId }) {
  switch (id) {
    case "fil":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          {(["Acheteur", "Témoin", "Vendeur"] as const).map((t, i) => (
            <g key={t}>
              <circle cx={60 + i * 120} cy={70} r={32} className={i === 1 ? "fill-gold/20 stroke-gold" : "fill-card stroke-forest"} strokeWidth={2} />
              <text x={60 + i * 120} y={74} textAnchor="middle" className="fill-ink text-[12px] font-semibold">
                {t}
              </text>
            </g>
          ))}
          <path d="M92 70H148M212 70H268" className="stroke-gold" strokeWidth={2} strokeDasharray="4 6" />
          <circle r={4} className="map-pulse fill-forest">
            <animateMotion dur="3s" repeatCount="indefinite" path="M92 70H268" />
          </circle>
          {[0, 1, 2].map((i) => (
            <g key={i}>
              <rect x={40} y={128 + i * 26} width={280} height={18} rx={9} className="fill-section" />
              <rect x={40} y={128 + i * 26} width={[150, 210, 110][i]} height={18} rx={9} className="fill-forest/20">
                <animate attributeName="width" values={`0;${[150, 210, 110][i]}`} dur="1.2s" begin={`${i * 0.3}s`} fill="freeze" />
              </rect>
              <text x={330} y={141 + i * 26} textAnchor="end" className="fill-ink-soft font-mono text-[10px]">
                {["10:42", "10:58", "11:15"][i]}
              </text>
            </g>
          ))}
        </svg>
      );
    case "silsila":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          <path d="M34 90H326" className="stroke-gold" strokeWidth={1.8} />
          <circle r={4} className="map-pulse fill-forest">
            <animateMotion dur="3.5s" repeatCount="indefinite" path="M34 90H326" />
          </circle>
          {(["Apporteur", "Agent", "Témoins", "DAMAN", "WASSALA"] as const).map((t, i) => (
            <g key={t}>
              <circle cx={34 + i * 73} cy={90} r={30} className={i === 4 ? "fill-gold stroke-gold" : "fill-card stroke-forest"} strokeWidth={1.8} />
              <text x={34 + i * 73} y={93.5} textAnchor="middle" className="fill-ink text-[9.5px] font-semibold">
                {t}
              </text>
            </g>
          ))}
          <text x={180} y={160} textAnchor="middle" className="fill-ink text-[13px] font-semibold">
            Commission de 3 à 5 %
          </text>
          <text x={180} y={182} textAnchor="middle" className="fill-ink-soft text-[11px]">
            répartie selon une règle fixée à l’avance
          </text>
        </svg>
      );
    case "amana":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          <rect x={120} y={18} width={120} height={40} rx={8} className="fill-ink" />
          <text x={180} y={43} textAnchor="middle" className="fill-bg text-[11.5px] font-semibold">
            Banque partenaire
          </text>
          {[
            { x: 24, w: 90, p: "30 %", l: "Inspection", b: 0 },
            { x: 122, w: 116, p: "40 %", l: "Chargement", b: 2.5 },
            { x: 246, w: 90, p: "30 %", l: "Réception", b: 5 },
          ].map(({ x, w, p, l, b }) => (
            <g key={p + l}>
              <path d={`M180 58L${x + w / 2} 100`} className="stroke-gold/60" strokeWidth={1.2} strokeDasharray="3 4" />
              <rect x={x} y={100} width={w} height={42} rx={8} className="fill-forest stroke-forest" strokeWidth={1.5} fillOpacity={0.12}>
                <animate attributeName="fill-opacity" values=".12;.9;.9;.12" keyTimes="0;.15;.85;1" dur="7.5s" begin={`${b}s`} repeatCount="indefinite" />
              </rect>
              <text x={x + w / 2} y={126} textAnchor="middle" className="fill-ink text-[14px] font-semibold">
                {p}
              </text>
              <text x={x + w / 2} y={162} textAnchor="middle" className="fill-ink-soft text-[11px]">
                {l}
              </text>
            </g>
          ))}
          <text x={180} y={200} textAnchor="middle" className="fill-gold-text text-[12px] font-semibold">
            WASSALA ne détient jamais les fonds
          </text>
        </svg>
      );
    case "chahid":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          <circle cx={180} cy={90} r={40} className="fill-gold/15 stroke-gold" strokeWidth={2} />
          <circle cx={180} cy={90} r={40} className="map-pulse fill-none stroke-gold" strokeWidth={1.5}>
            <animate attributeName="r" values="40;80" dur="3s" repeatCount="indefinite" />
            <animate attributeName="opacity" values=".8;0" dur="3s" repeatCount="indefinite" />
          </circle>
          <path d="M162 90l13 13 25-27" className="fill-none stroke-forest" strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
          {[
            { x: 50, y: 60, t: "Photos" },
            { x: 310, y: 60, t: "Relevés" },
            { x: 50, y: 130, t: "Scans" },
            { x: 310, y: 130, t: "GPS" },
          ].map((p) => (
            <g key={p.t}>
              <path d={`M${p.x < 180 ? p.x + 30 : p.x - 30} ${p.y}L${p.x < 180 ? 142 : 218} ${p.y < 90 ? 78 : 102}`} className="stroke-ink-soft/40" strokeDasharray="2 4" />
              <rect x={p.x - 30} y={p.y - 14} width={60} height={28} rx={14} className="fill-card stroke-line-strong" />
              <text x={p.x} y={p.y + 4} textAnchor="middle" className="fill-ink text-[11px]">
                {p.t}
              </text>
            </g>
          ))}
          <text x={180} y={168} textAnchor="middle" className="fill-ink text-[13px] font-semibold">
            Constat géolocalisé
          </text>
          <text x={180} y={192} textAnchor="middle" className="fill-ink-soft text-[11px]">
            Un faux constat entraîne l’exclusion
          </text>
        </svg>
      );
    case "muqassa":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          <text x={30} y={34} className="fill-ink-soft text-[11px]">
            Export Algérie → pays X
          </text>
          <path d="M30 50H300" className="stroke-gold" strokeWidth={8} strokeLinecap="round" />
          <path d="M300 40l16 10-16 10" className="fill-none stroke-gold" strokeWidth={3} />
          <text x={330} y={92} textAnchor="end" className="fill-ink-soft text-[11px]">
            Export pays X → Algérie
          </text>
          <path d="M330 108H110" className="stroke-forest" strokeWidth={8} strokeLinecap="round" />
          <path d="M110 98l-16 10 16 10" className="fill-none stroke-forest" strokeWidth={3} />
          <path d="M30 168H120" className="stroke-ink" strokeWidth={8} strokeLinecap="round">
            <animate attributeName="stroke-opacity" values=".3;1;.3" dur="3s" repeatCount="indefinite" />
          </path>
          <text x={136} y={173} className="fill-ink text-[13px] font-semibold">
            Seul le solde net traverse
          </text>
          <text x={30} y={200} className="fill-ink-soft text-[11px]">
            Appariement exécuté par des banques agréées
          </text>
        </svg>
      );
    case "daman":
      return (
        <svg viewBox="0 0 360 220" className="h-auto w-full" style={T} aria-hidden="true">
          <text x={30} y={40} className="fill-ink-soft text-[11px]">
            Valeur de la transaction
          </text>
          <rect x={30} y={52} width={300} height={34} rx={6} className="fill-ink/10" />
          <rect x={30} y={52} width={30} height={34} rx={6} className="fill-gold" />
          <rect x={60} y={52} width={30} height={34} className="fill-gold/45" />
          <text x={45} y={106} textAnchor="middle" className="fill-ink text-[11px]">
            10 %
          </text>
          <text x={90} y={106} textAnchor="middle" className="fill-ink text-[11px]">
            20 %
          </text>
          <text x={215} y={74} textAnchor="middle" className="fill-ink-soft text-[11.5px] font-semibold">
            Au-delà : rien n’est garanti
          </text>
          {[0, 1, 2, 3].map((i) => (
            <circle key={i} cx={130 + i * 34} cy={150} r={3.5} className="map-pulse fill-forest">
              <animate attributeName="cy" values="132;168" dur="2s" begin={`${i * 0.4}s`} repeatCount="indefinite" />
              <animate attributeName="opacity" values="1;0" dur="2s" begin={`${i * 0.4}s`} repeatCount="indefinite" />
            </circle>
          ))}
          <rect x={110} y={170} width={140} height={22} rx={11} className="fill-forest/15 stroke-forest" />
          <text x={180} y={185} textAnchor="middle" className="fill-forest text-[11px] font-semibold">
            Fonds mutuel DAMAN
          </text>
          <text x={180} y={212} textAnchor="middle" className="fill-gold-text text-[11.5px] font-semibold">
            0,3 à 0,5 % par transaction
          </text>
        </svg>
      );
  }
}

/**
 * Les six mécanismes en récit défilant : le texte défile, le schéma reste fixe et change avec le mécanisme lu.
 * Sur mobile, chaque mécanisme porte son propre schéma.
 */
export function SANADMechanisms() {
  const reduce = useReducedMotion();
  const active = useActiveSection(MECH_IDS, "fil");

  const current = MECHS.find((m) => m.id === active)!;

  return (
    <section id="mecanismes" className="relative py-24 md:py-32" aria-labelledby="mecanismes-title">
      <div className="container">
        <div className="mb-10 max-w-3xl md:mb-4">
          <p className="eyebrow">Six mécanismes</p>
          <h2 id="mecanismes-title" className="mb-5 text-[clamp(34px,4.6vw,56px)]">
            Six mécanismes, tous traçables
          </h2>
          <p className="text-lg text-ink-soft">
            SANAD ne crée aucun droit propre. Il fait appliquer, transaction par transaction, ce que l’accord ZLECAf et le droit douanier
            prévoient déjà.
          </p>
        </div>

        <div className="grid gap-10 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
          <ol>
            {MECHS.map((m) => (
              <li
                key={m.id}
                id={m.id}
                className="flex scroll-mt-40 flex-col justify-center border-b border-gold/40 py-12 last:border-0 lg:min-h-[72vh]"
              >
                <p className={cn("mb-3 text-sm font-semibold uppercase tracking-[.2em] transition-colors", active === m.id ? "text-gold-text" : "text-ink-soft")}>
                  {m.n} · {m.name}
                </p>
                <h3 className={cn("mb-4 text-[clamp(28px,3vw,40px)] transition-opacity duration-500", active === m.id ? "opacity-100" : "lg:opacity-40")}>{m.title}</h3>
                <p className="mb-5 text-lg text-ink-soft">{m.body}</p>
                {m.warning ? (
                  <p className="flex items-start gap-3 rounded-lg border border-gold bg-card p-4 text-[15px] font-semibold">
                    <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-gold-text" aria-hidden="true" />
                    {m.warning}
                  </p>
                ) : null}
                <div className="card mt-6 p-5 lg:hidden">
                  <Visual id={m.id} />
                </div>
              </li>
            ))}
          </ol>

          <div className="hidden lg:block">
            <div className="sticky top-[calc(var(--header-h)+80px)]">
              <div className="card overflow-hidden shadow-soft">
                <div className="flex items-center justify-between border-b border-line px-6 py-4">
                  <p className="font-semibold">
                    <span className="text-gold-text">{current.n}</span> · {current.name}
                  </p>
                  <div className="flex gap-1.5" aria-hidden="true">
                    {MECHS.map((m) => (
                      <span key={m.id} className={cn("h-1.5 rounded-full transition-all duration-500", m.id === active ? "w-6 bg-forest" : "w-1.5 bg-ink/20")} />
                    ))}
                  </div>
                </div>
                <div className="relative p-8">
                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div
                      key={active}
                      initial={reduce ? { opacity: 0 } : { opacity: 0, y: 16, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={reduce ? { opacity: 0 } : { opacity: 0, y: -16, scale: 0.98 }}
                      transition={{ duration: 0.4, ease: [0.2, 0.7, 0.2, 1] }}
                    >
                      <Visual id={active} />
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
