"use client";

import { animate, useReducedMotion } from "framer-motion";
import { ArrowRight, Info } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { NODES } from "@/data/capitals";
import {
  COMMISSION_RATE_MAX,
  COMMISSION_RATE_MIN,
  DAMAN_COVER_RANGE,
  DAMAN_RANGE,
  amanaTranches,
  computeCommission,
} from "@/lib/sanad/commission";
import { cn, formatAmount } from "@/lib/utils";

const MIN = 5_000;
const MAX = 1_000_000;
const PRESETS = [10_000, 60_000, 250_000, 500_000] as const;
const ORIGINS = ["Alger", "Oran", "Sétif", "Constantine", "Annaba", "Biskra"] as const;
const COUNTRY_OF: Record<string, string> = {
  Rabat: "Maroc", Tunis: "Tunisie", Nouakchott: "Mauritanie", Dakar: "Sénégal", Bamako: "Mali", Conakry: "Guinée",
  Ouagadougou: "Burkina Faso", Niamey: "Niger", "N’Djamena": "Tchad", Yamoussoukro: "Côte d’Ivoire", Abidjan: "Côte d’Ivoire",
  Lomé: "Togo", "Porto-Novo": "Bénin", Yaoundé: "Cameroun", Libreville: "Gabon", "Kinshasa · Brazzaville": "RD Congo",
  Bangui: "Centrafrique", "Kigali · Gitega": "Rwanda", Djibouti: "Djibouti", Moroni: "Comores", Antananarivo: "Madagascar",
  Lagos: "Nigéria", Nairobi: "Kenya", "Addis-Abeba": "Éthiopie", Johannesburg: "Afrique du Sud", "Le Caire": "Égypte",
};
const DESTINATIONS = NODES.filter((n) => n.id !== "alg").map((n) => n.name);

/** Curseur logarithmique : précision sur les petits montants, portée jusqu'au million. */
const toSlider = (v: number) => (Math.log(v / MIN) / Math.log(MAX / MIN)) * 1000;
const fromSlider = (s: number) => {
  const raw = MIN * Math.pow(MAX / MIN, s / 1000);
  const step = raw < 50_000 ? 1_000 : raw < 250_000 ? 5_000 : 10_000;
  return Math.round(raw / step) * step;
};

function AnimatedNumber({ value, className }: { value: number; className?: string }) {
  const reduce = useReducedMotion();
  const [shown, setShown] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    if (reduce) {
      setShown(value);
      return;
    }
    const c = animate(prev.current, value, { duration: 0.6, ease: [0.2, 0.7, 0.2, 1], onUpdate: setShown });
    prev.current = value;
    return () => c.stop();
  }, [value, reduce]);
  return <span className={cn("tabular-nums", className)}>{formatAmount(shown)}</span>;
}

const PARTS = [
  { key: "apporteur", label: "Apporteur", cls: "bg-forest" },
  { key: "agentLocal", label: "Agent local", cls: "bg-forest/70" },
  { key: "temoins", label: "Témoins", cls: "bg-sea" },
  { key: "daman", label: "Fonds DAMAN", cls: "bg-gold/60" },
  { key: "wassala", label: "WASSALA", cls: "bg-gold" },
] as const;

/** Simulateur de commission SANAD : curseurs, corridor, répartition SILSILA, tranches AMANA et plafond DAMAN. */
export function SANADSimulator() {
  const [value, setValue] = useState(60_000);
  const [rate, setRate] = useState(4);
  const [origin, setOrigin] = useState<(typeof ORIGINS)[number]>("Sétif");
  const [destination, setDestination] = useState("Nouakchott");
  const r = useMemo(() => computeCommission(value, rate), [value, rate]);
  const tranches = useMemo(() => amanaTranches(value), [value]);
  const destCountry = COUNTRY_OF[destination] ?? "";

  const briefLink = `/app/transactions/new?${new URLSearchParams({
    role: "exportateur",
    valeur: String(value),
    origine: "Algérie",
    destination: destCountry,
  }).toString()}`;

  return (
    <section id="simulateur" className="on-ink relative overflow-hidden bg-ink-section py-24 text-bg md:py-32" aria-labelledby="simulateur-title">
      <div className="container">
        <div className="mb-14 grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-end">
          <div>
            <p className="eyebrow">Un exemple chiffré</p>
            <h2 id="simulateur-title" className="text-[clamp(34px,4.6vw,56px)] text-bg">
              Simulez la répartition.
            </h2>
          </div>
          <p className="text-lg text-bg/75">
            Exemple par défaut : vente de 60&nbsp;000&nbsp;$ de produits agroalimentaires, Sétif vers Nouakchott, commission de 4&nbsp;%. Le fonds
            DAMAN prend 0,4&nbsp;% de la valeur, le reste suit les proportions de l’exemple de référence.{" "}
            <span className="placeholder-tag">Règle à confirmer</span>
          </p>
        </div>

        <div className="grid items-start gap-6 lg:grid-cols-[1fr_1.15fr]">
          {/* Réglages */}
          <div className="rounded-2xl border border-line-dark bg-white/[.04] p-6 md:p-8">
            <div className="mb-8">
              <div className="mb-3 flex items-baseline justify-between gap-4">
                <label htmlFor="sim-value" className="font-semibold">
                  Valeur de la transaction
                </label>
                <span className="font-display text-3xl text-gold">
                  <AnimatedNumber value={value} /> $
                </span>
              </div>
              <input
                id="sim-value"
                type="range"
                min={0}
                max={1000}
                step={1}
                value={toSlider(value)}
                onChange={(e) => setValue(fromSlider(Number(e.target.value)))}
                aria-valuetext={`${formatAmount(value)} dollars`}
                className="w-full accent-[#E3B65B]"
              />
              <div className="mt-3 flex flex-wrap gap-2">
                {PRESETS.map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setValue(v)}
                    aria-pressed={v === value}
                    className={cn(
                      "min-h-10 rounded-full border px-3.5 text-sm font-semibold transition-colors",
                      v === value ? "border-gold bg-gold text-ink" : "border-line-dark text-bg/80 hover:border-gold",
                    )}
                  >
                    {formatAmount(v)} $
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-8">
              <div className="mb-3 flex items-baseline justify-between gap-4">
                <label htmlFor="sim-rate" className="font-semibold">
                  Taux de commission
                </label>
                <span className="font-display text-3xl text-gold">{rate.toLocaleString("fr-FR")} %</span>
              </div>
              <input
                id="sim-rate"
                type="range"
                min={COMMISSION_RATE_MIN}
                max={COMMISSION_RATE_MAX}
                step={0.5}
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                aria-valuetext={`${rate} pour cent`}
                className="w-full accent-[#E3B65B]"
              />
              <div className="mt-1 flex justify-between text-xs text-bg/60">
                <span>3 %</span>
                <span>5 %</span>
              </div>
            </div>

            <fieldset className="grid gap-4 sm:grid-cols-2">
              <legend className="mb-3 font-semibold">Corridor</legend>
              <div>
                <label htmlFor="sim-origin" className="mb-1.5 block text-sm text-bg/70">
                  Départ (Algérie)
                </label>
                <select id="sim-origin" value={origin} onChange={(e) => setOrigin(e.target.value as (typeof ORIGINS)[number])} className="field border-line-dark bg-ink text-bg">
                  {ORIGINS.map((o) => (
                    <option key={o}>{o}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="sim-dest" className="mb-1.5 block text-sm text-bg/70">
                  Arrivée
                </label>
                <select id="sim-dest" value={destination} onChange={(e) => setDestination(e.target.value)} className="field border-line-dark bg-ink text-bg">
                  {DESTINATIONS.map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </div>
            </fieldset>
            <p className="mt-4 flex items-start gap-2 text-sm text-bg/65">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden="true" />
              {origin} → {destination}
              {destCountry ? ` (${destCountry})` : ""} : le code SH et la liste de concessions sont relevés dans le fil de transaction pour
              déterminer le régime, préférentiel ou droit commun.
            </p>
          </div>

          {/* Résultats */}
          <div className="rounded-2xl bg-bg p-6 text-ink md:p-8" aria-live="polite">
            <div className="mb-6 flex flex-wrap items-baseline justify-between gap-3 border-b border-line pb-6">
              <span className="text-lg text-ink-soft">Commission totale</span>
              <span className="font-display text-[clamp(40px,5vw,60px)] leading-none text-forest">
                <AnimatedNumber value={r.total} /> $
              </span>
            </div>

            <div className="mb-3 flex h-4 overflow-hidden rounded-full" role="img" aria-label="Répartition de la commission">
              {PARTS.map((p) => (
                <div key={p.key} className={cn("h-full transition-[width] duration-700 ease-brand", p.cls)} style={{ width: `${r.total ? (r[p.key] / r.total) * 100 : 0}%` }} />
              ))}
            </div>
            <dl className="mb-6 divide-y divide-line">
              {PARTS.map((p) => (
                <div key={p.key} className="flex items-center justify-between gap-3 py-2.5">
                  <dt className={cn("flex items-center gap-2.5 text-[15px]", p.key === "wassala" && "font-semibold")}>
                    <span aria-hidden="true" className={cn("h-2.5 w-2.5 rounded-sm", p.cls)} />
                    {p.label}
                  </dt>
                  <dd className="font-semibold">
                    <AnimatedNumber value={r[p.key]} /> $
                  </dd>
                </div>
              ))}
            </dl>
            <p className="mb-6 rounded-lg bg-section px-4 py-3 text-sm text-ink-soft">
              WASSALA perçoit environ <strong className="text-ink">{r.wassalaShare.toLocaleString("fr-FR")} % de la valeur</strong> de la transaction,
              et seulement si elle aboutit.
            </p>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-lg border border-line p-4">
                <p className="mb-2 text-xs font-semibold uppercase tracking-[.14em] text-gold-text">AMANA · tranches</p>
                <ul className="space-y-1.5 text-sm">
                  {tranches.map((t) => (
                    <li key={t.event} className="flex justify-between gap-2">
                      <span className="text-ink-soft">
                        {t.pct} % · {t.event.split(" ")[0]}
                      </span>
                      <b>{formatAmount(t.amount)} $</b>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-lg border border-line p-4">
                <p className="mb-2 text-xs font-semibold uppercase tracking-[.14em] text-gold-text">DAMAN · garantie</p>
                <p className="text-sm text-ink-soft">
                  Contribution ({DAMAN_RANGE[0].toLocaleString("fr-FR")} à {DAMAN_RANGE[1].toLocaleString("fr-FR")} %) :{" "}
                  <b className="text-ink">
                    {formatAmount((value * DAMAN_RANGE[0]) / 100)} à {formatAmount((value * DAMAN_RANGE[1]) / 100)} $
                  </b>
                </p>
                <p className="mt-1 text-sm text-ink-soft">
                  Première perte couverte : <b className="text-ink">{formatAmount((value * DAMAN_COVER_RANGE[0]) / 100)} à {formatAmount((value * DAMAN_COVER_RANGE[1]) / 100)} $</b>. Au-delà,
                  rien n’est garanti.
                </p>
              </div>
            </div>

            <Link href={briefLink} className="btn-primary group mt-6 w-full">
              Lancer cette transaction
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
