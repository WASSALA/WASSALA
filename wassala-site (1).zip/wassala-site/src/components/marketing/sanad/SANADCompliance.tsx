import { FileCheck2, Landmark, ShieldAlert } from "lucide-react";
import { Reveal } from "@/components/motion/Reveal";

const CARDS = [
  {
    icon: FileCheck2,
    title: "Le certificat d’origine ZLECAf",
    body: "Il est exigé et vérifié par le témoin CHAHID. SANAD ne délivre jamais le certificat : cette prérogative appartient aux autorités nationales.",
  },
  {
    icon: Landmark,
    title: "AMANA et les fonds",
    body: "Les fonds sont déposés chez une banque partenaire ou un agent séquestre régulé. WASSALA ne détient jamais les fonds.",
  },
  {
    icon: ShieldAlert,
    title: "DAMAN : une limite affichée",
    body: "La couverture est plafonnée à 10 à 20 % de la valeur, sur litiges constatés par témoin. Au-delà, rien n’est garanti.",
  },
] as const;

export function SANADCompliance() {
  return (
    <section id="conformite" className="bg-section py-24 md:py-32" aria-labelledby="conformite-title">
      <div className="container grid items-start gap-14 lg:grid-cols-[1fr_1.1fr]">
        <div className="lg:sticky lg:top-40">
          <p className="eyebrow">Cadre juridique</p>
          <h2 id="conformite-title" className="mb-6 text-[clamp(34px,4.6vw,56px)]">
            Conformité ZLECAf
          </h2>
          <p className="mb-5 text-lg text-ink-soft">
            SANAD ne crée aucun droit propre. Il fait appliquer, transaction par transaction, ce que l’accord ZLECAf et le droit douanier
            prévoient déjà.
          </p>
          <p className="text-ink-soft">
            SANAD s’inscrit dans le cadre de l’accord ZLECAf (signé à Kigali le 21 mars 2018, en vigueur depuis le 30 mai 2019) et du droit
            douanier algérien. Avant toute transaction, le fil relève le code SH, la liste de concessions (A, B ou C) de chaque pays et le droit
            applicable. La transaction est étiquetée <strong className="text-ink">« préférentielle »</strong> ou{" "}
            <strong className="text-ink">« droit commun »</strong>.
          </p>
        </div>
        <ul className="space-y-4">
          {CARDS.map((c, i) => (
            <Reveal as="li" key={c.title} index={i} className="card flex gap-5 border-gold/70 p-6 md:p-8">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold/20">
                <c.icon className="h-6 w-6 text-gold-text" strokeWidth={1.6} aria-hidden="true" />
              </span>
              <div>
                <h3 className="mb-2 font-sans text-lg font-semibold">{c.title}</h3>
                <p className="text-ink-soft">{c.body}</p>
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
