import { Reveal } from "@/components/motion/Reveal";

const PROBLEMS = [
  { n: "01", title: "La confiance", body: "Prépaiement risqué, impayés, aucun recours.", answer: "AMANA · CHAHID" },
  { n: "02", title: "Les devises", body: "Inconvertibilité, double conversion, délais et coûts.", answer: "MUQASSA" },
  { n: "03", title: "Le financement", body: "Lettres de crédit inaccessibles aux PME.", answer: "Passeport de transaction" },
  { n: "04", title: "L’information", body: "Règles douanières et d’origine, frictions informelles.", answer: "Le Fil · cartes de corridor" },
  { n: "05", title: "La logistique", body: "Fragmentation, absence de suivi.", answer: "Le Fil · CHAHID" },
  { n: "06", title: "Les litiges", body: "Systèmes juridiques différents, exécution quasi impossible.", answer: "DAMAN · CHAHID" },
  { n: "07", title: "La qualité", body: "Marchandise différente de l’échantillon.", answer: "CHAHID · AMANA" },
] as const;

/** Les sept causes d'échec des transactions, chacune reliée au mécanisme SANAD qui la traite. */
export function SANADProblem() {
  return (
    <section className="bg-section py-24 md:py-32" aria-labelledby="probleme-title">
      <div className="container">
        <div className="mb-14 grid gap-8 lg:grid-cols-[1fr_1.1fr] lg:items-end">
          <div>
            <p className="eyebrow">Sept causes d’échec</p>
            <h2 id="probleme-title" className="text-[clamp(34px,4.6vw,56px)]">
              Le problème que nous résolvons
            </h2>
          </div>
          <p className="text-lg text-ink-soft">
            Chaque jour, des producteurs et des acheteurs africains veulent faire des affaires ensemble. Et chaque jour, ces transactions échouent
            pour des raisons qui n’ont rien à voir avec le produit ou le prix.
          </p>
        </div>

        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {PROBLEMS.map((p, i) => (
            <Reveal as="li" key={p.n} index={i % 4} className="spotlight card card-lift group relative flex flex-col overflow-hidden p-6">
              <p className="mb-6 font-display text-4xl text-gold-read">{p.n}</p>
              <h3 className="mb-2 text-2xl">{p.title}</h3>
              <p className="flex-1 text-ink-soft">{p.body}</p>
              <p className="mt-5 border-t border-line pt-3 text-xs font-semibold uppercase tracking-[.12em] text-forest">
                <span className="text-ink-soft">Réponse · </span>
                {p.answer}
              </p>
            </Reveal>
          ))}
          <Reveal as="li" index={3} className="on-ink flex flex-col justify-end rounded-lg bg-ink-section p-6 text-bg">
            <p className="font-display text-2xl leading-snug">
              Le commerce intra-africain est freiné d’abord par l’absence de <span className="text-gold">confiance exécutable</span> entre deux
              inconnus qui veulent conclure une vente.
            </p>
          </Reveal>
        </ul>

        <blockquote className="reveal mt-16 max-w-4xl border-s-4 border-gold ps-7">
          <p className="font-display text-[clamp(24px,2.6vw,34px)] leading-snug">
            Celui qui fabrique cette confiance, transaction après transaction, réalise l’intégration que les institutions ne font que décréter.
          </p>
        </blockquote>
      </div>
    </section>
  );
}
