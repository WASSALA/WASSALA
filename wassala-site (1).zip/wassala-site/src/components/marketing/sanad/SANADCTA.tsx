import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import { SITE } from "@/data/site";

export function SANADCTA() {
  return (
    <section className="py-24 md:py-28" aria-labelledby="sanad-cta-title">
      <div className="container">
        <div className="on-ink relative overflow-hidden rounded-2xl bg-ink-section p-8 text-bg md:p-14">
          <div aria-hidden="true" className="pattern-circles opacity-50" />
          <div className="relative grid items-end gap-10 lg:grid-cols-[1.2fr_1fr]">
            <div>
              <p className="eyebrow">Passer à l’action</p>
              <h2 id="sanad-cta-title" className="mb-4 text-[clamp(32px,4.4vw,54px)] text-bg">
                Lancer une transaction avec SANAD.
              </h2>
              <p className="max-w-xl text-bg/75">Décrivez votre activité et votre besoin. Un agent prend contact sous {SITE.responseDelay}.</p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
              <Link href="/app/transactions/new?role=exportateur" className="group flex min-h-16 items-center justify-between rounded-xl bg-gold px-6 font-semibold text-ink transition-transform hover:-translate-y-0.5">
                Devenir exportateur
                <ArrowUpRight className="h-5 w-5 transition-transform group-hover:rotate-45" aria-hidden="true" />
              </Link>
              <Link href="/app/transactions/new?role=acheteur" className="group flex min-h-16 items-center justify-between rounded-xl border border-gold/70 px-6 font-semibold text-bg transition-colors hover:bg-white/5">
                Devenir acheteur
                <ArrowUpRight className="h-5 w-5 transition-transform group-hover:rotate-45" aria-hidden="true" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
