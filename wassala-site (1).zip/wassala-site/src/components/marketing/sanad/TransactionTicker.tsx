"use client";

import { motion, useInView, useReducedMotion } from "framer-motion";
import { Check } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { TRANSACTION_STATUSES } from "@/lib/api/types";
import { cn } from "@/lib/utils";

const TRANCHES = [
  { pct: 30, label: "Inspection", at: 6 },
  { pct: 40, label: "Chargement", at: 7 },
  { pct: 30, label: "Réception", at: 8 },
] as const;

/**
 * Phases de la démonstration : 0 à 5 = du brief à l'accord ; 6 à 8 = exécution (les trois tranches AMANA
 * sont débloquées après constat du témoin) ; 9 = commission ; 10 = transaction aboutie.
 */
const LAST_PHASE = 10;
const statusOf = (phase: number) => (phase <= 5 ? phase : phase <= 8 ? 5 : phase === 9 ? 6 : 7);

/** Carte produit animée : une transaction de démonstration qui avance d'étape en étape, tranches AMANA comprises. */
export function TransactionTicker() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "-10% 0px" });
  const [phase, setPhase] = useState(reduce ? LAST_PHASE : 0);

  useEffect(() => {
    if (reduce || !inView) return;
    const id = window.setInterval(() => setPhase((p) => (p + 1) % (LAST_PHASE + 2)), 1300);
    return () => window.clearInterval(id);
  }, [reduce, inView]);

  const step = statusOf(Math.min(phase, LAST_PHASE));
  const current = Math.min(step, TRANSACTION_STATUSES.length - 1);
  const executing = phase >= 6 && phase <= 8;
  return (
    <div ref={ref} className="relative rounded-2xl border border-line bg-card p-5 shadow-lift md:p-6" aria-label="Exemple de transaction suivie dans SANAD (démonstration)" role="img">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <p className="font-mono text-xs text-ink-soft">TX-DÉMO-0001</p>
          <p className="font-semibold">Sétif → Nouakchott</p>
          <p className="text-sm text-ink-soft">Agroalimentaire · 60 000 $ · commission 4 %</p>
        </div>
        <span className="rounded-full border border-gold px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[.12em] text-gold-text">Démo</span>
      </div>

      <ol className="mb-6 space-y-2.5">
        {TRANSACTION_STATUSES.map((s, i) => {
          const done = i < step;
          const active = i === current && step < TRANSACTION_STATUSES.length;
          return (
            <li key={s.id} className="flex items-center gap-3 text-sm">
              <span
                className={cn(
                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold transition-colors duration-300",
                  done ? "border-forest bg-forest text-white" : active ? "border-forest text-forest" : "border-line text-ink-soft",
                )}
              >
                {done ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : i + 1}
              </span>
              <span className={cn("transition-colors", done || active ? "text-ink" : "text-ink-soft")}>
                {s.label}
                {active && s.id === "accord" && executing ? <span className="ms-2 text-xs text-gold-text">exécution en cours</span> : null}
              </span>
              {active ? (
                <motion.span layoutId="ticker-active" className="ms-auto h-1.5 w-1.5 rounded-full bg-gold" transition={{ duration: 0.3 }} />
              ) : null}
            </li>
          );
        })}
      </ol>

      <div className="rounded-xl bg-section p-4">
        <p className="mb-3 text-xs font-semibold uppercase tracking-[.14em] text-gold-text">AMANA · fonds en séquestre bancaire</p>
        <div className="flex gap-1.5">
          {TRANCHES.map((t) => {
            const released = phase >= t.at;
            return (
              <div key={t.label} className="min-w-0" style={{ flex: t.pct }}>
                <div className="h-2.5 overflow-hidden rounded-full bg-ink/10">
                  <div className={cn("h-full origin-left rounded-full bg-forest transition-transform duration-700 ease-brand", released ? "scale-x-100" : "scale-x-0")} />
                </div>
                <p className="mt-1.5 truncate text-[11px] text-ink-soft">
                  <b className="text-ink">{t.pct} %</b> {t.label}
                </p>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11px] text-ink-soft">WASSALA ne détient jamais les fonds.</p>
      </div>
    </div>
  );
}
