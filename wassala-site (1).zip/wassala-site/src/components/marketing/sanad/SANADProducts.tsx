import { BadgeCheck, Map } from "lucide-react";
import { Reveal } from "@/components/motion/Reveal";

export function SANADProducts() {
  return (
    <section id="produits" className="py-24 md:py-32" aria-labelledby="produits-title">
      <div className="container">
        <div className="mb-14 max-w-3xl">
          <p className="eyebrow">Au-delà de la transaction</p>
          <h2 id="produits-title" className="text-[clamp(34px,4.6vw,56px)]">
            Ce que SANAD produit
          </h2>
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <Reveal className="spotlight card card-lift p-8 md:p-10">
            <BadgeCheck className="mb-8 h-10 w-10 text-forest" strokeWidth={1.5} aria-hidden="true" />
            <h3 className="mb-3 text-3xl">Le passeport de transaction</h3>
            <p className="text-ink-soft">
              L’historique des transactions menées à terme, pondéré par la diversité des contreparties. C’est la réputation qui se construit,
              transaction après transaction. Il devient une pièce utilisable par les banques partenaires pour ouvrir le financement.
            </p>
          </Reveal>
          <Reveal index={1} className="spotlight card card-lift p-8 md:p-10">
            <Map className="mb-8 h-10 w-10 text-gold-text" strokeWidth={1.5} aria-hidden="true" />
            <h3 className="mb-3 text-3xl">Les cartes de frictions de corridor</h3>
            <p className="text-ink-soft">
              Chaque témoin documente les coûts réels, les délais et les obstacles de chaque point de passage. Ces données, documentées corridor
              par corridor, sont proposées par abonnement aux institutions, logisticiens et banques. Un produit en soi.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
