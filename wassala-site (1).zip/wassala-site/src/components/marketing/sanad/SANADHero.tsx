import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { Magnetic } from "@/components/motion/Magnetic";
import { SplitText } from "@/components/motion/SplitText";
import { Breadcrumb } from "@/components/shared/Breadcrumb";
import { GeometricPattern } from "@/components/shared/GeometricPattern";
import { TransactionTicker } from "./TransactionTicker";

export function SANADHero() {
  return (
    <section className="relative overflow-hidden border-b border-gold/60" aria-labelledby="sanad-hero-title">
      <GeometricPattern />
      <div aria-hidden="true" className="pointer-events-none absolute -end-40 top-0 h-[520px] w-[520px] rounded-full bg-gold/20 blur-[120px]" />
      <div className="container relative grid items-center gap-14 pb-20 pt-12 lg:grid-cols-[1.15fr_1fr] lg:pb-28">
        <div>
          <Breadcrumb items={[{ href: "/", label: "Accueil" }, { label: "SANAD" }]} />
          <p className="eyebrow">Finder’s Fee · ZLECAf</p>
          <h1 id="sanad-hero-title" className="mb-6 text-[clamp(42px,6.4vw,82px)] leading-[1.0] tracking-[-0.025em]">
            <span className="inline-flex items-baseline gap-3">
              SANAD
              <span lang="ar" dir="rtl" className="font-arabic text-[0.7em] text-gold-read">
                سند
              </span>
            </span>
            <span className="mt-2 block text-[0.62em] leading-[1.08]">
              <SplitText text="la confiance qui fait aboutir les transactions africaines." delay={0.15} stagger={0.045} accent={["confiance"]} accentClassName="italic text-forest" />
            </span>
          </h1>
          <p className="mb-9 max-w-2xl animate-rise text-lg text-ink-soft md:text-xl" style={{ animationDelay: ".5s" }}>
            Nous proposons un service de Finder’s Fee qui met en relation des producteurs et industriels algériens avec des investisseurs et
            importateurs du reste de l’Afrique. Nous ne créons pas seulement de la valeur, nous l’aidons à circuler.
          </p>
          <div className="flex animate-rise flex-wrap gap-3" style={{ animationDelay: ".65s" }}>
            <Magnetic>
              <Link href="/app/transactions/new" className="btn-primary group">
                Lancer une transaction
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
              </Link>
            </Magnetic>
            <Magnetic>
              <a href="#mecanismes" className="btn-outline">
                Voir les six mécanismes
              </a>
            </Magnetic>
          </div>
        </div>
        <div className="animate-rise" style={{ animationDelay: ".35s" }}>
          <TransactionTicker />
        </div>
      </div>
    </section>
  );
}
