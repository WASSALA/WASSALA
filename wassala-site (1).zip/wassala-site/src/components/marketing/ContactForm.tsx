"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { Check, Loader2, Mail, MapPin, Send } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { FORM_COUNTRIES } from "@/data/countries";
import { SITE } from "@/data/site";
import { CONTACT_SUBJECTS, contactSchema } from "@/lib/forms/schemas";
import { cn } from "@/lib/utils";

/** Formulaire de contact : validation zod partagée avec /api/contact, champ piège anti-robot, accord RGPD explicite. */
export function ContactForm({ defaultSubject }: { defaultSubject?: (typeof CONTACT_SUBJECTS)[number] }) {
  const reduce = useReducedMotion();
  const [sent, setSent] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(contactSchema),
    defaultValues: { nom: "", structure: "", email: "", telephone: "", message: "", website: "" },
  });

  const onSubmit = handleSubmit(async (data) => {
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });
      const json = (await res.json()) as { ok: boolean; reference?: string; error?: string };
      if (!res.ok || !json.ok) throw new Error(json.error ?? "Envoi impossible.");
      setSent(json.reference ?? "OK");
      reset();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Envoi impossible. Réessayez.");
    }
  });

  const err = (name: keyof typeof errors) =>
    errors[name]?.message ? (
      <p id={`${name}-error`} role="alert" className="mt-1.5 text-sm text-danger">
        {String(errors[name]?.message)}
      </p>
    ) : null;
  const aria = (name: keyof typeof errors) => ({ "aria-invalid": errors[name] ? true : undefined, "aria-describedby": errors[name] ? `${name}-error` : undefined });

  return (
    <section className="relative overflow-hidden bg-section py-24 md:py-32" id="contact" aria-labelledby="contact-title">
      <div className="container grid gap-14 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <p className="eyebrow">Contact</p>
          <h2 id="contact-title" className="mb-6 text-[clamp(36px,5vw,64px)]">
            Parlons de votre projet.
          </h2>
          <p className="mb-10 max-w-md text-lg text-ink-soft">
            Exportateur, acheteur, institution ou porteur de projet&nbsp;: une personne de l’équipe vous répond sous {SITE.responseDelay}.
          </p>
          <dl className="space-y-5">
            <div className="flex items-start gap-4">
              <MapPin className="mt-1 h-5 w-5 text-gold-text" aria-hidden="true" />
              <div>
                <dt className="font-semibold">Adresse</dt>
                <dd className="text-ink-soft">{SITE.city}</dd>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Mail className="mt-1 h-5 w-5 text-gold-text" aria-hidden="true" />
              <div>
                <dt className="font-semibold">Email</dt>
                <dd className="text-ink-soft">{SITE.email}</dd>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <span className="mt-1 flex h-5 w-5 items-center justify-center text-xs font-bold text-gold-text" aria-hidden="true">
                in
              </span>
              <div>
                <dt className="font-semibold">LinkedIn</dt>
                <dd className="text-ink-soft">{SITE.linkedin}</dd>
              </div>
            </div>
          </dl>
        </div>

        <div className="relative rounded-2xl border border-line bg-card p-6 shadow-soft md:p-10">
          <AnimatePresence mode="wait" initial={false}>
            {sent ? (
              <motion.div
                key="ok"
                role="status"
                className="flex min-h-[460px] flex-col items-center justify-center text-center"
                initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.span
                  className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-forest text-white"
                  initial={reduce ? false : { scale: 0, rotate: -40 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 260, damping: 16, delay: 0.1 }}
                >
                  <Check className="h-10 w-10" aria-hidden="true" />
                </motion.span>
                <h3 className="mb-3 text-3xl">Message envoyé.</h3>
                <p className="mb-2 max-w-sm text-ink-soft">Nous vous répondrons sous {SITE.responseDelay}.</p>
                <p className="mb-8 text-sm text-ink-soft">
                  Référence : <span className="font-mono text-ink">{sent}</span>
                </p>
                <button type="button" onClick={() => setSent(null)} className="btn-outline">
                  Envoyer un autre message
                </button>
              </motion.div>
            ) : (
              <motion.form key="form" onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2" exit={{ opacity: 0 }}>
                <div>
                  <label htmlFor="nom" className="field-label">
                    Nom *
                  </label>
                  <input id="nom" autoComplete="name" className="field" {...register("nom")} {...aria("nom")} />
                  {err("nom")}
                </div>
                <div>
                  <label htmlFor="structure" className="field-label">
                    Structure
                  </label>
                  <input id="structure" autoComplete="organization" className="field" {...register("structure")} />
                </div>
                <div>
                  <label htmlFor="email" className="field-label">
                    Email *
                  </label>
                  <input id="email" type="email" autoComplete="email" className="field" {...register("email")} {...aria("email")} />
                  {err("email")}
                </div>
                <div>
                  <label htmlFor="telephone" className="field-label">
                    Téléphone
                  </label>
                  <input id="telephone" type="tel" autoComplete="tel" className="field" {...register("telephone")} {...aria("telephone")} />
                  {err("telephone")}
                </div>
                <div>
                  <label htmlFor="pays" className="field-label">
                    Pays *
                  </label>
                  <select id="pays" className="field" defaultValue="" {...register("pays")} {...aria("pays")}>
                    <option value="" disabled>
                      Choisir
                    </option>
                    {FORM_COUNTRIES.map((p) => (
                      <option key={p}>{p}</option>
                    ))}
                  </select>
                  {err("pays")}
                </div>
                <div>
                  <label htmlFor="objet" className="field-label">
                    Objet *
                  </label>
                  <select id="objet" className="field" defaultValue={defaultSubject ?? ""} {...register("objet")} {...aria("objet")}>
                    <option value="" disabled>
                      Choisir
                    </option>
                    {CONTACT_SUBJECTS.map((o) => (
                      <option key={o}>{o}</option>
                    ))}
                  </select>
                  {err("objet")}
                </div>
                <div className="sm:col-span-2">
                  <label htmlFor="message" className="field-label">
                    Message *
                  </label>
                  <textarea id="message" rows={5} className="field resize-y" {...register("message")} {...aria("message")} />
                  {err("message")}
                </div>
                {/* Champ piège : masqué aux humains et aux lecteurs d'écran */}
                <div aria-hidden="true" className="absolute -start-[9999px] h-px w-px overflow-hidden">
                  <label htmlFor="website">Site web</label>
                  <input id="website" tabIndex={-1} autoComplete="off" {...register("website")} />
                </div>
                <div className="sm:col-span-2">
                  <label className="flex cursor-pointer items-start gap-3 text-sm text-ink-soft">
                    <input type="checkbox" className="mt-0.5 h-5 w-5 shrink-0 rounded border-line-strong" {...register("consent")} {...aria("consent")} />
                    J’accepte que WASSALA utilise ces informations pour répondre à ma demande. Elles ne sont ni vendues ni cédées.
                  </label>
                  {err("consent")}
                </div>
                <div className="sm:col-span-2">
                  <button type="submit" disabled={isSubmitting} className={cn("btn-primary w-full sm:w-auto", isSubmitting && "opacity-70")}>
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Send className="h-4 w-4 rtl:-scale-x-100" aria-hidden="true" />}
                    {isSubmitting ? "Envoi…" : "Envoyer"}
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
