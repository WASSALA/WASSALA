import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { Magnetic } from "@/components/motion/Magnetic";
import { SplitText } from "@/components/motion/SplitText";
import { AfricaMap, MapLegend } from "@/components/shared/AfricaMap";
import { GeometricPattern } from "@/components/shared/GeometricPattern";
import { getDictionary } from "@/lib/i18n/server";
import { HeroPrompt } from "./HeroPrompt";

/**
 * Ouverture de l'accueil. Message validé : des entrepreneurs qui deviennent des opérateurs économiques
 * de leur continent (et non l'inverse) ; WASSALA relie et accompagne ceux qui sont prêts (elle ne finance pas).
 */
export async function Hero() {
  const { t } = await getDictionary();
  return (
    <section className="relative overflow-hidden border-b border-gold/60" aria-labelledby="hero-title">
      <GeometricPattern />
      <div aria-hidden="true" className="pointer-events-none absolute -start-32 top-1/3 h-[420px] w-[420px] rounded-full bg-gold/20 blur-[110px]" />
      <div aria-hidden="true" className="pointer-events-none absolute -end-24 -top-24 h-[520px] w-[520px] rounded-full bg-forest/15 blur-[120px]" />

      <div className="container relative grid items-center gap-12 pb-20 pt-14 lg:grid-cols-[1.05fr_1fr] lg:gap-8 lg:pb-24 lg:pt-16">
        <div>
          <p className="eyebrow animate-rise" style={{ animationDelay: ".05s" }}>
            {t.hero.eyebrow}
          </p>
          <h1 id="hero-title" className="mb-7 text-[clamp(46px,7.2vw,92px)] leading-[0.98] tracking-[-0.03em]">
            <SplitText text={t.hero.title} delay={0.1} accent={["lien", "link", "elo", "Kiungo"]} accentClassName="italic text-forest" />
          </h1>
          <p className="mb-9 max-w-xl animate-rise text-lg text-ink-soft md:text-xl" style={{ animationDelay: ".45s" }}>
            {t.hero.lead}
          </p>
          <div className="mb-10 flex animate-rise flex-wrap gap-3" style={{ animationDelay: ".6s" }}>
            <Magnetic>
              <Link href="/sanad" className="btn-primary group">
                {t.hero.ctaPrimary}
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100 rtl:group-hover:-translate-x-1" aria-hidden="true" />
              </Link>
            </Magnetic>
            <Magnetic>
              <Link href="/projets-continentaux" className="btn-outline">
                {t.hero.ctaSecondary}
              </Link>
            </Magnetic>
          </div>
          <div className="animate-rise" style={{ animationDelay: ".75s" }}>
            <HeroPrompt />
          </div>
        </div>

        <div className="animate-rise" style={{ animationDelay: ".3s" }}>
          <AfricaMap interactive labels idPrefix="hero" className="mx-auto max-w-[640px]" />
          <MapLegend className="justify-center lg:justify-start" />
        </div>
      </div>
    </section>
  );
}
