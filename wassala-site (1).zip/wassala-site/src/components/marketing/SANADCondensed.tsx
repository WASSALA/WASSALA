"use client";

import { AnimatePresence, motion, useInView, useReducedMotion } from "framer-motion";
import { ArrowRight, ShieldCheck } from "lucide-react";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

const MECHS = [
  { id: "fil", name: "Le Fil", line: "Chaque transaction ouvre un fil numéroté : messages, photos et documents horodatés dans un registre.", node: "Registre horodaté" },
  { id: "silsila", name: "SILSILA", line: "Chaque introduction est enregistrée. La commission de 3 à 5 % est répartie selon une règle fixée à l’avance.", node: "Chaîne des apporteurs" },
  { id: "amana", name: "AMANA", line: "Les fonds sont chez une banque partenaire et débloqués par tranches : 30 %, 40 %, 30 %.", node: "Banque partenaire" },
  { id: "chahid", name: "CHAHID", line: "Un témoin local certifié constate chaque étape, preuves géolocalisées à l’appui.", node: "Constat géolocalisé" },
  { id: "muqassa", name: "MUQASSA", line: "Les flux croisés se compensent : seul le solde net traverse la frontière, via des banques agréées.", node: "Banques agréées" },
  { id: "daman", name: "DAMAN", line: "Un fonds mutuel couvre une première perte plafonnée à 10 à 20 % de la valeur. Au-delà, rien n’est garanti.", node: "Fonds DAMAN" },
] as const;

const GUARANTEES = [
  "WASSALA ne détient jamais les fonds.",
  "La limite de la garantie DAMAN est dite clairement.",
  "SANAD ne délivre jamais le certificat d’origine.",
] as const;

/**
 * SANAD présenté en condensé sur l'accueil (remplace l'ancien bloc « Trois services, un seul réseau »).
 * Les six mécanismes défilent seuls tant que l'utilisateur n'a pas choisi ; le détail est sur /sanad.
 */
export function SANADCondensed() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { margin: "-20% 0px" });
  const [active, setActive] = useState(0);
  const [auto, setAuto] = useState(true);
  const tabs = useRef<Array<HTMLButtonElement | null>>([]);
  const m = MECHS[active]!;

  useEffect(() => {
    if (!auto || reduce || !inView) return;
    const id = window.setInterval(() => setActive((n) => (n + 1) % MECHS.length), 4500);
    return () => window.clearInterval(id);
  }, [auto, reduce, inView]);

  const select = (i: number, focus = false) => {
    setAuto(false);
    setActive(i);
    if (focus) tabs.current[i]?.focus();
  };

  return (
    <section className="on-ink relative overflow-hidden bg-ink-section py-24 text-bg md:py-32" id="sanad" aria-labelledby="sanad-title">
      <div aria-hidden="true" className="pattern-circles opacity-40" />
      <div ref={ref} className="container relative grid items-center gap-14 lg:grid-cols-2">
        <div>
          <p className="eyebrow">Finder’s Fee · notre premier service</p>
          <h2 id="sanad-title" className="mb-6 text-[clamp(36px,4.8vw,60px)] text-bg">
            <span className="text-gold-gradient">SANAD</span>&nbsp;: le service Finder’s Fee.
          </h2>
          <p className="mb-8 max-w-xl text-lg text-bg/75">
            Nous conduisons une transaction commerciale entre deux inconnus africains, de l’introduction jusqu’au paiement, et nous ne nous
            rémunérons que si elle arrive à son terme.
          </p>

          <div
            role="tablist"
            aria-label="Les six mécanismes SANAD"
            className="mb-6 flex flex-wrap gap-2"
            onKeyDown={(e) => {
              if (e.key === "ArrowRight" || e.key === "ArrowDown") {
                e.preventDefault();
                select((active + 1) % MECHS.length, true);
              } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
                e.preventDefault();
                select((active - 1 + MECHS.length) % MECHS.length, true);
              }
            }}
          >
            {MECHS.map((x, i) => (
              <button
                key={x.id}
                ref={(el) => {
                  tabs.current[i] = el;
                }}
                role="tab"
                id={`mech-tab-${x.id}`}
                aria-selected={i === active}
                aria-controls="mech-panel"
                tabIndex={i === active ? 0 : -1}
                onClick={() => select(i)}
                className={cn(
                  "relative min-h-11 rounded-full border px-4 text-sm font-semibold transition-colors",
                  i === active ? "border-gold text-ink" : "border-line-dark text-bg/80 hover:border-gold/70 hover:text-bg",
                )}
              >
                {i === active ? (
                  <motion.span
                    layoutId="mech-active"
                    className="absolute inset-0 -z-0 rounded-full bg-gold"
                    transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 400, damping: 34 }}
                  />
                ) : null}
                <span className="relative">{x.name}</span>
              </button>
            ))}
          </div>

          <div id="mech-panel" role="tabpanel" aria-labelledby={`mech-tab-${m.id}`} className="mb-10 min-h-[84px] rounded-lg border border-line-dark bg-white/[.04] p-5">
            <AnimatePresence mode="wait" initial={false}>
              <motion.p
                key={m.id}
                initial={reduce ? { opacity: 0 } : { opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
                className="text-bg/85"
              >
                <strong className="text-gold">{m.name}.</strong> {m.line}
              </motion.p>
            </AnimatePresence>
          </div>

          <ul className="mb-10 space-y-3">
            {GUARANTEES.map((g) => (
              <li key={g} className="flex items-start gap-3 text-bg/85">
                <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-gold" aria-hidden="true" />
                {g}
              </li>
            ))}
          </ul>

          <div className="flex flex-wrap gap-3">
            <Link href="/sanad" className="btn-gold group">
              Découvrir SANAD
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
            </Link>
            <Link href="/app/transactions/new" className="btn-ghost-dark">
              Lancer une transaction
            </Link>
          </div>
        </div>

        {/* Schéma : acheteur, témoin, vendeur, et l'acteur propre au mécanisme choisi */}
        <div className="relative rounded-2xl border border-line-dark bg-white/[.03] p-6 md:p-8">
          <svg viewBox="0 0 400 300" role="img" aria-label={`Schéma SANAD : acheteur, témoin et vendeur reliés ; mécanisme ${m.name} : ${m.node}.`} className="h-auto w-full">
            <path d="M88 110H160M240 110H312" className="stroke-gold" strokeWidth={2} strokeDasharray="4 6" />
            <circle r={4.5} className="map-pulse fill-forest-light">
              <animateMotion dur="3s" repeatCount="indefinite" path="M88 110H312" />
            </circle>
            <circle r={4.5} className="map-pulse fill-gold">
              <animateMotion dur="3s" begin="1.5s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear" path="M88 110H312" />
            </circle>
            {(["Acheteur", "Témoin", "Vendeur"] as const).map((t, i) => {
              const cx = 60 + i * 140;
              const witness = i === 1;
              return (
                <g key={t}>
                  <circle cx={cx} cy={110} r={witness ? 40 : 34} className="fill-ink" />
                  <circle cx={cx} cy={110} r={witness ? 40 : 34} className={witness ? "fill-gold/15 stroke-gold" : "fill-none stroke-forest-light"} strokeWidth={2} />
                  <text x={cx} y={114} textAnchor="middle" className="fill-bg text-[13px] font-semibold">
                    {t}
                  </text>
                </g>
              );
            })}
            <path d="M200 150V214" className="stroke-gold/60" strokeWidth={1.5} strokeDasharray="3 5" />
            <AnimatePresence mode="wait" initial={false}>
              <motion.g
                key={m.id}
                initial={reduce ? { opacity: 0 } : { opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, y: -8 }}
                transition={{ duration: 0.35 }}
              >
                <rect x={110} y={214} width={180} height={46} rx={23} className="fill-gold" />
                <text x={200} y={242} textAnchor="middle" className="fill-ink text-[14px] font-semibold">
                  {m.node}
                </text>
              </motion.g>
            </AnimatePresence>
            <text x={200} y={40} textAnchor="middle" className="fill-bg/60 text-[12px] uppercase tracking-[.2em]">
              De l’introduction jusqu’au paiement
            </text>
          </svg>
          <div className="mt-4 flex gap-1.5" aria-hidden="true">
            {MECHS.map((x, i) => (
              <span key={x.id} className="h-1 flex-1 overflow-hidden rounded-full bg-white/10">
                <span
                  className={cn("block h-full origin-left bg-gold", i < active ? "scale-x-100" : i === active ? "" : "scale-x-0")}
                  style={i === active && auto && !reduce && inView ? { animation: "score-grow 4.5s linear both" } : undefined}
                />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
