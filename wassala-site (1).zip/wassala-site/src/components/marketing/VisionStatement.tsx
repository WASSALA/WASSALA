import { ScrollWords } from "@/components/motion/ScrollWords";

/** Manifeste : la phrase s'éclaire mot à mot au défilement. */
export function VisionStatement() {
  return (
    <section className="relative overflow-hidden py-28 md:py-40" aria-label="Vision">
      <p
        aria-hidden="true"
        lang="ar"
        className="pointer-events-none absolute inset-x-0 top-1/2 -translate-y-1/2 select-none text-center font-arabic text-[clamp(160px,30vw,420px)] leading-none text-gold/[.13]"
      >
        وصلة
      </p>
      <div className="container relative max-w-5xl text-center">
        <ScrollWords
          text="L’Afrique ne manque pas de richesses. Elle manque de liens."
          highlight={["liens"]}
          className="font-display text-[clamp(38px,6vw,80px)] font-medium leading-[1.05] tracking-[-0.02em]"
        />
        <div className="reveal mx-auto mt-12 flex max-w-md items-center gap-4" aria-hidden="true">
          <span className="h-3 w-3 rotate-45 bg-forest" />
          <span className="h-px flex-1 bg-gradient-to-r from-forest via-gold to-forest" />
          <span className="h-3 w-3 rotate-45 bg-gold" />
        </div>
        <p className="reveal mt-8 font-display text-2xl italic text-ink-soft md:text-3xl" style={{ "--i": 2 } as React.CSSProperties}>
          Un mot. Un pont. Une destinée.
        </p>
      </div>
    </section>
  );
}
