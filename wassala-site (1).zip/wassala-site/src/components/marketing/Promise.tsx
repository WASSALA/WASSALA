import { Counter } from "@/components/motion/Counter";
import { Reveal } from "@/components/motion/Reveal";
import { KEY_FIGURES } from "@/data/stats";

const LINES = [
  "Que les entrepreneurs africains deviennent des réseaux.",
  "Que les capitaux africains financent l’Afrique.",
  "Que les solutions africaines répondent aux problèmes des Africains.",
  "Que le commerce intra-africain cesse d’être une intention.",
  "Que chaque transaction aboutie devienne une preuve.",
] as const;

export function Promise() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32" aria-labelledby="promesse-title">
      <div className="container max-w-5xl">
        <div className="mb-14 text-center">
          <p className="eyebrow justify-center">La promesse</p>
          <h2 id="promesse-title" className="text-[clamp(34px,4.6vw,56px)]">
            La promesse
          </h2>
          <p className="mt-4 text-lg text-ink-soft">Nous offrons la promesse d’une Afrique nouvelle.</p>
        </div>
        <ol>
          {LINES.map((line, i) => (
            <Reveal as="li" key={line} index={0} className="group">
              <p className="flex items-baseline justify-center gap-5 py-6 text-center font-display text-[clamp(24px,3vw,36px)] leading-snug transition-colors duration-300 hover:text-forest">
                <span className="hidden font-sans text-xs font-semibold text-gold-text sm:inline">0{i + 1}</span>
                {line}
              </p>
              {i < LINES.length - 1 ? (
                <div className="rule-diamond mx-auto max-w-md opacity-70" aria-hidden="true">
                  <span />
                </div>
              ) : null}
            </Reveal>
          ))}
        </ol>

        <dl className="mt-20 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-3">
          {KEY_FIGURES.map((f) => (
            <div key={f.label} className="flex flex-col items-center bg-card px-6 py-8 text-center">
              <dt className="order-2 mt-2 text-sm text-ink-soft">{f.label}</dt>
              <dd className="font-display text-5xl text-forest">
                {f.value === null ? <span className="placeholder-tag text-xs">[placeholder]</span> : <Counter to={f.value} />}
              </dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
