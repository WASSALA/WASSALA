import type { PlatformId } from "@/data/platforms";
import { cn } from "@/lib/utils";

/** Pictogrammes des plateformes, au trait or et vert. S'animent au survol de la carte parente (.group). */
export function PlatformIcon({ kind, className }: { kind: PlatformId | "sanad"; className?: string }) {
  const stroke = { fill: "none", strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  return (
    <svg viewBox="0 0 64 64" className={cn("overflow-visible", className)} aria-hidden="true">
      {kind === "incubation" ? (
        <>
          <circle cx="32" cy="32" r="28" className="fill-forest/5 stroke-gold/50" strokeWidth="1.2" />
          <path d="M32 50V26" className="stroke-forest" strokeWidth="2.2" {...stroke} />
          <path
            d="M32 34C22 34 18 26 18 20C28 20 32 26 32 34ZM32 30C32 22 38 16 46 16C46 24 40 30 32 30Z"
            className="fill-gold/30 stroke-gold transition-transform duration-500 ease-brand [transform-origin:32px_34px] group-hover:scale-110"
            strokeWidth="1.8"
          />
          <path d="M22 50H42" className="stroke-forest" strokeWidth="2" {...stroke} />
        </>
      ) : null}
      {kind === "formation" ? (
        <>
          <circle cx="32" cy="32" r="28" className="fill-forest/5 stroke-gold/50" strokeWidth="1.2" />
          <path d="M14 26L32 18L50 26L32 34Z" className="fill-gold/25 stroke-gold" strokeWidth="1.8" {...stroke} />
          <path d="M20 29V39C26 44 38 44 44 39V29" className="stroke-forest" strokeWidth="2" {...stroke} />
          <path d="M50 26V38" className="stroke-forest transition-transform duration-500 group-hover:translate-y-1" strokeWidth="2" {...stroke} />
        </>
      ) : null}
      {kind === "investissement" ? (
        <>
          <circle cx="32" cy="32" r="28" className="fill-forest/5 stroke-gold/50" strokeWidth="1.2" />
          <path d="M16 44C24 30 40 34 48 20" className="stroke-gold" strokeWidth="2" strokeDasharray="3 4" {...stroke} />
          <circle cx="16" cy="44" r="5" className="fill-forest stroke-none transition-transform duration-500 group-hover:-translate-x-0.5" />
          <circle cx="48" cy="20" r="5" className="fill-gold stroke-none transition-transform duration-500 group-hover:translate-x-0.5" />
          <path d="M42 18L48 20L46 26" className="stroke-forest" strokeWidth="1.8" {...stroke} />
        </>
      ) : null}
      {kind === "placement" ? (
        <>
          <circle cx="32" cy="32" r="28" className="fill-forest/5 stroke-gold/50" strokeWidth="1.2" />
          <circle cx="32" cy="32" r="18" className="stroke-gold transition-transform duration-500 [transform-origin:center] group-hover:scale-110" strokeWidth="1.4" {...stroke} />
          <circle cx="32" cy="32" r="9" className="fill-gold/30 stroke-gold" strokeWidth="1.6" />
          <path d="M32 14V8M50 32H56M32 50V56M14 32H8" className="stroke-forest" strokeWidth="2" {...stroke} />
        </>
      ) : null}
      {kind === "sanad" ? (
        <>
          <circle cx="32" cy="32" r="28" className="fill-gold/15 stroke-gold" strokeWidth="1.6" />
          <path d="M14 32H50" className="stroke-gold" strokeWidth="2" strokeDasharray="3 4" {...stroke} />
          <circle cx="14" cy="32" r="5" className="fill-forest" />
          <circle cx="32" cy="32" r="6" className="fill-gold" />
          <circle cx="50" cy="32" r="5" className="fill-forest" />
        </>
      ) : null}
    </svg>
  );
}
