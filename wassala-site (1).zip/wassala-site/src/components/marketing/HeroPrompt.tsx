"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { askAssistant } from "@/lib/events";
import { useI18n } from "@/lib/i18n/I18nProvider";

const EXAMPLES = [
  "J’exporte des dattes de Biskra vers le Sénégal",
  "Je cherche un fournisseur de ciment en Algérie",
  "Comment fonctionne le séquestre AMANA ?",
  "Quels pays couvre WASSALA dans la ZLECAf ?",
] as const;

/**
 * Barre « demandez à WASSALA » de l'accueil : l'utilisateur décrit son besoin en une phrase,
 * l'assistant répond et, s'il détecte un projet d'export ou d'achat, propose un brief pré-rempli.
 */
export function HeroPrompt() {
  const reduce = useReducedMotion();
  const { t } = useI18n();
  const [value, setValue] = useState("");
  const [i, setI] = useState(0);

  useEffect(() => {
    if (reduce || value) return;
    const id = window.setInterval(() => setI((n) => (n + 1) % EXAMPLES.length), 3200);
    return () => window.clearInterval(id);
  }, [reduce, value]);

  const submit = (q: string) => {
    const question = q.trim();
    if (!question) return;
    askAssistant(question);
    setValue("");
  };

  return (
    <div className="max-w-xl">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit(value || (EXAMPLES[i] ?? ""));
        }}
        className="group relative flex items-center gap-2 rounded-xl border border-line-strong bg-card/90 p-1.5 shadow-soft transition-colors focus-within:border-forest"
      >
        <Sparkles className="ms-3 h-5 w-5 shrink-0 text-gold-text" aria-hidden="true" />
        <label htmlFor="hero-prompt" className="sr-only">
          {t.hero.promptLabel}
        </label>
        <div className="relative min-w-0 flex-1">
          <input
            id="hero-prompt"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            autoComplete="off"
            className="peer relative z-10 h-11 w-full bg-transparent text-[15px] text-ink outline-none"
          />
          {!value ? (
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={i}
                aria-hidden="true"
                className="pointer-events-none absolute inset-y-0 end-1 start-0 block truncate text-[15px] leading-[44px] text-ink-soft/80"
                initial={reduce ? { opacity: 0 } : { opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={reduce ? { opacity: 0 } : { opacity: 0, y: -10 }}
                transition={{ duration: 0.35 }}
              >
                {EXAMPLES[i]}
              </motion.span>
            </AnimatePresence>
          ) : null}
        </div>
        <button type="submit" className="btn-primary min-h-11 shrink-0 px-4 text-sm">
          <span className="hidden sm:inline">{t.hero.ask}</span>
          <ArrowRight className="h-4 w-4 rtl:-scale-x-100" aria-hidden="true" />
        </button>
      </form>
      <p className="mt-2.5 ps-1 text-[13px] text-ink-soft">
        {t.hero.promptHint}
      </p>
    </div>
  );
}
