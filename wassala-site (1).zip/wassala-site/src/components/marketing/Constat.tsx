import { ArrowUpRight } from "lucide-react";
import Link from "next/link";
import { Reveal } from "@/components/motion/Reveal";

const CARDS = [
  { title: "Entrepreneurs", body: "Des opérateurs compétents, sans réseau pour passer à l’échelle.", art: "net" },
  { title: "Capitaux", body: "Des capitaux africains qui financent rarement l’Afrique.", art: "arc" },
  { title: "Talents", body: "Une jeunesse formée, sous-valorisée localement.", art: "rise" },
  { title: "États", body: "Des traités signés, des transactions qui n’aboutissent pas.", art: "gap" },
] as const;

function Art({ kind }: { kind: (typeof CARDS)[number]["art"] }) {
  const common = { className: "fill-none stroke-gold", strokeWidth: 1.8, strokeLinecap: "round" as const };
  return (
    <svg viewBox="0 0 120 40" width="120" height="40" aria-hidden="true">
      {kind === "net" ? (
        <>
          <path d="M10 30L40 10L70 26L104 8" {...common} strokeDasharray="2 6" />
          {[
            [10, 30],
            [40, 10],
            [70, 26],
            [104, 8],
          ].map(([x, y]) => (
            <circle key={`${x}`} cx={x} cy={y} r={4} className="fill-card stroke-forest" strokeWidth={1.6} />
          ))}
        </>
      ) : null}
      {kind === "arc" ? (
        <>
          <path d="M12 32C40 0 80 0 108 32" {...common} />
          <circle cx="12" cy="32" r="3.5" className="fill-forest" />
          <circle cx="108" cy="32" r="3.5" className="fill-ink-soft/40" />
        </>
      ) : null}
      {kind === "rise" ? <path d="M6 34L36 22L58 28L112 6" {...common} /> : null}
      {kind === "gap" ? (
        <>
          <path d="M6 20H50M70 20H114" {...common} />
          <path d="M56 12V28M64 12V28" className="stroke-ink-soft/50" strokeWidth={1.4} />
        </>
      ) : null}
    </svg>
  );
}

/**
 * Le constat, suivi de deux appels à l'action distincts :
 * devenir exportateur (producteurs algériens) ou devenir acheteur (importateurs du reste de l'Afrique).
 * Chacun ouvre le brief SANAD avec le bon rôle déjà choisi.
 */
export function Constat() {
  return (
    <section className="relative py-24 md:py-32" id="constat" aria-labelledby="constat-title">
      <div className="container">
        <div className="mb-14 grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:items-end">
          <div>
            <p className="eyebrow">Quatre forces, sans lien entre elles</p>
            <h2 id="constat-title" className="text-[clamp(34px,4.6vw,56px)]">
              Le constat
            </h2>
          </div>
          <p className="text-lg text-ink-soft">
            L’Afrique détient toutes les clés de sa réussite. Nous avons la jeunesse, la connaissance, les ressources et l’espace. Mais le manque
            de liens nous pénalise dans l’exécution de notre vision. Wassala se présente comme un lien organique et vital qui permet de relier
            tout le potentiel de l’Afrique pour mettre en marche son progrès.
          </p>
        </div>

        <ul className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {CARDS.map((c, i) => (
            <Reveal as="li" key={c.title} index={i} className="spotlight card card-lift flex flex-col p-7">
              <Art kind={c.art} />
              <h3 className="mb-2 mt-6 text-2xl">{c.title}</h3>
              <p className="text-ink-soft">{c.body}</p>
            </Reveal>
          ))}
        </ul>

        <div className="mt-16">
          <p className="mb-5 font-display text-2xl md:text-3xl">Passez à l’action&nbsp;:</p>
          <div className="grid gap-5 md:grid-cols-2">
            <Reveal>
              <Link
                href="/app/transactions/new?role=exportateur"
                className="group relative flex h-full flex-col overflow-hidden rounded-xl bg-forest p-8 text-white transition-transform duration-500 ease-brand hover:-translate-y-1 md:p-10"
              >
                <span aria-hidden="true" className="absolute -end-16 -top-16 h-56 w-56 rounded-full bg-gold/25 blur-2xl transition-transform duration-700 group-hover:scale-150" />
                <span className="relative mb-10 text-sm font-semibold uppercase tracking-[.18em] text-white/75">Vous produisez en Algérie&nbsp;?</span>
                <span className="relative flex items-end justify-between gap-6">
                  <span>
                    <span className="block font-display text-[clamp(32px,4vw,48px)] leading-tight">Devenir exportateur</span>
                    <span className="mt-3 block max-w-md text-white/80">
                      Trouvez des acheteurs dans la ZLECAf. Vous êtes payé par tranches, depuis un séquestre bancaire, à chaque étape constatée.
                    </span>
                  </span>
                  <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white text-forest transition-transform duration-500 ease-brand group-hover:rotate-45">
                    <ArrowUpRight className="h-6 w-6" aria-hidden="true" />
                  </span>
                </span>
              </Link>
            </Reveal>
            <Reveal index={1}>
              <Link
                href="/app/transactions/new?role=acheteur"
                className="group relative flex h-full flex-col overflow-hidden rounded-xl border-2 border-gold bg-card p-8 text-ink transition-transform duration-500 ease-brand hover:-translate-y-1 md:p-10"
              >
                <span aria-hidden="true" className="absolute -end-16 -top-16 h-56 w-56 rounded-full bg-gold/20 blur-2xl transition-transform duration-700 group-hover:scale-150" />
                <span className="relative mb-10 text-sm font-semibold uppercase tracking-[.18em] text-gold-text">Vous importez ailleurs en Afrique&nbsp;?</span>
                <span className="relative flex items-end justify-between gap-6">
                  <span>
                    <span className="block font-display text-[clamp(32px,4vw,48px)] leading-tight">Devenir acheteur</span>
                    <span className="mt-3 block max-w-md text-ink-soft">
                      Accédez à des producteurs et industriels algériens. Vos fonds restent en séquestre et ne sont débloqués qu’aux étapes
                      constatées par un témoin.
                    </span>
                  </span>
                  <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-ink text-gold transition-transform duration-500 ease-brand group-hover:rotate-45">
                    <ArrowUpRight className="h-6 w-6" aria-hidden="true" />
                  </span>
                </span>
              </Link>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
