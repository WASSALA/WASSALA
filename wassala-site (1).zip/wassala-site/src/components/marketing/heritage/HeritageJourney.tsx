"use client";

import { motion, useReducedMotion, useScroll, useSpring } from "framer-motion";
import { useRef } from "react";
import { Counter } from "@/components/motion/Counter";
import { HIGHLIGHTS, TIMELINE } from "@/data/heritage";
import { cn } from "@/lib/utils";

/**
 * Une seule et même section : la frise chronologique (1954 → 2025), puis, dans sa continuité,
 * les sept grands moments de l'Algérie pour l'Afrique. La ligne dorée se remplit au fil de la lecture.
 */
export function HeritageJourney() {
  const reduce = useReducedMotion();
  const ref = useRef<HTMLOListElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 70%", "end 60%"] });
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 });

  return (
    <section id="frise" className="relative bg-section py-24 md:py-32" aria-labelledby="frise-title">
      <div className="container">
        {/* 1. Frise chronologique */}
        <div className="mb-16 max-w-3xl">
          <p className="eyebrow">La frise</p>
          <h2 id="frise-title" className="mb-5 text-[clamp(34px,4.6vw,56px)]">
            De 1954 à aujourd’hui
          </h2>
          <p className="text-lg text-ink-soft">
            Soixante-dix ans d’engagement africain, de la lutte de libération à la Foire du commerce intra-africain.
          </p>
        </div>

        <ol ref={ref} className="relative">
          <span aria-hidden="true" className="absolute bottom-0 start-[7px] top-0 w-[2px] bg-gold/25 md:start-[227px]" />
          {!reduce ? (
            <motion.span
              aria-hidden="true"
              className="absolute start-[7px] top-0 h-full w-[2px] origin-top bg-gradient-to-b from-forest via-gold to-gold md:start-[227px]"
              style={{ scaleY }}
            />
          ) : null}
          {TIMELINE.map((evt) => (
            <li key={evt.year} className="reveal relative grid gap-2 pb-14 ps-10 last:pb-0 md:grid-cols-[200px_1fr] md:gap-14 md:ps-0">
              <span aria-hidden="true" className="absolute start-0 top-2.5 h-4 w-4 rotate-45 border-2 border-gold bg-section md:start-[220px]" />
              <p className="font-display text-3xl leading-tight text-forest md:text-end md:text-[32px]">{evt.year}</p>
              <div>
                <h3 className="mb-3 text-2xl md:text-[28px]">{evt.title}</h3>
                <p className="max-w-2xl text-ink-soft">{evt.body}</p>
                {evt.quote ? (
                  <figure className="mt-5 max-w-2xl border-s-4 border-gold ps-5">
                    <blockquote className="font-display text-xl italic leading-snug">« {evt.quote.text} »</blockquote>
                    <figcaption className="mt-2 text-sm text-ink-soft">— {evt.quote.author}</figcaption>
                  </figure>
                ) : null}
                {evt.note ? <p className="mt-3 text-xs font-semibold uppercase tracking-[.08em] text-gold-text">{evt.note}</p> : null}
              </div>
            </li>
          ))}
        </ol>

        {/* 2. Dans la continuité de la frise : les sept grands moments */}
        <div id="moments" className="mt-24 scroll-mt-40 border-t border-gold/60 pt-16 md:mt-32">
          <div className="mb-12 grid gap-6 lg:grid-cols-[1fr_1.1fr] lg:items-end">
            <div>
              <p className="eyebrow">Sept grands moments</p>
              <h3 className="text-[clamp(30px,4vw,48px)]">Sept grands moments de l’Algérie pour l’Afrique</h3>
            </div>
            <p className="text-lg text-ink-soft">
              Du soutien aux mouvements de libération aux infrastructures qui relient physiquement l’Algérie au continent.
            </p>
          </div>

          <ol className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {HIGHLIGHTS.map((h, i) => (
              <li
                key={h.id}
                className={cn(
                  "reveal spotlight card card-lift flex flex-col p-7",
                  i === 0 && "xl:col-span-2 xl:row-span-1",
                  i === 0 && "on-ink border-transparent bg-ink-section text-bg",
                )}
                style={{ "--i": i % 3 } as React.CSSProperties}
              >
                <div className="mb-6 flex items-baseline justify-between gap-3">
                  <span className={cn("font-display text-5xl", i === 0 ? "text-gold" : "text-gold-read")}>0{i + 1}</span>
                  <span className={cn("text-end text-xs font-semibold uppercase tracking-[.14em]", i === 0 ? "text-bg/70" : "text-ink-soft")}>{h.period}</span>
                </div>
                <h4 className={cn("mb-3 font-display text-2xl leading-tight", i === 0 ? "text-bg md:text-3xl" : "")}>{h.title}</h4>
                <p className={cn("flex-1 text-[15px]", i === 0 ? "text-bg/75" : "text-ink-soft")}>{h.body}</p>
                {h.note ? <p className={cn("mt-3 text-[11px] font-semibold uppercase tracking-[.08em]", i === 0 ? "text-gold" : "text-gold-text")}>{h.note}</p> : null}
                <div className={cn("mt-6 border-t pt-5", i === 0 ? "border-line-dark" : "border-line")}>
                  <span className={cn("font-display text-4xl", i === 0 ? "text-gold" : "text-forest")}>
                    {h.kpiValue ? <Counter to={h.kpiValue} suffix={h.kpi.includes("km") ? " km" : ""} /> : h.kpi}
                  </span>
                  <span className={cn("ms-2 text-sm", i === 0 ? "text-bg/70" : "text-ink-soft")}>{h.kpiLabel}</span>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
