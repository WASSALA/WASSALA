import { Counter } from "@/components/motion/Counter";
import { Reveal } from "@/components/motion/Reveal";

const BARS = [
  { label: "Afrique", pct: 15, cls: "bg-forest" },
  { label: "Europe", pct: 60, cls: "bg-gold" },
] as const;

export function HeritageFigures() {
  return (
    <section id="chiffres" className="py-24 md:py-32" aria-labelledby="chiffres-title">
      <div className="container grid items-center gap-14 lg:grid-cols-2">
        <div>
          <p className="eyebrow">En chiffres</p>
          <h2 id="chiffres-title" className="mb-10 text-[clamp(32px,4.2vw,52px)]">
            Le commerce intra-africain en chiffres
          </h2>
          <div className="space-y-7">
            {BARS.map((b, i) => (
              <Reveal key={b.label} index={i}>
                <div className="mb-2 flex items-baseline justify-between">
                  <span className="text-lg">{b.label}</span>
                  <span className="font-display text-3xl">
                    <Counter to={b.pct} suffix=" %" />
                  </span>
                </div>
                <div className="h-4 overflow-hidden rounded-full bg-ink/10">
                  <div className={`h-full origin-left rounded-full ${b.cls}`} style={{ width: `${b.pct}%`, animation: "score-grow 1.6s cubic-bezier(.2,.7,.2,1) .2s both" }} />
                </div>
              </Reveal>
            ))}
          </div>
          <p className="mt-6 text-sm text-ink-soft">
            Part du commerce intra-régional dans le commerce total, selon le chiffre cité par le président Tebboune à l’ouverture de la 4e Foire
            du commerce intra-africain (Alger, septembre 2025).
          </p>
        </div>
        <Reveal index={1}>
          <p className="font-display text-[clamp(28px,3.4vw,44px)] leading-snug">
            Le commerce intra-africain ne représente que <span className="text-forest">15 %</span> du commerce total du continent, contre{" "}
            <span className="text-gold-read">60 %</span> en Europe.
          </p>
          <p className="mt-6 text-lg text-ink-soft">C’est cet écart que WASSALA veut réduire, une transaction aboutie après l’autre.</p>
        </Reveal>
      </div>
    </section>
  );
}
