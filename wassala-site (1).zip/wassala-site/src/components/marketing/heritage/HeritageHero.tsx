import { SplitText } from "@/components/motion/SplitText";
import { Breadcrumb } from "@/components/shared/Breadcrumb";
import { GeometricPattern } from "@/components/shared/GeometricPattern";

export function HeritageHero() {
  return (
    <section className="relative overflow-hidden border-b border-gold/60" aria-labelledby="heritage-title">
      <GeometricPattern />
      <p
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-10 end-0 select-none font-display text-[clamp(120px,22vw,320px)] leading-none tracking-tighter text-gold/15"
      >
        1954
      </p>
      <div className="container relative pb-20 pt-12 lg:pb-28">
        <Breadcrumb items={[{ href: "/", label: "Accueil" }, { label: "Héritage" }]} />
        <p className="eyebrow">Algérie &amp; panafricanisme</p>
        <h1 id="heritage-title" className="mb-7 max-w-4xl text-[clamp(42px,6.6vw,84px)] leading-[1.0] tracking-[-0.025em]">
          <SplitText text="Un peu d’histoire, pour dire pourquoi Alger." delay={0.1} accent={["Alger"]} accentClassName="italic text-forest" />
        </h1>
        <p className="max-w-2xl animate-rise text-lg text-ink-soft md:text-xl" style={{ animationDelay: ".5s" }}>
          L’Algérie est l’un des membres fondateurs de l’Organisation de l’unité africaine (OUA), devenue Union africaine (UA), et a activement
          participé à la promotion de l’intégration africaine ainsi qu’au renforcement des mécanismes institutionnels de gouvernance
          continentale.
        </p>
      </div>
    </section>
  );
}
