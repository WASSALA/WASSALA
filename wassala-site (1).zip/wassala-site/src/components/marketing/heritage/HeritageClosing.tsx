import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { SOURCES } from "@/data/heritage";

export function HeritageClosing() {
  return (
    <section className="pb-24 md:pb-32" aria-labelledby="sources-title">
      <div className="container">
        <div className="mb-12 rounded-xl border border-line bg-card p-6 md:p-8">
          <h2 id="sources-title" className="mb-3 font-sans text-sm font-semibold uppercase tracking-[.16em] text-gold-text">
            Sources
          </h2>
          <p className="text-sm text-ink-soft">
            {SOURCES.join(" · ")}. <span className="placeholder-tag">Références détaillées à reporter avant publication</span>
          </p>
        </div>
        <div className="on-ink flex flex-wrap items-center justify-between gap-8 rounded-2xl bg-ink-section p-8 text-bg md:p-12">
          <p className="max-w-xl font-display text-[clamp(28px,3.4vw,44px)] leading-tight text-bg">Cette mémoire est un point de départ.</p>
          <Link href="/sanad" className="btn-gold group">
            Découvrir SANAD
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </section>
  );
}
