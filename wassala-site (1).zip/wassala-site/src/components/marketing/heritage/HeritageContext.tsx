import { Reveal } from "@/components/motion/Reveal";

const PILLARS = [
  { period: "1954 – 1962", title: "Une lutte internationalisée", body: "Dès le premier jour, la guerre d’indépendance est portée vers l’Afrique et l’Asie." },
  { period: "1962 – 1973", title: "Une capitale des libérations", body: "Alger accueille les mouvements de libération du continent et porte des initiatives continentales." },
  { period: "1963 – aujourd’hui", title: "Un acteur de l’intégration", body: "Membre fondateur de l’OUA, devenue l’UA, puis signataire de la ZLECAf." },
] as const;

/**
 * Pourquoi cette page : faire un peu d'Histoire pour légitimer qu'une entreprise panafricaine
 * puisse s'implanter à Alger. Ce n'est pas une histoire complète.
 */
export function HeritageContext() {
  return (
    <section className="py-24 md:py-32" aria-labelledby="legitimite-title">
      <div className="container">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.15fr] lg:items-start">
          <div>
            <p className="eyebrow">Pourquoi cette page</p>
            <h2 id="legitimite-title" className="text-[clamp(32px,4.2vw,52px)]">
              Pourquoi une entreprise panafricaine peut s’implanter à Alger.
            </h2>
          </div>
          <div className="space-y-5 text-lg text-ink-soft">
            <p>
              Il s’agit ici de faire un peu d’Histoire, non pour la raconter toute entière, mais pour <strong className="text-ink">légitimer</strong>{" "}
              qu’une entreprise panafricaine puisse naître et s’implanter à Alger.
            </p>
            <p>
              Depuis 1954, l’Algérie a internationalisé sa lutte, accueilli les mouvements de libération du continent, porté des initiatives
              continentales et investi dans l’intégration africaine. Ce moment fonde un capital de légitimité que l’Algérie mobilise depuis des
              décennies. <strong className="text-ink">Wassala le met au service d’un réseau économique.</strong>
            </p>
          </div>
        </div>

        <ol className="mt-16 grid gap-5 md:grid-cols-3">
          {PILLARS.map((p, i) => (
            <Reveal as="li" key={p.title} index={i} className="spotlight card card-lift relative overflow-hidden p-8">
              <span aria-hidden="true" className="absolute end-6 top-4 font-display text-7xl text-gold/25">
                {i + 1}
              </span>
              <p className="mb-6 text-xs font-semibold uppercase tracking-[.18em] text-gold-text">{p.period}</p>
              <h3 className="mb-3 text-2xl">{p.title}</h3>
              <p className="text-ink-soft">{p.body}</p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}
