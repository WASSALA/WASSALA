"use client";

import { AnimatePresence, motion } from "framer-motion";
import { BellRing, Check, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { PLATFORMS } from "@/data/platforms";
import { cn } from "@/lib/utils";

/** « Être prévenu » : inscription à l'ouverture des plateformes (validée par /api/notify). */
export function NotifyForm() {
  const [email, setEmail] = useState("");
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [website, setWebsite] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");

  const toggle = (id: string) => setPlatforms((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/notify", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, platforms, website }),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };
      if (!res.ok || !json.ok) throw new Error(json.error ?? "Inscription impossible.");
      setState("done");
    } catch (err) {
      setState("idle");
      toast.error(err instanceof Error ? err.message : "Inscription impossible.");
    }
  };

  return (
    <section id="prevenir" className="scroll-mt-40 py-24 md:py-28" aria-labelledby="prevenir-title">
      <div className="container">
        <div className="grid items-center gap-10 rounded-2xl border border-gold/60 bg-card p-7 md:p-12 lg:grid-cols-[1fr_1.15fr]">
          <div>
            <BellRing className="mb-6 h-9 w-9 text-gold-text" strokeWidth={1.6} aria-hidden="true" />
            <h2 id="prevenir-title" className="mb-3 text-[clamp(30px,3.6vw,44px)]">
              Être prévenu.
            </h2>
            <p className="text-ink-soft">Laissez votre email : nous vous écrirons à l’ouverture de chaque plateforme. Rien d’autre.</p>
          </div>
          <AnimatePresence mode="wait" initial={false}>
            {state === "done" ? (
              <motion.p key="done" role="status" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 text-lg font-semibold text-forest">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-forest text-white">
                  <Check className="h-5 w-5" aria-hidden="true" />
                </span>
                C’est noté. Nous vous écrirons à l’ouverture.
              </motion.p>
            ) : (
              <motion.form key="form" onSubmit={submit} exit={{ opacity: 0 }} className="space-y-4">
                <fieldset>
                  <legend className="mb-3 text-sm font-semibold">Plateformes qui vous intéressent (facultatif)</legend>
                  <div className="flex flex-wrap gap-2">
                    {PLATFORMS.map((p) => {
                      const on = platforms.includes(p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          aria-pressed={on}
                          onClick={() => toggle(p.id)}
                          className={cn(
                            "inline-flex min-h-10 items-center gap-1.5 rounded-full border px-4 text-sm font-semibold transition-colors",
                            on ? "border-forest bg-forest text-white" : "border-line-strong hover:border-gold",
                          )}
                        >
                          {on ? <Check className="h-3.5 w-3.5" aria-hidden="true" /> : null}
                          {p.short}
                        </button>
                      );
                    })}
                  </div>
                </fieldset>
                <div className="flex flex-wrap gap-3">
                  <label htmlFor="notif-email" className="sr-only">
                    Votre email
                  </label>
                  <input
                    id="notif-email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="vous@exemple.com"
                    className="field min-w-[220px] flex-1"
                  />
                  <input aria-hidden="true" tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} className="absolute -start-[9999px] h-px w-px" />
                  <button type="submit" disabled={state === "sending"} className="btn-primary">
                    {state === "sending" ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : null}
                    Être prévenu
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
