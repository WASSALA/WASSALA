import { PLATFORMS } from "@/data/platforms";

const POS = [
  { x: 200, y: 52 },
  { x: 348, y: 200 },
  { x: 200, y: 348 },
  { x: 52, y: 200 },
] as const;

/** Écosystème : SANAD (ouvert) au centre, les quatre plateformes à venir en orbite. */
export function EcosystemOrbit() {
  return (
    <svg viewBox="0 0 400 400" role="img" aria-label="Écosystème WASSALA : SANAD au centre, entouré des plateformes d’incubation, de formation, d’investissement et de placement, à venir." className="h-auto w-full">
      <circle cx="200" cy="200" r="148" className="fill-none stroke-gold/40" strokeWidth="1.2" />
      <circle cx="200" cy="200" r="148" className="map-ring fill-none stroke-gold" strokeWidth="1.6" strokeDasharray="2 10" />
      <circle cx="200" cy="200" r="96" className="fill-none stroke-forest/25" strokeWidth="1" strokeDasharray="3 6" />
      {POS.map((p, i) => (
        <path key={i} d={`M200 200L${p.x} ${p.y}`} className="stroke-gold/50" strokeWidth="1.2" strokeDasharray="3 5" />
      ))}
      {POS.map((p, i) => (
        <circle key={`pulse-${i}`} r="3.5" className="map-pulse fill-forest">
          <animateMotion dur={`${2.6 + i * 0.4}s`} begin={`${i * 0.5}s`} repeatCount="indefinite" path={`M200 200L${p.x} ${p.y}`} />
        </circle>
      ))}
      <circle cx="200" cy="200" r="58" className="fill-ink" />
      <circle cx="200" cy="200" r="58" className="map-pulse fill-none stroke-gold" strokeWidth="1.5">
        <animate attributeName="r" values="58;84" dur="3s" repeatCount="indefinite" />
        <animate attributeName="opacity" values=".8;0" dur="3s" repeatCount="indefinite" />
      </circle>
      <text x="200" y="198" textAnchor="middle" className="fill-gold text-[18px] font-semibold tracking-[.12em]">
        SANAD
      </text>
      <text x="200" y="218" textAnchor="middle" className="fill-bg/80 text-[11px] uppercase tracking-[.14em]">
        Ouvert
      </text>
      {PLATFORMS.map((pl, i) => {
        const p = POS[i]!;
        return (
          <g key={pl.id}>
            <circle cx={p.x} cy={p.y} r="40" className="fill-card stroke-gold" strokeWidth="1.6" />
            <text x={p.x} y={p.y - 2} textAnchor="middle" className="fill-ink text-[11.5px] font-semibold">
              {pl.short.split(" ")[0]}
            </text>
            <text x={p.x} y={p.y + 14} textAnchor="middle" className="fill-gold-text text-[9px] font-semibold uppercase tracking-[.12em]">
              À venir
            </text>
          </g>
        );
      })}
    </svg>
  );
}
