"use client";

import { Check, Clock } from "lucide-react";
import { useActiveSection } from "@/lib/hooks/useActiveSection";
import { PLATFORMS, type PlatformId } from "@/data/platforms";
import { cn } from "@/lib/utils";
import { PlatformIcon } from "../PlatformIcon";

const IDS = PLATFORMS.map((p) => p.id);

/** Les quatre plateformes en détail, avec un sommaire collant qui suit la lecture. */
export function PlatformDetails() {
  const active = useActiveSection<PlatformId>(IDS, "incubation");

  return (
    <section className="py-24 md:py-32" aria-labelledby="plateformes-title">
      <div className="container">
        <div className="mb-16 grid gap-6 lg:grid-cols-[1fr_1.1fr] lg:items-end">
          <div>
            <p className="eyebrow">Quatre plateformes</p>
            <h2 id="plateformes-title" className="text-[clamp(34px,4.6vw,56px)]">
              Quatre plateformes, une même exigence
            </h2>
          </div>
          <p className="text-lg text-ink-soft">
            Incubation, formation, investissement, placement financier. Toutes sont en préparation et toutes sont centrées sur l’Afrique et sur
            l’éthique. SANAD est le premier service ouvert.
          </p>
        </div>

        <div className="grid gap-12 lg:grid-cols-[260px_1fr]">
          <nav aria-label="Plateformes" className="hidden lg:block">
            <ol className="sticky top-[calc(var(--header-h)+80px)] space-y-1 border-s border-line">
              {PLATFORMS.map((p) => (
                <li key={p.id}>
                  <a
                    href={`#${p.id}`}
                    aria-current={active === p.id ? "true" : undefined}
                    className={cn(
                      "-ms-px flex min-h-12 items-center gap-3 border-s-2 ps-5 text-[15px] transition-colors",
                      active === p.id ? "border-forest font-semibold text-ink" : "border-transparent text-ink-soft hover:text-ink",
                    )}
                  >
                    <span className="font-display text-gold-read">{p.n}</span>
                    {p.short}
                  </a>
                </li>
              ))}
            </ol>
          </nav>

          <div className="space-y-6">
            {PLATFORMS.map((p) => (
              <article
                key={p.id}
                id={p.id}
                className="reveal spotlight card group scroll-mt-40 overflow-hidden"
                aria-labelledby={`${p.id}-title`}
              >
                <div className="grid gap-8 p-7 md:grid-cols-[1fr_auto] md:p-10">
                  <div>
                    <div className="mb-6 flex flex-wrap items-center gap-3">
                      <span className="font-display text-5xl text-gold-read">{p.n}</span>
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-gold px-3 py-1 text-[11px] font-semibold uppercase tracking-[.12em] text-gold-text">
                        <Clock className="h-3 w-3" aria-hidden="true" />À venir
                      </span>
                    </div>
                    <h3 id={`${p.id}-title`} className="mb-4 text-[clamp(26px,2.8vw,36px)]">
                      {p.title}
                    </h3>
                    <p className="mb-4 font-display text-xl leading-snug text-forest">{p.lead}</p>
                    <p className="max-w-2xl text-ink-soft">{p.body}</p>
                  </div>
                  <PlatformIcon kind={p.id} className="h-24 w-24 md:h-32 md:w-32" />
                </div>
                <div className="grid gap-6 border-t border-line bg-bg/60 p-7 md:grid-cols-[1.3fr_1fr] md:p-10">
                  <ul className="grid gap-2.5 sm:grid-cols-2">
                    {p.items.map((it) => (
                      <li key={it} className="flex items-start gap-2.5 text-[15px]">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-forest" aria-hidden="true" />
                        <span className={it.startsWith("[") ? "text-gold-text" : ""}>{it}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="rounded-lg border-s-4 border-gold bg-card p-4">
                    <p className="mb-1 text-xs font-semibold uppercase tracking-[.14em] text-gold-text">Notre limite</p>
                    <p className="text-[15px]">
                      {p.limit} {p.limitValidated ? null : <span className="placeholder-tag">À valider</span>}
                    </p>
                  </div>
                </div>
                {p.note ? <p className="border-t border-line px-7 py-3 text-xs font-semibold uppercase tracking-[.08em] text-gold-text md:px-10">{p.note}</p> : null}
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
