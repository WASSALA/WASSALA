import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { Reveal } from "@/components/motion/Reveal";
import { PLATFORMS } from "@/data/platforms";
import { PlatformIcon } from "./PlatformIcon";

/**
 * Section « Projets continentaux » de l'accueil. Elle remplace les anciens onglets Formation et Investissement :
 * quatre plateformes centrées sur l'Afrique et sur l'éthique, toutes à venir.
 */
export function ContinentalProjects() {
  return (
    <section className="relative bg-section py-24 md:py-32" id="projets" aria-labelledby="projets-title">
      <div className="container">
        <div className="mb-14 flex flex-wrap items-end justify-between gap-8">
          <div className="max-w-2xl">
            <p className="eyebrow">Projets continentaux</p>
            <h2 id="projets-title" className="mb-5 text-[clamp(34px,4.6vw,56px)]">
              Projets continentaux
            </h2>
            <p className="text-lg text-ink-soft">
              Quatre plateformes, toutes centrées sur l’Afrique et sur l’éthique&nbsp;: incubation, formation, investissement et placement
              financier.
            </p>
          </div>
          <Link href="/projets-continentaux" className="btn-outline group">
            Découvrir les projets continentaux
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
          </Link>
        </div>

        <ol className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          {PLATFORMS.map((p, i) => (
            <Reveal as="li" key={p.id} index={i}>
              <Link
                href={`/projets-continentaux#${p.id}`}
                className="spotlight card card-lift group flex h-full flex-col gap-5 p-7"
                aria-label={`${p.short} : ${p.lead} (à venir)`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-4xl text-gold-read">{p.n}</span>
                  <span className="rounded-full border border-gold px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[.12em] text-gold-text">
                    À venir
                  </span>
                </div>
                <PlatformIcon kind={p.id} className="h-16 w-16" />
                <h3 className="text-2xl">{p.short}</h3>
                <p className="flex-1 text-[15px] text-ink-soft">{p.lead}</p>
                <span className="inline-flex items-center gap-2 text-sm font-semibold text-forest">
                  En savoir plus
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:-scale-x-100" aria-hidden="true" />
                </span>
              </Link>
            </Reveal>
          ))}
        </ol>

        <p className="mt-8 text-[15px] text-ink-soft">
          <Link href="/sanad" className="font-semibold text-forest underline decoration-gold underline-offset-4">
            SANAD
          </Link>{" "}
          est le premier service ouvert. Les plateformes ouvriront par étapes.
        </p>
      </div>
    </section>
  );
}
