import { Reveal } from "@/components/motion/Reveal";

const ROLE = [
  { verb: "Transformer", body: "des entrepreneurs en opérateurs économiques de leur continent." },
  { verb: "Relier", body: "les projets aux investisseurs africains." },
  { verb: "Accompagner", body: "ceux qui sont prêts." },
] as const;

/** Qui est WASSALA : agence de coopération, pourquoi, et le sens du mot. Textes validés par l'équipe : ne pas reformuler. */
export function AgencyBlock() {
  return (
    <section className="relative py-24 md:py-32" id="agence" aria-labelledby="agence-title">
      <div className="container">
        <div className="grid gap-5 lg:grid-cols-6">
          {/* L'agence */}
          <Reveal className="spotlight card overflow-hidden p-8 md:p-12 lg:col-span-4">
            <p className="eyebrow">L’agence</p>
            <h2 id="agence-title" className="mb-6 max-w-2xl text-[clamp(34px,4.4vw,54px)]">
              Une agence de coopération à portée panafricaine.
            </h2>
            <p className="max-w-2xl text-lg text-ink-soft md:text-xl">
              Wassala est une agence de coopération à portée panafricaine basée à Alger, capitale de l’Algérie. Elle a pour rôle de stimuler
              la coopération en Afrique à travers les <strong className="font-semibold text-ink">flux commerciaux</strong> entre l’Algérie et
              le reste du continent.
            </p>
            <svg viewBox="0 0 600 60" className="mt-10 h-auto w-full max-w-xl" aria-hidden="true">
              <circle cx="14" cy="30" r="7" className="fill-forest" />
              <circle cx="586" cy="30" r="7" className="fill-gold" />
              <path d="M24 30C180 -8 420 68 576 30" className="fill-none stroke-gold" strokeWidth="1.6" strokeDasharray="3 7" />
              <circle r="4" className="map-pulse fill-forest-dark">
                <animateMotion dur="3.6s" repeatCount="indefinite" path="M24 30C180 -8 420 68 576 30" />
              </circle>
              <circle r="4" className="map-pulse fill-[#B8860B]">
                <animateMotion dur="3.6s" begin="1.8s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear" path="M24 30C180 -8 420 68 576 30" />
              </circle>
            </svg>
            <div className="mt-3 flex max-w-xl justify-between text-xs font-semibold uppercase tracking-[.18em] text-ink-soft">
              <span>Algérie</span>
              <span>Reste du continent</span>
            </div>
          </Reveal>

          {/* Notre rôle */}
          <Reveal index={1} className="on-ink relative overflow-hidden rounded-lg bg-ink-section p-8 text-bg md:p-10 lg:col-span-2">
            <p className="eyebrow">Notre rôle</p>
            <ol className="space-y-6">
              {ROLE.map((r, i) => (
                <li key={r.verb} className="border-b border-line-dark pb-5 last:border-0 last:pb-0">
                  <p className="mb-1 flex items-baseline gap-3 font-display text-3xl text-bg">
                    <span className="font-sans text-xs font-semibold text-gold">0{i + 1}</span>
                    {r.verb}
                  </p>
                  <p className="text-bg/75">{r.body}</p>
                </li>
              ))}
            </ol>
          </Reveal>

          {/* Pourquoi */}
          <Reveal index={2} className="spotlight card p-8 md:p-10 lg:col-span-3">
            <p className="eyebrow">Pourquoi&nbsp;?</p>
            <p className="mb-5 font-display text-2xl leading-snug md:text-[28px]">
              Nous sommes une équipe d’Algériens profondément inspirés par le panafricanisme. Wassala n’a de cesse de vouloir contribuer au
              rayonnement de l’Afrique et de ses peuples.
            </p>
            <p className="text-ink-soft">
              Nous avons un objectif&nbsp;: atteindre un niveau de développement conséquent de l’Afrique pour affirmer notre dignité et nos
              convictions dans le monde. Nous croyons fermement que l’union fait la force&nbsp;: le partage de connaissance, de ressources, et
              d’une vision commune va permettre à l’Afrique de s’inscrire comme un acteur à part entière de l’évolution du monde ces prochaines
              décennies.
            </p>
          </Reveal>

          {/* Créer du lien */}
          <Reveal index={3} className="spotlight card relative overflow-hidden p-8 md:p-10 lg:col-span-3">
            <p className="eyebrow">Créer du lien</p>
            <div className="mb-6 flex items-end gap-5">
              <span lang="ar" dir="rtl" className="font-arabic text-7xl leading-none text-gold-read md:text-8xl">
                وصلة
              </span>
              <span className="pb-2 text-sm text-ink-soft">
                <em>wassala</em>
                <br />« un lien »
              </span>
            </div>
            <p className="text-ink-soft">
              Wassala signifie un lien en langue arabe. C’est donc une agence dont l’objectif premier est de créer du lien. Wassala transforme
              de simples entrepreneurs en véritables opérateurs économiques de développement pour leur continent.
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
