import { cn } from "@/lib/utils";

/**
 * Bloc qui apparaît au défilement (voir InteractionLayer et la classe .reveal de globals.css).
 * `index` décale l'apparition dans une grille (80 ms par rang).
 */
export function Reveal({
  as: Tag = "div",
  index = 0,
  className,
  children,
  ...rest
}: { as?: "div" | "li" | "article" | "section" | "p"; index?: number; className?: string; children: React.ReactNode } & React.HTMLAttributes<HTMLElement>) {
  return (
    <Tag className={cn("reveal", className)} style={{ "--i": index } as React.CSSProperties} {...rest}>
      {children}
    </Tag>
  );
}
