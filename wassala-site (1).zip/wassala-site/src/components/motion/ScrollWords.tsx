"use client";

import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { useRef } from "react";
import { cn } from "@/lib/utils";

interface ScrollWordsProps {
  text: string;
  className?: string;
  /** Mots (sans ponctuation) qui passent en or une fois éclairés. */
  highlight?: readonly string[];
}

function Word({ children, progress, range, gold }: { children: string; progress: MotionValue<number>; range: [number, number]; gold: boolean }) {
  const opacity = useTransform(progress, range, [0.16, 1]);
  const y = useTransform(progress, range, [8, 0]);
  return (
    <motion.span style={{ opacity, y }} className={cn("inline-block", gold && "text-gold-read")}>
      {children}
    </motion.span>
  );
}

/** Phrase dont les mots s'éclairent au rythme du défilement. Mouvement réduit : texte statique. */
export function ScrollWords({ text, className, highlight = [] }: ScrollWordsProps) {
  const ref = useRef<HTMLParagraphElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 85%", "end 45%"] });
  const words = text.split(" ");

  if (reduce) {
    return <p className={className}>{text}</p>;
  }
  return (
    <p ref={ref} className={className}>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">
        {words.map((w, i) => {
          const start = i / words.length;
          const end = start + 1 / words.length;
          return (
            <span key={`${w}-${i}`}>
              <Word progress={scrollYProgress} range={[start, end]} gold={highlight.includes(w.replace(/[.,;:!?]/g, ""))}>
                {w}
              </Word>
              {i < words.length - 1 ? " " : ""}
            </span>
          );
        })}
      </span>
    </p>
  );
}
