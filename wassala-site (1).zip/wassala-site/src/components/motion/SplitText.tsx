import { cn } from "@/lib/utils";

interface SplitTextProps {
  text: string;
  className?: string;
  /** Délai initial en secondes. */
  delay?: number;
  /** Écart entre deux mots en secondes. */
  stagger?: number;
  /** Mots (sans ponctuation) à mettre en valeur. */
  accent?: readonly string[];
  accentClassName?: string;
}

/**
 * Titre dont les mots montent un à un derrière un masque. CSS pur : fonctionne sans JavaScript,
 * neutralisé par prefers-reduced-motion (globals.css). Le texte complet reste lisible par les lecteurs d'écran.
 */
export function SplitText({ text, className, delay = 0, stagger = 0.06, accent = [], accentClassName = "text-forest" }: SplitTextProps) {
  const words = text.split(" ");
  return (
    <span className={className}>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">
        {words.map((w, i) => {
          const bare = w.replace(/[.,;:!?’']/g, "");
          return (
            <span key={`${w}-${i}`} className="inline-block overflow-hidden pb-[0.08em] align-bottom">
              <span
                className={cn("inline-block animate-rise", accent.includes(bare) && accentClassName)}
                style={{ animationDelay: `${(delay + i * stagger).toFixed(2)}s` }}
              >
                {w}
                {i < words.length - 1 ? " " : ""}
              </span>
            </span>
          );
        })}
      </span>
    </span>
  );
}
