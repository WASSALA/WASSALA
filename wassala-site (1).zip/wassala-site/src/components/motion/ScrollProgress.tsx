"use client";

import { motion, useReducedMotion, useScroll, useSpring } from "framer-motion";

/** Fine barre dorée en haut de l'écran : progression de lecture de la page. */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 180, damping: 30, restDelta: 0.001 });
  const reduce = useReducedMotion();
  if (reduce) return null;
  return (
    <motion.div
      aria-hidden="true"
      className="fixed inset-x-0 top-0 z-[60] h-[3px] origin-left bg-gradient-to-r from-forest via-gold to-gold rtl:origin-right"
      style={{ scaleX }}
    />
  );
}
