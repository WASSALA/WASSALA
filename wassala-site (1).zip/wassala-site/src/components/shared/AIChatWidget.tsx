"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { RotateCcw, Sparkles, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { suggestionsFor } from "@/data/knowledge";
import { useAssistant } from "@/lib/ai/useAssistant";
import { ASK_ASSISTANT_EVENT, type AskAssistantDetail } from "@/lib/events";
import { useI18n } from "@/lib/i18n/I18nProvider";
import { cn } from "@/lib/utils";
import { ChatComposer } from "./ChatComposer";
import { ChatThread } from "./ChatThread";
import { Logo } from "./Logo";

/**
 * Assistant WASSALA : panneau latéral, réponses en flux, suggestions selon la page,
 * et actions concrètes (brief pré-rempli, liens) sous chaque réponse.
 * Connecté à Claude si ANTHROPIC_API_KEY est configurée, sinon répond depuis la base de connaissances.
 */
export function AIChatWidget() {
  const pathname = usePathname();
  const { t, locale } = useI18n();
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);
  const { messages, busy, mode, ask, stop, reset, loadMode } = useAssistant({ storageKey: "wassala-assistant-v1", pathname, locale });
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const suggestions = suggestionsFor(pathname);

  useEffect(() => {
    if (open) loadMode();
  }, [open, loadMode]);

  useEffect(() => {
    if (!open) return;
    const id = window.setTimeout(() => inputRef.current?.focus(), 80);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        launcherRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.clearTimeout(id);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: reduce ? "auto" : "smooth" });
  }, [messages, reduce]);

  useEffect(() => {
    const onAsk = (e: Event) => {
      const q = (e as CustomEvent<AskAssistantDetail>).detail?.question;
      setOpen(true);
      if (q) void ask(q);
    };
    window.addEventListener(ASK_ASSISTANT_EVENT, onAsk);
    return () => window.removeEventListener(ASK_ASSISTANT_EVENT, onAsk);
  }, [ask]);

  const close = () => {
    setOpen(false);
    launcherRef.current?.focus();
  };

  return (
    <>
      <motion.button
        ref={launcherRef}
        type="button"
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-hidden={open || undefined}
        tabIndex={open ? -1 : 0}
        className={cn(
          "group fixed bottom-5 end-5 z-30 inline-flex h-14 items-center gap-2.5 rounded-full border border-gold/50 bg-ink pe-2 ps-2 font-semibold text-bg shadow-lift transition-colors hover:bg-forest-dark sm:pe-5 md:bottom-6 md:end-6",
          open && "pointer-events-none",
        )}
        initial={reduce ? { opacity: 0 } : { opacity: 0, y: 20, scale: 0.9 }}
        animate={open ? { opacity: 0, y: 20, scale: 0.9 } : { opacity: 1, y: 0, scale: 1 }}
        transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 300, damping: 24 }}
      >
        <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-gold text-ink">
          <Sparkles className="h-5 w-5 transition-transform duration-500 group-hover:rotate-[20deg]" aria-hidden="true" />
          {!reduce ? <span aria-hidden="true" className="absolute inset-0 animate-ping rounded-full bg-gold/40 [animation-duration:2.4s]" /> : null}
        </span>
        <span className="max-sm:sr-only">{t.assistant.open}</span>
      </motion.button>

      <AnimatePresence>
        {open ? (
          <motion.aside
            role="dialog"
            aria-label={t.assistant.title}
            className="fixed inset-0 z-50 flex flex-col bg-bg shadow-lift sm:inset-y-3 sm:end-3 sm:start-auto sm:w-[440px] sm:rounded-2xl sm:border sm:border-line"
            initial={reduce ? { opacity: 0 } : { opacity: 0, x: 40, scale: 0.98 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, x: 40, scale: 0.98 }}
            transition={{ duration: reduce ? 0 : 0.35, ease: [0.2, 0.7, 0.2, 1] }}
          >
            <header className="flex items-center gap-3 border-b border-line px-5 py-4">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-ink">
                <Logo size={20} withWord={false} />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="font-sans text-base font-semibold">{t.assistant.title}</h2>
                <p className="flex items-center gap-1.5 truncate text-xs text-ink-soft">
                  <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", mode === "live" ? "bg-forest" : "bg-gold")} aria-hidden="true" />
                  {mode === "live" ? t.assistant.subtitleLive : t.assistant.subtitleLocal}
                </p>
              </div>
              {messages.length > 0 ? (
                <button
                  type="button"
                  onClick={() => {
                    reset();
                    inputRef.current?.focus();
                  }}
                  aria-label={t.assistant.reset}
                  title={t.assistant.reset}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-md text-ink-soft hover:bg-section hover:text-ink"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                </button>
              ) : null}
              <button type="button" onClick={close} aria-label={t.assistant.close} className="inline-flex h-10 w-10 items-center justify-center rounded-md hover:bg-section">
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </header>

            <div ref={listRef} className="flex-1 space-y-5 overflow-y-auto px-5 py-5" aria-live="polite" aria-busy={busy}>
              {messages.length === 0 ? (
                <div className="pt-4">
                  <p className="mb-2 font-display text-3xl">Bonjour.</p>
                  <p className="text-[15px] text-ink-soft">{t.assistant.empty}</p>
                </div>
              ) : null}
              <ChatThread messages={messages} onAction={() => setOpen(false)} thinkingLabel={t.assistant.thinking} />
            </div>

            <div className="border-t border-line px-4 pb-4 pt-3">
              {!busy ? (
                <div className="no-scrollbar -mx-1 mb-3 flex gap-2 overflow-x-auto px-1">
                  {suggestions.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => void ask(s.question)}
                      className="min-h-9 shrink-0 rounded-full border border-line bg-card px-3.5 text-[13px] text-ink-soft transition-colors hover:border-gold hover:text-ink"
                    >
                      {s.question}
                    </button>
                  ))}
                </div>
              ) : null}
              <ChatComposer
                id="assistant-input"
                ref={inputRef}
                busy={busy}
                placeholder={t.assistant.placeholder}
                sendLabel={t.assistant.send}
                stopLabel={t.assistant.stop}
                onSend={(text) => void ask(text)}
                onStop={stop}
              />
              <p className="mt-2 text-center text-[11px] text-ink-soft">{t.assistant.disclaimer}</p>
            </div>
          </motion.aside>
        ) : null}
      </AnimatePresence>
    </>
  );
}
