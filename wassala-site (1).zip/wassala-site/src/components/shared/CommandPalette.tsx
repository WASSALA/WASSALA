"use client";

import { Command } from "cmdk";
import { ArrowRight, CornerDownLeft, FileText, Hash, LayoutDashboard, Sparkles, Wand2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { briefHref, describeIntent, detectIntent, isBriefIntent } from "@/lib/ai/intent";
import { OPEN_PALETTE_EVENT, askAssistant } from "@/lib/events";
import { useI18n } from "@/lib/i18n/I18nProvider";

interface Entry {
  href: string;
  label: string;
  hint?: string;
  keywords?: string;
}

const PAGES: readonly Entry[] = [
  { href: "/", label: "Accueil", keywords: "home wassala agence" },
  { href: "/sanad", label: "SANAD · Finder’s Fee", keywords: "transaction service sanad" },
  { href: "/heritage", label: "Héritage", keywords: "histoire alger algerie" },
  { href: "/projets-continentaux", label: "Projets continentaux", keywords: "incubation formation investissement placement" },
  { href: "/mentions-legales", label: "Mentions légales", keywords: "rgpd donnees" },
];

const SECTIONS: readonly Entry[] = [
  { href: "/#perimetre", label: "Notre périmètre : la ZLECAf", hint: "Accueil" },
  { href: "/#constat", label: "Le constat · devenir exportateur ou acheteur", hint: "Accueil" },
  { href: "/#contact", label: "Nous contacter", hint: "Accueil" },
  { href: "/sanad#mecanismes", label: "Les six mécanismes", hint: "SANAD" },
  { href: "/sanad#amana", label: "AMANA · le séquestre à étapes", hint: "SANAD", keywords: "fonds paiement escrow" },
  { href: "/sanad#daman", label: "DAMAN · la tontine de transaction", hint: "SANAD", keywords: "garantie" },
  { href: "/sanad#chahid", label: "CHAHID · le témoin local", hint: "SANAD" },
  { href: "/sanad#muqassa", label: "MUQASSA · la compensation de flux", hint: "SANAD" },
  { href: "/sanad#simulateur", label: "Simulateur de commission", hint: "SANAD", keywords: "prix cout combien" },
  { href: "/sanad#conformite", label: "Conformité ZLECAf", hint: "SANAD", keywords: "certificat origine" },
  { href: "/heritage#frise", label: "La frise, de 1954 à aujourd’hui", hint: "Héritage" },
  { href: "/heritage#moments", label: "Les sept grands moments", hint: "Héritage" },
  { href: "/projets-continentaux#incubation", label: "Incubation", hint: "Projets continentaux" },
  { href: "/projets-continentaux#formation", label: "Formation", hint: "Projets continentaux" },
  { href: "/projets-continentaux#investissement", label: "Investissement", hint: "Projets continentaux" },
  { href: "/projets-continentaux#placement", label: "Placement éthique", hint: "Projets continentaux" },
  { href: "/projets-continentaux#prevenir", label: "Être prévenu de l’ouverture", hint: "Projets continentaux" },
];

const APP: readonly Entry[] = [
  { href: "/app", label: "Tableau de bord" },
  { href: "/app/transactions/new?role=exportateur", label: "Devenir exportateur · nouveau brief", hint: "Nouveau" },
  { href: "/app/transactions/new?role=acheteur", label: "Devenir acheteur · nouveau brief", hint: "Nouveau" },
  { href: "/app/transactions", label: "Transactions" },
  { href: "/app/matching", label: "Matching et score de préparation" },
  { href: "/app/veille", label: "Veille : appels d’offres" },
  { href: "/app/coaching", label: "Coaching à la mise en relation" },
  { href: "/app/kyc", label: "Vérification KYC/KYB" },
  { href: "/app/deal-house", label: "Deal House" },
  { href: "/app/deal-room", label: "Deal Room" },
  { href: "/app/annuaire/agents", label: "Annuaire : agents locaux" },
  { href: "/app/annuaire/ambassades", label: "Annuaire : ambassades" },
  { href: "/app/market-intel", label: "Market Intelligence" },
  { href: "/app/offline", label: "Mode SMS / USSD" },
  { href: "/app/settings", label: "Réglages" },
];

const groupCls =
  "[&_[cmdk-group-heading]]:px-3 [&_[cmdk-group-heading]]:pb-1.5 [&_[cmdk-group-heading]]:pt-3 [&_[cmdk-group-heading]]:text-[11px] [&_[cmdk-group-heading]]:font-semibold [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-[.16em] [&_[cmdk-group-heading]]:text-gold-text";
const itemCls =
  "group flex min-h-11 cursor-pointer items-center gap-3 rounded-lg px-3 text-[15px] text-ink data-[selected=true]:bg-section data-[selected=true]:text-ink";

/**
 * Palette de commandes (Ctrl/Cmd + K, ou « / ») : navigation, sections, application,
 * et IA : une phrase comme « j'exporte du ciment vers la Mauritanie » propose un brief pré-rempli,
 * toute question peut être envoyée à l'assistant.
 */
export function CommandPalette() {
  const router = useRouter();
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const typing = target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName));
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "/" && !typing) {
        e.preventDefault();
        setOpen(true);
      }
    };
    const onOpen = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener(OPEN_PALETTE_EVENT, onOpen);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener(OPEN_PALETTE_EVENT, onOpen);
    };
  }, []);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  const intent = useMemo(() => (query.trim().length > 8 ? detectIntent(query) : null), [query]);
  const showBrief = intent ? isBriefIntent(intent) : false;

  const go = useCallback(
    (href: string) => {
      setOpen(false);
      router.push(href);
    },
    [router],
  );

  const renderGroup = (heading: string, items: readonly Entry[], icon: React.ReactNode) => (
    <Command.Group heading={heading} className={groupCls}>
      {items.map((it) => (
        <Command.Item key={it.href} value={`${it.label} ${it.hint ?? ""} ${it.keywords ?? ""} ${it.href}`} onSelect={() => go(it.href)} className={itemCls}>
          <span className="text-ink-soft group-data-[selected=true]:text-gold-text">{icon}</span>
          <span className="flex-1 truncate">{it.label}</span>
          {it.hint ? <span className="text-xs text-ink-soft">{it.hint}</span> : null}
        </Command.Item>
      ))}
    </Command.Group>
  );

  return (
    <Command.Dialog
      open={open}
      onOpenChange={setOpen}
      label="Recherche globale"
      overlayClassName="fixed inset-0 z-[70] bg-ink/40 backdrop-blur-[2px]"
      contentClassName="fixed start-1/2 top-[12vh] z-[70] w-[min(680px,94vw)] -translate-x-1/2 overflow-hidden rounded-2xl border border-line bg-bg shadow-lift rtl:translate-x-1/2"
    >
      <div className="flex items-center gap-3 border-b border-line px-5">
        <Sparkles className="h-5 w-5 shrink-0 text-gold-text" aria-hidden="true" />
        <Command.Input
          value={query}
          onValueChange={setQuery}
          placeholder={t.palette.placeholder}
          className="h-14 w-full bg-transparent text-base outline-none placeholder:text-ink-soft/70"
        />
        <kbd className="hidden rounded border border-line px-1.5 py-0.5 text-[11px] text-ink-soft sm:inline">Esc</kbd>
      </div>

      <Command.List className="max-h-[min(60vh,520px)] overflow-y-auto p-2">
        {showBrief && intent ? (
          <Command.Group heading={t.palette.actions} className={groupCls} forceMount>
            <Command.Item value={`__brief__ ${query}`} forceMount onSelect={() => go(briefHref(intent, query))} className={itemCls}>
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-ink text-gold">
                <Wand2 className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="flex-1">
                <span className="block font-semibold">{t.palette.suggested}</span>
                <span className="block truncate text-sm text-ink-soft">{describeIntent(intent)}</span>
              </span>
              <ArrowRight className="h-4 w-4 text-ink-soft rtl:-scale-x-100" aria-hidden="true" />
            </Command.Item>
          </Command.Group>
        ) : null}

        {renderGroup(t.palette.pages, PAGES, <FileText className="h-4 w-4" aria-hidden="true" />)}
        {renderGroup("Sections", SECTIONS, <Hash className="h-4 w-4" aria-hidden="true" />)}
        {renderGroup(t.palette.app, APP, <LayoutDashboard className="h-4 w-4" aria-hidden="true" />)}

        {query.trim() ? (
          <Command.Group heading={t.palette.askAssistant} className={groupCls} forceMount>
            <Command.Item
              value={`__ask__ ${query}`}
              forceMount
              onSelect={() => {
                setOpen(false);
                askAssistant(query);
              }}
              className={itemCls}
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-gold text-ink">
                <Sparkles className="h-4 w-4" aria-hidden="true" />
              </span>
              <span className="flex-1 truncate">
                {t.palette.askAssistant} : <span className="font-semibold">« {query} »</span>
              </span>
              <CornerDownLeft className="h-4 w-4 text-ink-soft" aria-hidden="true" />
            </Command.Item>
          </Command.Group>
        ) : null}
      </Command.List>

      <div className="flex items-center justify-between border-t border-line px-4 py-2.5 text-xs text-ink-soft">
        <span>{t.palette.hint}</span>
        <span className="hidden items-center gap-1 sm:flex">
          <Sparkles className="h-3 w-3 text-gold-text" aria-hidden="true" /> IA
        </span>
      </div>
    </Command.Dialog>
  );
}
