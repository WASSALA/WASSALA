import { cn } from "@/lib/utils";

/**
 * Motif signature : cercles concentriques (rayons 30, 20, 10 ; tuile 72 px ; trait 1,4 px ; or à 22 %).
 * Calque décoratif, estompé vers le bas. À placer comme frère d'un contenu, dans un parent « relative ».
 * RÈGLE : ne jamais le placer derrière un paragraphe de texte.
 */
export function GeometricPattern({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn("pattern-circles", className)} />;
}
