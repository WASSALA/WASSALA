import Link from "next/link";
import { CONTINENTAL_ANCHORS, NAV_ITEMS, SITE } from "@/data/site";
import { getDictionary } from "@/lib/i18n/server";
import { Logo } from "./Logo";

/** Pied de page en 4 colonnes : marque | navigation | projets continentaux | contact et mentions. */
export async function Footer() {
  const { t } = await getDictionary();
  const linkCls = "inline-flex min-h-10 items-center text-bg/70 transition-colors hover:text-gold";
  return (
    <footer className="on-ink relative overflow-hidden bg-ink text-bg">
      <div aria-hidden="true" className="pointer-events-none absolute -end-40 -top-40 h-[520px] w-[520px] rounded-full bg-forest/30 blur-3xl" />
      <div className="container relative grid gap-12 pb-12 pt-20 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <Logo size={38} className="text-bg" />
          <p className="mt-5 max-w-[300px] font-display text-2xl leading-snug text-bg">{t.tagline}</p>
          <p className="mt-4 max-w-[320px] text-[15px] text-bg/65">
            Agence de coopération à portée panafricaine, basée à Alger.
          </p>
        </div>

        <nav aria-label={t.footer.navigation}>
          <h2 className="mb-3 font-sans text-xs font-semibold uppercase tracking-[.2em] text-gold">{t.footer.navigation}</h2>
          <ul>
            <li>
              <Link href="/" className={linkCls}>
                {t.nav.home}
              </Link>
            </li>
            {NAV_ITEMS.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className={linkCls}>
                  {t.nav[l.key]}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label={t.footer.projects}>
          <h2 className="mb-3 font-sans text-xs font-semibold uppercase tracking-[.2em] text-gold">{t.footer.projects}</h2>
          <ul>
            {CONTINENTAL_ANCHORS.map((l) => (
              <li key={l.href}>
                <Link href={l.href} className={linkCls}>
                  {t.footer[l.key]}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="mb-3 font-sans text-xs font-semibold uppercase tracking-[.2em] text-gold">{t.footer.contact}</h2>
          <ul className="space-y-1 text-bg/70">
            <li className="min-h-10 py-2">{SITE.city}</li>
            <li className="min-h-10 py-2">{SITE.email}</li>
            <li className="min-h-10 py-2">{SITE.linkedin}</li>
            <li>
              <Link href="/mentions-legales" className={linkCls}>
                {t.footer.legal}
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="container relative">
        <p
          aria-hidden="true"
          className="select-none overflow-hidden whitespace-nowrap font-display text-[clamp(64px,15vw,220px)] font-medium leading-[.85] tracking-tight text-bg/[.06]"
        >
          WASSALA <span lang="ar" className="font-arabic">وصلة</span>
        </p>
      </div>

      <div className="border-t border-line-dark">
        <div className="container flex flex-wrap items-center justify-between gap-3 py-6 text-sm text-bg/60">
          <span>
            © {SITE.year} WASSALA. {t.footer.rights}
          </span>
          <span className="font-display text-base text-bg/80">{t.tagline}</span>
        </div>
      </div>
    </footer>
  );
}
