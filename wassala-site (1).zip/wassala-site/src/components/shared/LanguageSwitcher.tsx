"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { useI18n } from "@/lib/i18n/I18nProvider";
import { LOCALES, LOCALE_COOKIE, LOCALE_LABELS, type Locale } from "@/lib/locale";
import { cn } from "@/lib/utils";

interface LanguageSwitcherProps {
  /** compact : FR · EN · عربي (en-tête). full : les cinq langues (réglages). */
  variant?: "compact" | "full";
  className?: string;
}

const COMPACT: readonly Locale[] = ["fr", "en", "ar"];

/** Change la langue en posant un cookie, puis relit la page côté serveur (lang et dir corrects, sans clignotement). */
export function LanguageSwitcher({ variant = "compact", className }: LanguageSwitcherProps) {
  const router = useRouter();
  const { locale, t } = useI18n();
  const [pending, startTransition] = useTransition();

  const choose = (code: Locale) => {
    if (code === locale) return;
    document.cookie = `${LOCALE_COOKIE}=${code}; path=/; max-age=31536000; samesite=lax`;
    startTransition(() => router.refresh());
  };

  const list = variant === "full" ? LOCALES : COMPACT;
  return (
    <div
      role="group"
      aria-label={t.nav.language}
      aria-busy={pending || undefined}
      className={cn("inline-flex items-center rounded-full border border-line p-0.5", pending && "opacity-60", className)}
    >
      {list.map((code) => {
        const active = code === locale;
        return (
          <button
            key={code}
            type="button"
            onClick={() => choose(code)}
            aria-pressed={active}
            lang={code}
            title={LOCALE_LABELS[code].native}
            className={cn(
              "min-h-10 min-w-10 rounded-full px-2.5 text-[13px] tracking-wide transition-colors",
              active ? "bg-ink font-semibold text-bg" : "text-ink-soft hover:text-forest",
              variant === "full" && "px-4",
            )}
          >
            {variant === "full" ? LOCALE_LABELS[code].native : LOCALE_LABELS[code].short}
          </button>
        );
      })}
    </div>
  );
}
