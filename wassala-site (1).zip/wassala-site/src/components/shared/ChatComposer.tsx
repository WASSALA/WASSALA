"use client";

import { ArrowUp, Square } from "lucide-react";
import { forwardRef, useState } from "react";

interface Props {
  busy: boolean;
  placeholder: string;
  sendLabel: string;
  stopLabel: string;
  onSend: (text: string) => void;
  onStop: () => void;
  id: string;
}

/** Zone de saisie de l'assistant : Entrée pour envoyer, Maj+Entrée pour aller à la ligne, hauteur automatique. */
export const ChatComposer = forwardRef<HTMLTextAreaElement, Props>(function ChatComposer({ busy, placeholder, sendLabel, stopLabel, onSend, onStop, id }, ref) {
  const [draft, setDraft] = useState("");
  const send = () => {
    if (!draft.trim() || busy) return;
    onSend(draft);
    setDraft("");
  };
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        send();
      }}
      className="flex items-end gap-2 rounded-2xl border border-line-strong bg-white p-2 focus-within:border-forest focus-within:ring-2 focus-within:ring-forest/15"
    >
      <label htmlFor={id} className="sr-only">
        {placeholder}
      </label>
      <textarea
        id={id}
        ref={ref}
        value={draft}
        onChange={(e) => {
          setDraft(e.target.value);
          e.target.style.height = "auto";
          e.target.style.height = `${Math.min(e.target.scrollHeight, 140)}px`;
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            send();
          }
        }}
        rows={1}
        maxLength={2000}
        placeholder={placeholder}
        className="max-h-[140px] min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-[15px] outline-none placeholder:text-ink-soft/70"
      />
      {busy ? (
        <button type="button" onClick={onStop} aria-label={stopLabel} className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ink text-bg">
          <Square className="h-4 w-4" aria-hidden="true" />
        </button>
      ) : (
        <button
          type="submit"
          aria-label={sendLabel}
          disabled={!draft.trim()}
          className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-forest text-white transition-colors hover:bg-forest-dark disabled:bg-ink/15 disabled:text-ink-soft"
        >
          <ArrowUp className="h-5 w-5" aria-hidden="true" />
        </button>
      )}
    </form>
  );
});
