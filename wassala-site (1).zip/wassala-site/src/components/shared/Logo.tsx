import { cn } from "@/lib/utils";
import { WAW_PATH, WAW_VIEWBOX } from "./waw-path";

interface LogoProps {
  /** Hauteur du symbole en pixels. Le mot suit la taille. */
  size?: number;
  withWord?: boolean;
  className?: string;
}

/** Symbole waw (tracé exact de la charte) suivi du mot WASSALA. Le waw reste doré. */
export function Logo({ size = 40, withWord = true, className }: LogoProps) {
  const word = Math.round(size * 0.6);
  return (
    <span className={cn("inline-flex items-start gap-3 text-ink", className)}>
      <svg
        viewBox={WAW_VIEWBOX}
        width={Math.round(size * 0.945)}
        height={size}
        aria-hidden="true"
        focusable="false"
        className="shrink-0 fill-gold"
      >
        <path fillRule="evenodd" d={WAW_PATH} />
      </svg>
      {withWord ? (
        <span className="font-sans font-semibold uppercase tracking-[.02em]" style={{ fontSize: word, lineHeight: `${word - 6}px` }}>
          WASSALA
        </span>
      ) : (
        <span className="sr-only">WASSALA</span>
      )}
    </span>
  );
}
