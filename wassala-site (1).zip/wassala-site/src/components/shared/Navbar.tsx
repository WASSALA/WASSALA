"use client";

import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, Menu, Sparkles, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { NAV_ITEMS } from "@/data/site";
import { openPalette } from "@/lib/events";
import { useI18n } from "@/lib/i18n/I18nProvider";
import { cn } from "@/lib/utils";
import { CapitalsMarquee } from "./CapitalsMarquee";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { Logo } from "./Logo";

/**
 * En-tête à deux niveaux : (1) navigation collante, (2) bandeau défilant des capitales.
 * Au défilement vers le bas, le bandeau se replie ; il revient dès que l'on remonte.
 */
export function Navbar() {
  const pathname = usePathname();
  const { t } = useI18n();
  const reduce = useReducedMotion();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [compact, setCompact] = useState(false);
  const [shortcut, setShortcut] = useState("Ctrl K");

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    setShortcut(/Mac|iPhone|iPad/.test(navigator.platform) ? "⌘K" : "Ctrl K");
    let last = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 8);
      if (Math.abs(y - last) > 6) {
        setCompact(y > 160 && y > last);
        last = y;
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-[box-shadow,background-color] duration-300",
        scrolled ? "bg-bg/90 shadow-[0_10px_30px_-20px_rgb(16_38_27/.35)]" : "bg-bg/95",
      )}
      style={{ backdropFilter: "saturate(1.4) blur(10px)", WebkitBackdropFilter: "saturate(1.4) blur(10px)" }}
    >
      <div className="container flex items-center justify-between gap-4" style={{ minHeight: "var(--header-h)" }}>
        <Link href="/" aria-label={`WASSALA, ${t.nav.home}`} className="rounded-md">
          <Logo size={38} />
        </Link>

        <nav aria-label={t.nav.mainNav} className="hidden items-center gap-1 lg:flex">
          {NAV_ITEMS.map((item) => {
            const active = isActive(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "relative inline-flex min-h-11 items-center rounded-full px-4 text-[15px] font-medium transition-colors",
                  active ? "text-ink" : "text-ink-soft hover:text-ink",
                )}
              >
                {active ? (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 -z-10 rounded-full border border-gold/70 bg-card"
                    transition={reduce ? { duration: 0 } : { type: "spring", stiffness: 380, damping: 32 }}
                  />
                ) : null}
                {t.nav[item.key]}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <LanguageSwitcher />
          <button
            type="button"
            onClick={openPalette}
            className="group inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card/70 pe-2 ps-3.5 text-sm text-ink-soft transition-colors hover:border-gold hover:text-ink"
            aria-label={`${t.nav.search} (${shortcut})`}
          >
            <Sparkles className="h-4 w-4 text-gold-text transition-transform group-hover:rotate-12" aria-hidden="true" />
            <span>{t.nav.search}</span>
            <kbd className="rounded border border-line bg-bg px-1.5 py-0.5 font-sans text-[11px] text-ink-soft">{shortcut}</kbd>
          </button>
          <Link href="/#contact" className="btn-primary min-h-11 px-5 text-[15px]">
            {t.nav.contact}
          </Link>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <button
            type="button"
            onClick={openPalette}
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-line"
            aria-label={t.nav.search}
          >
            <Sparkles className="h-5 w-5 text-gold-text" aria-hidden="true" />
          </button>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-line"
            aria-expanded={open}
            aria-controls="menu-mobile"
            aria-label={open ? t.nav.closeMenu : t.nav.openMenu}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
          </button>
        </div>
      </div>

      <div
        className={cn("grid transition-[grid-template-rows] duration-500 ease-brand", compact && !open ? "grid-rows-[0fr]" : "grid-rows-[1fr]")}
      >
        <div className="overflow-hidden">
          <CapitalsMarquee label={t.nav.capitals} />
        </div>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.div
            id="menu-mobile"
            className="fixed inset-x-0 bottom-0 top-[var(--header-h)] z-40 overflow-y-auto bg-bg lg:hidden"
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, y: -12 }}
            transition={{ duration: 0.3, ease: [0.2, 0.7, 0.2, 1] }}
          >
            <nav aria-label={t.nav.mobileNav} className="container flex flex-col pb-10 pt-4">
              {[{ href: "/", key: "home" as const }, ...NAV_ITEMS].map((item, i) => (
                <motion.div
                  key={item.href}
                  initial={reduce ? false : { opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.05, duration: 0.35 }}
                >
                  <Link
                    href={item.href}
                    aria-current={pathname === item.href ? "page" : undefined}
                    className="flex min-h-16 items-center justify-between border-b border-line font-display text-3xl"
                  >
                    {t.nav[item.key]}
                    <ArrowUpRight className="h-6 w-6 text-gold-text rtl:-scale-x-100" aria-hidden="true" />
                  </Link>
                </motion.div>
              ))}
              <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
                <LanguageSwitcher />
                <Link href="/#contact" className="btn-primary">
                  {t.nav.contact}
                </Link>
              </div>
            </nav>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
