import { Languages } from "lucide-react";
import { getDictionary } from "@/lib/i18n/server";

/** Bandeau affiché hors français : le contenu détaillé n'est pas encore traduit. Honnête plutôt que trompeur. */
export async function TranslationNotice() {
  const { locale, t } = await getDictionary();
  if (locale === "fr" || !t.notice) return null;
  return (
    <div className="border-b border-gold/60 bg-card">
      <p className="container flex items-center gap-3 py-2.5 text-sm text-ink-soft">
        <Languages className="h-4 w-4 shrink-0 text-gold-text" aria-hidden="true" />
        {t.notice}
      </p>
    </div>
  );
}
