import { Fragment } from "react";

/**
 * Rendu « markdown léger » des réponses de l'assistant : paragraphes, listes « - », **gras**.
 * Construit des nœuds React (jamais de HTML injecté) : aucun risque d'injection.
 */
function inline(text: string, key: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) =>
    p.startsWith("**") && p.endsWith("**") && p.length > 4 ? (
      <strong key={`${key}-${i}`} className="font-semibold">
        {p.slice(2, -2)}
      </strong>
    ) : (
      <Fragment key={`${key}-${i}`}>{p}</Fragment>
    ),
  );
}

const BULLET = /^\s*[-•*]\s+/;

export function RichText({ text }: { text: string }) {
  const lines = text.replace(/\r/g, "").split("\n");
  const groups: Array<{ list: boolean; lines: string[] }> = [];
  for (const line of lines) {
    if (!line.trim()) {
      groups.push({ list: false, lines: [] });
      continue;
    }
    const list = BULLET.test(line);
    const last = groups[groups.length - 1];
    if (last && last.list === list && last.lines.length > 0) last.lines.push(line);
    else groups.push({ list, lines: [line] });
  }
  return (
    <>
      {groups
        .filter((g) => g.lines.length > 0)
        .map((g, gi) =>
          g.list ? (
            <ul key={gi} className="my-2 space-y-1">
              {g.lines.map((l, li) => (
                <li key={li} className="flex gap-2">
                  <span aria-hidden="true" className="mt-[9px] h-1.5 w-1.5 shrink-0 rotate-45 bg-gold" />
                  <span>{inline(l.replace(BULLET, ""), `${gi}-${li}`)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p key={gi} className="my-2 first:mt-0 last:mb-0">
              {g.lines.map((l, li) => (
                <Fragment key={li}>
                  {li > 0 ? <br /> : null}
                  {inline(l, `${gi}-${li}`)}
                </Fragment>
              ))}
            </p>
          ),
        )}
    </>
  );
}
