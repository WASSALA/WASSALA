"use client";

import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from "framer-motion";
import { useMemo, useRef, useState } from "react";
import {
  AFRICA_OUTLINE,
  CROSS_LINKS,
  HUB_LINKS,
  MADAGASCAR_OUTLINE,
  NODES,
  SEA_ROUTE,
  THIN_LINKS,
  type MapNode,
} from "@/data/capitals";
import { VIEW_H, VIEW_W, closedSpline, polygonPath, project, quadCurve, type XY } from "@/lib/map-geometry";
import { cn } from "@/lib/utils";

/* Calculs faits une seule fois, au chargement du module. */
const POINTS = new Map<string, XY>(NODES.map((n) => [n.id, project(n.lonlat)]));
const pt = (id: string): XY => {
  const p = POINTS.get(id);
  if (!p) throw new Error(`Nœud inconnu : ${id}`);
  return p;
};
const OUTLINE = polygonPath(AFRICA_OUTLINE) + polygonPath(MADAGASCAR_OUTLINE);
const SEA = closedSpline(SEA_ROUTE.map(project));
const ALGER = pt("alg");
const hubPaths = HUB_LINKS.map((id) => quadCurve(ALGER, pt(id), 0.18));
const thinPaths = THIN_LINKS.map((id) => quadCurve(ALGER, pt(id), 0.14));
const crossPaths = CROSS_LINKS.map(([a, b]) => quadCurve(pt(a), pt(b), 0.12));
const returnPaths = [...hubPaths, ...thinPaths];
/** Lien Alger → nœud, pour la mise en évidence au survol. */
const LINK_TO = new Map<string, string>(
  NODES.filter((n) => n.id !== "alg").map((n) => [n.id, quadCurve(ALGER, pt(n.id), (HUB_LINKS as readonly string[]).includes(n.id) ? 0.18 : 0.14)]),
);

const KIND_LABEL: Record<MapNode["kind"], string> = {
  hub: "Siège WASSALA",
  capital: "Capitale francophone",
  partner: "Hub partenaire",
};

interface AfricaMapProps {
  /** Affiche les noms des capitales. À désactiver sur petit écran. */
  labels?: boolean;
  /** Préfixe des identifiants SVG : à rendre unique si plusieurs cartes sont sur la même page. */
  idPrefix?: string;
  /** Inclinaison 3D légère qui suit le pointeur, et info-bulles au survol des villes. */
  interactive?: boolean;
  className?: string;
}

function Label({ node, strong }: { node: MapNode; strong?: boolean }) {
  if (!node.label) return null;
  const [x, y] = pt(node.id);
  const big = strong || node.label.strong;
  return (
    <text
      x={Math.round(x + node.label.dx)}
      y={Math.round(y + node.label.dy)}
      textAnchor={node.label.anchor}
      className={cn(
        "pointer-events-none fill-forest stroke-bg",
        big ? "text-[13px] font-semibold" : "text-[10.5px]",
        node.kind === "capital" && "max-sm:hidden",
      )}
      strokeWidth={3}
      style={{ paintOrder: "stroke", letterSpacing: big ? "1.5px" : ".3px" }}
    >
      {node.label.text}
    </text>
  );
}

/**
 * Carte animée de l'Afrique : matrice de points, contour fin, aucune frontière, aucun drapeau.
 * Capitales francophones en vert, hubs partenaires en or, liens dorés depuis Alger,
 * impulsions à l'aller et au retour, routes maritimes qui contournent le continent.
 * Mouvement réduit : voir globals.css (.map-pulse, .map-ship, .map-ring masqués ; liens statiques).
 */
export function AfricaMap({ labels = true, idPrefix = "af", interactive = false, className }: AfricaMapProps) {
  const reduce = useReducedMotion();
  const wrap = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<string | null>(null);
  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const rx = useSpring(useTransform(py, [-0.5, 0.5], [5, -5]), { stiffness: 120, damping: 18 });
  const ry = useSpring(useTransform(px, [-0.5, 0.5], [-6, 6]), { stiffness: 120, damping: 18 });

  const clip = `${idPrefix}-clip`;
  const dots = `${idPrefix}-dots`;
  const glow = `${idPrefix}-glow`;
  const alger = NODES.find((n) => n.id === "alg")!;
  const hovered = hover ? NODES.find((n) => n.id === hover) : null;
  const tip = useMemo(() => (hover ? pt(hover) : null), [hover]);
  const tilt = interactive && !reduce;

  return (
    <motion.div
      ref={wrap}
      className={cn("relative", className)}
      style={tilt ? { rotateX: rx, rotateY: ry, transformPerspective: 1100 } : undefined}
      onPointerMove={(e) => {
        if (!tilt || e.pointerType !== "mouse" || !wrap.current) return;
        const r = wrap.current.getBoundingClientRect();
        px.set((e.clientX - r.left) / r.width - 0.5);
        py.set((e.clientY - r.top) / r.height - 0.5);
      }}
      onPointerLeave={() => {
        px.set(0);
        py.set(0);
        setHover(null);
      }}
    >
      <svg
        viewBox={`0 0 ${VIEW_W} ${VIEW_H}`}
        role="img"
        aria-label="Carte de l’Afrique : capitales francophones, hubs partenaires, routes maritimes autour du continent et flux entre Alger et le réseau."
        className="block h-auto w-full overflow-visible"
      >
        <defs>
          <clipPath id={clip}>
            <path d={OUTLINE} />
          </clipPath>
          <pattern id={dots} width="9" height="9" patternUnits="userSpaceOnUse">
            <circle cx="4.5" cy="4.5" r="1.5" className="fill-ink-soft" fillOpacity=".4" />
          </pattern>
          <radialGradient id={glow}>
            <stop offset="0" stopColor="#E3B65B" stopOpacity=".55" />
            <stop offset="1" stopColor="#E3B65B" stopOpacity="0" />
          </radialGradient>
        </defs>

        <circle cx={Math.round(ALGER[0])} cy={Math.round(ALGER[1])} r={90} fill={`url(#${glow})`} />
        <rect width={VIEW_W} height={VIEW_H} fill={`url(#${dots})`} clipPath={`url(#${clip})`} />
        <path d={OUTLINE} className="fill-none stroke-ink-soft" strokeOpacity=".3" />

        {/* Routes maritimes : pointillés, navires dans les deux sens */}
        <path d={SEA} className="fill-none stroke-sea" strokeOpacity=".55" strokeWidth={1.3} strokeDasharray="2 7" strokeLinecap="round" />
        {Array.from({ length: 6 }, (_, i) => (
          <circle key={`s${i}`} r={3.2} className="map-ship fill-sea">
            <animateMotion dur="44s" begin={`-${((i * 44) / 6).toFixed(1)}s`} repeatCount="indefinite" path={SEA} />
          </circle>
        ))}
        {Array.from({ length: 4 }, (_, i) => (
          <circle key={`r${i}`} r={2.6} className="map-ship fill-sea" fillOpacity=".7">
            <animateMotion dur="52s" begin={`-${i * 13}s`} repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear" path={SEA} />
          </circle>
        ))}

        {/* Liens : tracé progressif au chargement (.map-link) */}
        <g className="fill-none" strokeLinecap="round">
          <g className="stroke-ink-soft" strokeOpacity=".4" strokeWidth={1.2}>
            {crossPaths.map((d, i) => (
              <path key={i} d={d} pathLength={1} className="map-link" />
            ))}
          </g>
          <g className="stroke-ink-soft" strokeOpacity=".22" strokeWidth={1}>
            {thinPaths.map((d, i) => (
              <path key={i} d={d} pathLength={1} className="map-link" />
            ))}
          </g>
          <g className="stroke-gold" strokeWidth={1.8}>
            {hubPaths.map((d, i) => (
              <path key={i} d={d} pathLength={1} className="map-link" style={{ animationDelay: `${0.3 + i * 0.12}s` }} />
            ))}
          </g>
          {hover && hover !== "alg" ? (
            <path d={LINK_TO.get(hover)} className="stroke-forest" strokeWidth={2.6} strokeDasharray="5 5">
              {!reduce ? <animate attributeName="stroke-dashoffset" values="20;0" dur=".8s" repeatCount="indefinite" /> : null}
            </path>
          ) : null}
        </g>

        {/* Impulsions : sortantes depuis Alger (vert foncé), retours vers Alger (or foncé), échanges entre pays */}
        {hubPaths.map((d, i) => (
          <circle key={`o${i}`} r={3} className="map-pulse fill-forest-dark">
            <animateMotion dur={`${(3.5 + i * 0.6).toFixed(1)}s`} begin={`${(i * 0.5).toFixed(1)}s`} repeatCount="indefinite" path={d} />
          </circle>
        ))}
        {returnPaths.map((d, i) => (
          <circle key={`b${i}`} r={2.8} className="map-pulse fill-[#B8860B]">
            <animateMotion
              dur={`${(4 + (i % 7) * 0.7).toFixed(1)}s`}
              begin={`${((i * 0.37) % 4).toFixed(1)}s`}
              repeatCount="indefinite"
              keyPoints="1;0"
              keyTimes="0;1"
              calcMode="linear"
              path={d}
            />
          </circle>
        ))}
        {crossPaths.map((d, i) => (
          <circle key={`c${i}`} r={2} className="map-pulse fill-ink-soft">
            <animateMotion dur={`${(5 + i * 0.7).toFixed(1)}s`} begin={`${(i * 0.8).toFixed(1)}s`} repeatCount="indefinite" path={d} />
          </circle>
        ))}

        {/* Nœuds */}
        {NODES.map((n) => {
          const [x, y] = pt(n.id);
          const gold = n.kind !== "capital";
          const base = n.kind === "hub" ? 6 : gold ? 3.6 : 3;
          const r = hover === n.id ? base + 2.5 : base;
          return <circle key={n.id} cx={Math.round(x)} cy={Math.round(y)} r={r} className={cn("map-node", gold ? "fill-gold" : "fill-forest")} />;
        })}
        {(["alg", "dak", "nia", "lag", "kin", "nai", "joh"] as const).map((id, i) => {
          const [x, y] = pt(id);
          const big = id === "alg";
          return (
            <circle key={`h${id}`} cx={Math.round(x)} cy={Math.round(y)} r={5} className="map-pulse fill-none stroke-forest" strokeWidth={1.2}>
              <animate attributeName="r" values={`5;${big ? 28 : 16}`} dur={`${big ? 3 : 4}s`} begin={`${i * 0.4}s`} repeatCount="indefinite" />
              <animate attributeName="opacity" values=".8;0" dur={`${big ? 3 : 4}s`} begin={`${i * 0.4}s`} repeatCount="indefinite" />
            </circle>
          );
        })}
        <circle cx={Math.round(ALGER[0])} cy={Math.round(ALGER[1])} r={22} className="map-ring fill-none stroke-gold" strokeWidth={1.2} strokeDasharray="3 6" />

        {/* Libellés */}
        <Label node={alger} strong />
        {NODES.filter((n) => n.kind === "partner").map((n) => (
          <Label key={n.id} node={n} />
        ))}
        {labels ? NODES.filter((n) => n.kind === "capital").map((n) => <Label key={n.id} node={n} />) : null}

        {/* Zones de survol (souris) : agrandies, invisibles */}
        {interactive
          ? NODES.map((n) => {
              const [x, y] = pt(n.id);
              return (
                <circle
                  key={`hit-${n.id}`}
                  cx={Math.round(x)}
                  cy={Math.round(y)}
                  r={13}
                  fill="transparent"
                  aria-hidden="true"
                  className="cursor-pointer"
                  onPointerEnter={() => setHover(n.id)}
                  onPointerLeave={() => setHover((h) => (h === n.id ? null : h))}
                />
              );
            })
          : null}
      </svg>

      {hovered && tip ? (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-[calc(100%+14px)] whitespace-nowrap rounded-md border border-gold/70 bg-ink px-3 py-2 text-xs text-bg shadow-lift"
          style={{ left: `${(tip[0] / VIEW_W) * 100}%`, top: `${(tip[1] / VIEW_H) * 100}%` }}
        >
          <p className="font-semibold">{hovered.name}</p>
          <p className="text-bg/70">
            {KIND_LABEL[hovered.kind]}
            {hovered.id !== "alg" ? " · relié à Alger" : ""}
          </p>
        </div>
      ) : null}
    </motion.div>
  );
}

const LEGEND: ReadonlyArray<{ label: string; swatch: string }> = [
  { label: "Capitales francophones", swatch: "bg-forest rounded-full" },
  { label: "Hubs partenaires", swatch: "bg-gold rounded-full" },
  { label: "Routes maritimes", swatch: "bg-sea h-[3px] w-4 rounded-none" },
  { label: "Flux sortants", swatch: "bg-forest-dark rounded-full" },
  { label: "Retours vers Alger", swatch: "bg-[#B8860B] rounded-full" },
];

export function MapLegend({ className }: { className?: string }) {
  return (
    <ul className={cn("mt-3 flex flex-wrap gap-x-5 gap-y-2 text-[13px] text-ink-soft", className)}>
      {LEGEND.map((l) => (
        <li key={l.label} className="flex items-center gap-2">
          <span aria-hidden="true" className={cn("inline-block h-2.5 w-2.5", l.swatch)} />
          {l.label}
        </li>
      ))}
    </ul>
  );
}
