import { cn } from "@/lib/utils";

interface ScoreBadgeProps {
  /** Score de 0 à 100. */
  score: number;
  label?: string;
  className?: string;
}

function tier(score: number): { name: string; bar: string } {
  if (score >= 75) return { name: "Élevé", bar: "bg-forest" };
  if (score >= 50) return { name: "Moyen", bar: "bg-gold" };
  return { name: "Faible", bar: "bg-danger" };
}

/** Score 0-100 avec barre animée. Le niveau est écrit en toutes lettres : jamais la couleur seule. */
export function ScoreBadge({ score, label = "Score", className }: ScoreBadgeProps) {
  const value = Math.max(0, Math.min(100, Math.round(score)));
  const t = tier(value);
  return (
    <div className={cn("w-full", className)}>
      <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
        <span className="text-ink-soft">{label}</span>
        <span className="font-semibold">
          {value}/100 · {t.name}
        </span>
      </div>
      <div
        role="meter"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={value}
        className="h-2.5 overflow-hidden rounded-full bg-[rgba(16,38,27,.1)]"
      >
        <div
          className={cn("h-full origin-left rounded-full animate-[score-grow_1.2s_cubic-bezier(.2,.7,.2,1)_both]", t.bar)}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
