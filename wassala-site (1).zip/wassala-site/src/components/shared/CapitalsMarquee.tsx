import { FRANCOPHONE_CAPITALS } from "@/data/capitals";

/**
 * Bandeau défilant des capitales de l'Afrique francophone (niveau 2 de l'en-tête).
 * Boucle sans saut : la liste est dupliquée, la copie est masquée aux lecteurs d'écran.
 * Pause au survol et au focus clavier (tabIndex=0). Mouvement réduit : liste statique (globals.css).
 */
export function CapitalsMarquee({ label = "Capitales de l’Afrique francophone" }: { label?: string }) {
  const list = (hidden: boolean) => (
    <ul aria-hidden={hidden || undefined}>
      {FRANCOPHONE_CAPITALS.map((name) => (
        <li key={name} data-hub={name === "Alger"}>
          {name}
        </li>
      ))}
    </ul>
  );
  return (
    <div className="capitals-marquee" role="region" aria-label={label} tabIndex={0}>
      <div className="capitals-track">
        {list(false)}
        {list(true)}
      </div>
    </div>
  );
}
