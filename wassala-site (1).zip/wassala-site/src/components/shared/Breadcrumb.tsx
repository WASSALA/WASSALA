import { ChevronRight } from "lucide-react";
import Link from "next/link";

/** Fil d'Ariane des pages marketing. Le dernier élément est la page courante. */
export function Breadcrumb({ items }: { items: ReadonlyArray<{ href?: string; label: string }> }) {
  return (
    <nav aria-label="Fil d’Ariane" className="mb-8 animate-rise">
      <ol className="flex flex-wrap items-center gap-1.5 text-sm text-ink-soft">
        {items.map((it, i) => (
          <li key={it.label} className="flex items-center gap-1.5">
            {i > 0 ? <ChevronRight className="h-3.5 w-3.5 rtl:-scale-x-100" aria-hidden="true" /> : null}
            {it.href ? (
              <Link href={it.href} className="hover:text-forest">
                {it.label}
              </Link>
            ) : (
              <span aria-current="page" className="text-ink">
                {it.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
