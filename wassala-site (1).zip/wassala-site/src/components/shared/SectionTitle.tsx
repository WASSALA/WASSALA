import { cn } from "@/lib/utils";

interface SectionTitleProps {
  title: React.ReactNode;
  eyebrow?: string;
  lead?: React.ReactNode;
  as?: "h1" | "h2" | "h3";
  align?: "start" | "center";
  className?: string;
  id?: string;
}

export function SectionTitle({ title, eyebrow, lead, as: Tag = "h2", align = "start", className, id }: SectionTitleProps) {
  const size =
    Tag === "h1" ? "text-[clamp(44px,7vw,84px)]" : Tag === "h2" ? "text-[clamp(34px,4.6vw,56px)]" : "text-2xl md:text-3xl";
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      {eyebrow ? <p className={cn("eyebrow", align === "center" && "justify-center")}>{eyebrow}</p> : null}
      <Tag id={id} className={size}>
        {title}
      </Tag>
      {lead ? <p className="mt-5 text-lg text-ink-soft md:text-xl">{lead}</p> : null}
    </div>
  );
}
