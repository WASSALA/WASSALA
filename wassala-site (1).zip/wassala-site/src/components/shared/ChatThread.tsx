"use client";

import { ArrowRight, Copy } from "lucide-react";
import Link from "next/link";
import type { AssistantMessage } from "@/lib/ai/useAssistant";
import { cn } from "@/lib/utils";
import { RichText } from "./RichText";

/** Fil de messages de l'assistant (bulles, curseur de flux, actions, copie). */
export function ChatThread({ messages, onAction, thinkingLabel }: { messages: AssistantMessage[]; onAction?: () => void; thinkingLabel: string }) {
  return (
    <>
      {messages.map((m) =>
        m.role === "user" ? (
          <div key={m.id} className="ms-auto w-fit max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-ee-md bg-forest px-4 py-2.5 text-[15px] text-white">
            {m.content}
          </div>
        ) : (
          <div key={m.id} className="group/msg max-w-[92%]">
            <div
              className={cn(
                "rounded-2xl rounded-es-md border px-4 py-3 text-[15px] leading-relaxed",
                m.error ? "border-danger/40 bg-danger/5 text-danger" : "border-line bg-card text-ink",
              )}
            >
              {m.content ? <RichText text={m.content} /> : null}
              {m.streaming && !m.content ? (
                <span className="inline-flex items-center gap-1 py-1" role="status" aria-label={thinkingLabel}>
                  {[0, 1, 2].map((d) => (
                    <span key={d} className="h-1.5 w-1.5 animate-bounce rounded-full bg-gold-read" style={{ animationDelay: `${d * 0.15}s` }} />
                  ))}
                </span>
              ) : null}
              {m.streaming && m.content ? <span aria-hidden="true" className="ms-0.5 inline-block h-4 w-[2px] translate-y-0.5 animate-blink bg-forest" /> : null}
            </div>
            {!m.streaming && m.actions?.length ? (
              <div className="mt-2 flex flex-wrap gap-2">
                {m.actions.map((a) => (
                  <Link
                    key={a.href + a.label}
                    href={a.href}
                    onClick={onAction}
                    className={cn(
                      "inline-flex min-h-10 max-w-full items-center gap-1.5 rounded-full px-3.5 text-sm font-semibold transition-colors",
                      a.primary ? "bg-ink text-bg hover:bg-forest" : "border border-line bg-card text-ink hover:border-gold",
                    )}
                  >
                    <span className="truncate">{a.label}</span>
                    <ArrowRight className="h-3.5 w-3.5 shrink-0 rtl:-scale-x-100" aria-hidden="true" />
                  </Link>
                ))}
              </div>
            ) : null}
            {!m.streaming && m.content && !m.error ? (
              <button
                type="button"
                onClick={() => void navigator.clipboard?.writeText(m.content)}
                className="mt-1 inline-flex min-h-8 items-center gap-1 rounded px-1.5 text-xs text-ink-soft opacity-0 transition-opacity hover:text-ink focus:opacity-100 group-hover/msg:opacity-100"
              >
                <Copy className="h-3 w-3" aria-hidden="true" /> Copier
              </button>
            ) : null}
          </div>
        ),
      )}
    </>
  );
}
