import type { Config } from "tailwindcss";

/** Une couleur définie par ses canaux RGB dans globals.css : permet les opacités Tailwind (bg-forest/10…). */
const token = (name: string) => `rgb(var(--rgb-${name}) / <alpha-value>)`;

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    container: {
      center: true,
      padding: { DEFAULT: "1.25rem", sm: "1.5rem", lg: "3rem" },
      screens: { "2xl": "1344px" },
    },
    extend: {
      colors: {
        bg: token("bg"),
        section: token("section"),
        card: token("card"),
        ink: token("ink"),
        "ink-soft": token("ink-soft"),
        forest: token("forest"),
        "forest-dark": token("forest-dark"),
        "forest-light": token("forest-light"),
        gold: token("gold"),
        "gold-read": token("gold-read"),
        "gold-text": token("gold-text"),
        sea: token("sea"),
        danger: token("danger"),
        line: "rgb(16 38 27 / 0.14)",
        "line-strong": "rgb(16 38 27 / 0.28)",
        "line-dark": "rgb(238 243 234 / 0.14)",
      },
      borderColor: { DEFAULT: "rgb(16 38 27 / 0.14)" },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        sans: ["var(--font-inter)", "Helvetica Neue", "Arial", "sans-serif"],
        arabic: ["var(--font-arabic)", "var(--font-inter)", "serif"],
      },
      borderRadius: { md: "8px", lg: "14px", xl: "20px", "2xl": "28px" },
      boxShadow: {
        soft: "0 10px 30px -14px rgb(16 38 27 / 0.35)",
        lift: "0 24px 60px -24px rgb(16 38 27 / 0.45)",
        glow: "0 0 0 1px rgb(227 182 91 / 0.5), 0 22px 44px -22px rgb(31 122 77 / 0.45)",
      },
      transitionTimingFunction: { brand: "cubic-bezier(.2,.7,.2,1)" },
      keyframes: {
        "score-grow": { from: { transform: "scaleX(0)" }, to: { transform: "scaleX(1)" } },
        rise: { from: { opacity: "0", transform: "translateY(24px)" }, to: { opacity: "1", transform: "none" } },
        "fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
        shimmer: { from: { backgroundPosition: "200% 0" }, to: { backgroundPosition: "-200% 0" } },
        "spin-slow": { to: { transform: "rotate(360deg)" } },
        blink: { "0%,100%": { opacity: "1" }, "50%": { opacity: "0" } },
      },
      animation: {
        rise: "rise .8s cubic-bezier(.2,.7,.2,1) both",
        "fade-in": "fade-in .5s ease both",
        shimmer: "shimmer 2.4s linear infinite",
        "spin-slow": "spin-slow 40s linear infinite",
        blink: "blink 1s step-end infinite",
      },
    },
  },
  plugins: [],
};

export default config;
