import { expect, test } from "@playwright/test";

test("l'accueil applique les correctifs validés", async ({ page, isMobile }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Le lien qui construit");
  if (!isMobile) {
    const nav = page.getByRole("navigation", { name: "Navigation principale" });
    await expect(nav.getByRole("link")).toHaveText(["SANAD", "Héritage", "Projets continentaux"]);
    await expect(nav.getByText("Formation")).toHaveCount(0);
  }
  await expect(page.getByRole("link", { name: /Devenir exportateur/ })).toBeVisible();
  await expect(page.getByRole("link", { name: /Devenir acheteur/ })).toBeVisible();
  await expect(page.getByText("flux commerciaux")).toBeVisible();
  await expect(page.getByText("Du diagnostic au financement")).toHaveCount(0);
  await expect(page.getByRole("heading", { name: "Trois services, un seul réseau" })).toHaveCount(0);
});

test("le CTA exportateur pré-sélectionne le rôle", async ({ page }) => {
  await page.goto("/app/transactions/new?role=exportateur&destination=S%C3%A9n%C3%A9gal");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Devenir exportateur");
  await expect(page.getByLabel("Pays de destination *")).toHaveValue("Sénégal");
});

test("le simulateur SANAD recalcule la commission", async ({ page }) => {
  await page.goto("/sanad#simulateur");
  await page.getByRole("button", { name: "250 000 $" }).click();
  await expect(page.getByText("Commission totale")).toBeVisible();
});

test("Héritage : la frise et les sept moments sont dans la même section", async ({ page }) => {
  await page.goto("/heritage");
  const section = page.locator("section#frise");
  await expect(section.getByRole("heading", { name: "De 1954 à aujourd’hui" })).toBeVisible();
  await expect(section.getByRole("heading", { name: /Sept grands moments/ })).toBeVisible();
});

test("l'assistant répond", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Assistant WASSALA" }).click();
  await page.getByRole("button", { name: "Qu’est-ce que SANAD ?" }).click();
  await expect(page.getByRole("dialog", { name: "Assistant WASSALA" })).toContainText("Finder’s Fee");
});

test("SANAD : le récapitulatif d’accord est généré depuis le Fil, sources à l’appui", async ({ page }) => {
  await page.goto("/app/transactions/tx-001");
  await page.getByRole("button", { name: "Générer le récapitulatif" }).click();
  const doc = page.locator(".print-doc");
  await expect(doc.getByRole("heading", { name: "Termes convenus dans le Fil" })).toBeVisible();
  await expect(doc).toContainText("CPT Nouakchott");
  await expect(doc).toContainText("ne vaut ni facture, ni contrat de vente");
  await expect(doc.getByRole("button", { name: "Voir le message 6 du Fil" }).first()).toBeVisible();
});
