import { describe, expect, it } from "vitest";
import { AFRICAN_COUNTRIES } from "@/data/countries";
import { contactSchema } from "@/lib/forms/schemas";
import { dirOf, parseLocale } from "@/lib/locale";
import { project } from "@/lib/map-geometry";
import { readiness } from "@/lib/sanad/readiness";

describe("langues", () => {
  it("retombe sur le français et passe l'arabe en RTL", () => {
    expect(parseLocale("xx")).toBe("fr");
    expect(parseLocale("ar")).toBe("ar");
    expect(dirOf("ar")).toBe("rtl");
    expect(dirOf("sw")).toBe("ltr");
  });
});

describe("carte", () => {
  it("place Alger au nord et Johannesburg au sud", () => {
    const [, yAlger] = project([3.06, 36.75]);
    const [, yJoburg] = project([28, -26.2]);
    expect(yAlger).toBeLessThan(yJoburg);
  });
});

describe("pays", () => {
  it("liste les 54 États africains", () => {
    expect(AFRICAN_COUNTRIES).toHaveLength(54);
  });
});

describe("formulaire de contact", () => {
  it("refuse un envoi sans consentement et accepte un envoi complet", () => {
    const base = { nom: "Amina", email: "amina@example.com", pays: "Sénégal", objet: "Autre", message: "Bonjour, je souhaite en savoir plus sur SANAD." };
    expect(contactSchema.safeParse(base).success).toBe(false);
    expect(contactSchema.safeParse({ ...base, consent: true }).success).toBe(true);
  });
});

describe("score de préparation", () => {
  it("vaut 100 quand tout est fourni", () => {
    expect(readiness({ kyc: true, secteur: true, corridor: true, ficheTechnique: true, codeSH: true, ticket: true, transactionsAbouties: 3 }).score).toBe(100);
  });
});
