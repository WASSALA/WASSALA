import { describe, expect, it } from "vitest";
import { KNOWLEDGE, suggestionsFor } from "@/data/knowledge";
import { detectIntent } from "@/lib/ai/intent";
import { FALLBACK_ANSWER, actionsFor, localAnswer } from "@/lib/ai/local-answer";
import { MIN_SCORE, retrieve } from "@/lib/ai/retrieve";

describe("retrieve", () => {
  it.each([
    ["Comment fonctionne le séquestre ?", "amana"],
    ["Que couvre la garantie DAMAN ?", "daman"],
    ["Est-ce que vous délivrez le certificat d'origine ?", "certificat"],
    ["Combien ça coûte ?", "commission"],
    ["Pourquoi Alger ?", "alger"],
    ["Financez-vous mon projet ?", "financement"],
  ])("« %s » → %s", (q, id) => {
    const [best] = retrieve(q);
    expect(best?.entry.id).toBe(id);
    expect(best!.score).toBeGreaterThanOrEqual(MIN_SCORE);
  });
});

describe("réponses locales", () => {
  it("répond par une réponse prudente quand rien ne correspond", () => {
    const q = "Quelle est la météo à Tokyo ?";
    expect(localAnswer(detectIntent(q), retrieve(q))).toBe(FALLBACK_ANSWER);
  });

  it("propose un brief pré-rempli quand un projet est décrit", () => {
    const q = "J'exporte des dattes vers le Sénégal";
    const actions = actionsFor(detectIntent(q), retrieve(q), q);
    expect(actions[0]?.primary).toBe(true);
    expect(actions[0]?.href).toContain("/app/transactions/new");
  });

  it("ne dit jamais que WASSALA détient les fonds ou finance les projets", () => {
    for (const k of KNOWLEDGE) {
      expect(k.answer).not.toMatch(/WASSALA (détient|conserve) (les|vos) fonds/i);
      expect(k.answer).not.toMatch(/WASSALA finance /i);
    }
  });

  it("suggère des questions adaptées à la page", () => {
    expect(suggestionsFor("/sanad").length).toBeGreaterThan(0);
    expect(suggestionsFor("/heritage").map((s) => s.id)).toContain("alger");
  });
});
