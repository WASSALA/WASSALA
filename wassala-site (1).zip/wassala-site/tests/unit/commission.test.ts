import { describe, expect, it } from "vitest";
import { REFERENCE_EXAMPLE, amanaTranches, computeCommission } from "@/lib/sanad/commission";

describe("computeCommission", () => {
  it("retrouve l'exemple de référence du dossier (60 000 $, 4 %)", () => {
    expect(REFERENCE_EXAMPLE).toMatchObject({ total: 2400, daman: 240, apporteur: 700, agentLocal: 500, temoins: 300, wassala: 660 });
    expect(REFERENCE_EXAMPLE.wassalaShare).toBe(1.1);
  });

  it("répartit toujours exactement la commission totale", () => {
    for (const value of [5_000, 12_345, 60_000, 250_000, 1_000_000]) {
      for (const rate of [3, 3.5, 4, 4.5, 5]) {
        const r = computeCommission(value, rate);
        const sum = r.daman + r.apporteur + r.agentLocal + r.temoins + r.wassala;
        expect(Math.abs(sum - r.total)).toBeLessThan(0.011);
      }
    }
  });

  it("ne produit jamais de montant négatif", () => {
    const r = computeCommission(0, 4);
    expect(Object.values(r).every((v) => v >= 0)).toBe(true);
  });
});

describe("amanaTranches", () => {
  it("découpe la valeur en 30 / 40 / 30 %", () => {
    expect(amanaTranches(60_000).map((t) => t.amount)).toEqual([18_000, 24_000, 18_000]);
  });
});
