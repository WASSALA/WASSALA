import { describe, expect, it } from "vitest";
import { MOCK_FIL, getTransaction } from "@/lib/api/mock";
import { buildRecap, extractLocal, mergeAi, parseAmount, type AiAccord } from "@/lib/sanad/accord";

const tx = getTransaction("tx-001")!;
const fil = MOCK_FIL["tx-001"]!;

describe("récapitulatif d'accord · extraction locale", () => {
  const { clauses, conditions } = extractLocal(fil);

  it("retrouve les termes convenus avec leurs messages sources", () => {
    expect(clauses.quantite).toEqual({ value: "20 tonnes", sources: [5] });
    expect(clauses.produit?.value).toBe("dattes Deglet Nour");
    expect(clauses.conditionnement?.value).toBe("cartons de 5 kg");
    expect(clauses.prixUnitaire?.value.replace(/ /g, " ")).toBe("3 000 $ la tonne");
    expect(clauses.valeur?.value.replace(/ /g, " ")).toBe("60 000 $");
    expect(clauses.codeSH).toEqual({ value: "0804.10", sources: [9] });
  });

  it("cumule les sources quand les deux parties reprennent le même terme", () => {
    expect(clauses.incoterm).toEqual({ value: "CPT Nouakchott", sources: [6, 7] });
    expect(clauses.delai).toEqual({ value: "45 jours après l’accord", sources: [6, 7] });
    expect(clauses.paiement?.sources).toEqual([7]);
  });

  it("relève les conditions particulières demandées par une partie", () => {
    expect(conditions).toHaveLength(1);
    expect(conditions[0]!.sources).toEqual([11]);
  });

  it("calcule la commission et les tranches sur la valeur convenue, pas sur une valeur inventée", () => {
    const r = buildRecap(tx, fil, clauses, conditions, "local");
    expect(r.commission.base).toBe(60_000);
    expect(r.commission.baseSource).toBe("fil");
    expect(r.commission.total).toBe(2_400);
    expect(r.tranches.map((t) => t.amount)).toEqual([18_000, 24_000, 18_000]);
    expect(r.clauses.find((c) => c.id === "regime")?.status).toBe("à confirmer");
    expect(r.missing).toEqual([]);
  });
});

describe("récapitulatif d'accord · rien n'est inventé", () => {
  it("un Fil vide laisse tous les termes manquants et signale la valeur du brief à confirmer", () => {
    const empty = extractLocal([]);
    const r = buildRecap(tx, [], empty.clauses, empty.conditions, "local");
    expect(r.clauses.filter((c) => c.status === "manquant")).toHaveLength(r.clauses.length - 1);
    const v = r.clauses.find((c) => c.id === "valeur")!;
    expect(v.status).toBe("à confirmer");
    expect(r.commission.baseSource).toBe("brief");
  });

  it("une valeur du modèle sans source valide est ignorée", () => {
    const local = extractLocal(fil).clauses;
    const ai: AiAccord = {
      clauses: { incoterm: { value: "DDP Dakar", sources: [99] }, delai: { value: "30 jours", sources: [] }, produit: { value: "dattes Deglet Nour (catégorie I)", sources: [5] } },
      conditions: [],
    };
    const merged = mergeAi(local, ai, fil.length);
    expect(merged.incoterm?.value).toBe("CPT Nouakchott");
    expect(merged.delai?.value).toBe("45 jours après l’accord");
    expect(merged.produit).toEqual({ value: "dattes Deglet Nour (catégorie I)", sources: [5] });
  });

  it("lit un montant écrit à la française", () => {
    expect(parseAmount("60 000 $")).toBe(60_000);
    expect(parseAmount("Non précisé")).toBeNull();
  });
});
