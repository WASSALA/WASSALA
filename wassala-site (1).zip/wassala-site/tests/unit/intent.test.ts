import { describe, expect, it } from "vitest";
import { briefHref, describeIntent, detectIntent, isBriefIntent } from "@/lib/ai/intent";

describe("detectIntent", () => {
  it("comprend un projet d'export simple", () => {
    const i = detectIntent("J’exporte des dattes de Biskra vers le Sénégal");
    expect(i.role).toBe("exportateur");
    expect(i.secteur).toBe("Agroalimentaire");
    expect(i.produit).toBe("dattes");
    expect(i.paysOrigine).toBe("Algérie");
    expect(i.paysDestination).toBe("Sénégal");
    expect(isBriefIntent(i)).toBe(true);
  });

  it("comprend un acheteur, une quantité et une valeur", () => {
    const i = detectIntent("Je cherche un fournisseur de ciment en Algérie pour Nouakchott, 50 000 tonnes, budget 2 M$");
    expect(i.role).toBe("acheteur");
    expect(i.secteur).toBe("Matériaux et BTP");
    expect(i.paysOrigine).toBe("Algérie");
    expect(i.paysDestination).toBe("Mauritanie");
    expect(i.quantite).toBe("50 000 tonnes");
    expect(i.valeur).toBe(2_000_000);
    expect(i.devise).toBe("USD");
  });

  it("distingue le Niger du Nigéria et lit les montants en k", () => {
    const i = detectIntent("Nous vendons des tracteurs au Nigeria, environ 120k dollars");
    expect(i.paysDestination).toBe("Nigéria");
    expect(i.secteur).toBe("Machinisme agricole");
    expect(i.valeur).toBe(120_000);
  });

  it("« chercher des acheteurs » signifie exporter", () => {
    expect(detectIntent("Je cherche des acheteurs pour mon huile d'olive au Mali").role).toBe("exportateur");
  });

  it("ne voit pas de projet dans une simple question", () => {
    const i = detectIntent("Comment fonctionne le séquestre AMANA ?");
    expect(isBriefIntent(i)).toBe(false);
  });

  it("produit un lien de brief pré-rempli et un résumé lisible", () => {
    const i = detectIntent("J'exporte du ciment vers la Mauritanie");
    const href = briefHref(i);
    expect(href.startsWith("/app/transactions/new?")).toBe(true);
    expect(href).toContain("role=exportateur");
    expect(href).toContain("destination=Mauritanie");
    expect(describeIntent(i)).toContain("Algérie → Mauritanie");
  });
});
