# WASSALA · site et application SANAD

> Le lien qui construit l’Afrique.

Site vitrine de WASSALA (agence de coopération à portée panafricaine basée à Alger) et application de démonstration **SANAD** (service Finder’s Fee).
Next.js 15 (App Router), React 19, TypeScript strict, Tailwind CSS 3.4, Framer Motion.

---

## Démarrage rapide

```bash
# Node.js 20.9 ou plus récent
npm install
cp .env.example .env.local      # facultatif : tout fonctionne sans clé
npm run dev                      # http://localhost:3000
```

| Script | Rôle |
|---|---|
| `npm run dev` | serveur de développement |
| `npm run build` puis `npm start` | build et serveur de production |
| `npm run typecheck` | vérification TypeScript |
| `npm run lint` | ESLint (règles Next.js) |
| `npm test` | tests unitaires (Vitest) : commission, détection d’intention, assistant, formulaires |
| `npm run test:e2e` | tests de bout en bout (Playwright ; installer d’abord `npx playwright install chromium`) |
| `npm run check` | typecheck + lint + tests |

## Variables d’environnement

| Variable | Obligatoire | Effet |
|---|---|---|
| `NEXT_PUBLIC_SITE_URL` | en production | URL canonique, Open Graph, sitemap |
| `NEXT_PUBLIC_DEFAULT_LOCALE` | non | langue par défaut (`fr`) |
| `ANTHROPIC_API_KEY` | non | active l’assistant connecté à Claude ; sans clé, il répond depuis la base de connaissances locale |
| `ASSISTANT_MODEL` | non | modèle utilisé (par défaut `claude-haiku-5-5`) |
| `FORMS_WEBHOOK_URL` | recommandé | reçoit en JSON les envois de formulaires (Make, Zapier, n8n, CRM…). Sans URL, les envois sont journalisés côté serveur |

## Pages

| URL | Contenu |
|---|---|
| `/` | Accueil : hero et carte animée, vision, l’agence, périmètre ZLECAf, le constat (+ devenir exportateur / devenir acheteur), SANAD en condensé, projets continentaux, promesse, contact |
| `/sanad` | Deuxième page : SANAD en détail (six mécanismes en récit défilant, parcours, simulateur à curseurs et corridor, conformité ZLECAf) |
| `/heritage` | Pourquoi Alger : légitimité historique, puis frise chronologique et sept grands moments dans une seule section |
| `/projets-continentaux` | Incubation, formation, investissement et placement financier, centrés sur l’Afrique et l’éthique |
| `/mentions-legales` | Mentions légales, données personnelles, cookies |
| `/app/*` | Application SANAD (démonstration, non indexée) : tableau de bord, transactions, brief, matching, veille, coaching IA, KYC, Deal House, Deal Room, annuaires, Market Intelligence, mode SMS/USSD, réglages |

Les anciennes URL sont redirigées (308) : `/projet` → `/`, `/formation` et `/investissement` → `/projets-continentaux#…`.

## L’IA au service de l’expérience

1. **Assistant WASSALA** (bouton flottant sur toutes les pages, `src/components/shared/AIChatWidget.tsx`)
   - réponses en flux (`/api/assistant`, protocole NDJSON) ;
   - **mode connecté** si `ANTHROPIC_API_KEY` est défini : Claude répond, strictement ancré sur la base de connaissances `src/data/knowledge.ts`, avec des règles explicites (n’invente aucun chiffre ; WASSALA accompagne et ne finance pas ; ne détient jamais les fonds…) ;
   - **mode local** sinon : recherche pondérée dans la même base, sans dépendance externe ;
   - suggestions selon la page, et **actions concrètes** sous chaque réponse : si l’utilisateur décrit un projet (« J’exporte des dattes vers le Sénégal »), un bouton ouvre le **brief pré-rempli**.
2. **Barre « Demander » de l’accueil** : une phrase suffit pour lancer l’assistant.
3. **Palette de commandes** (`Ctrl/⌘ + K` ou `/`) : navigation, sections, application, et détection d’intention en direct (« ciment vers la Mauritanie 200 000 $ » → « Préparer un brief : Exportateur · Ciment · Algérie → Mauritanie · 200 000 $ »).
4. **Brief SANAD pré-rempli** (`/app/transactions/new`) : l’utilisateur décrit son besoin en une phrase, `/api/brief/extract` remplit les champs (heuristique locale, complétée par Claude si configuré), les champs pré-remplis s’illuminent, un récapitulatif se met à jour en direct (complétude, commission, tranches AMANA).
5. **Coaching IA** (`/app/coaching`), **veille** avec explication des scores, **prochaine meilleure action** au tableau de bord, **brief par SMS** compris par l’assistant.
6. **Récapitulatif d’accord SANAD** (`/app/transactions/[id]`, à partir de l’étape Négociation) : l’IA relit le Fil et rassemble les termes convenus entre l’acheteur et le vendeur (produit, quantité, prix, incoterm, délai, code SH, régime ZLECAf, paiement, conditions particulières).
   - chaque terme cite les messages du Fil dont il vient (cliquer sur `#6` fait défiler le Fil jusqu’au message) ; ce qui n’est pas écrit reste « manquant » et peut être demandé aux parties ;
   - la commission, les tranches AMANA et les missions CHAHID sont **calculées par le code**, jamais par le modèle ;
   - circuit : brouillon généré → validé par l’agent → soumis aux parties ; impression ou PDF du seul document ;
   - **document interne** : il ne vaut ni facture, ni contrat de vente entre les parties ;
   - `/api/accord` : extraction locale déterministe (`src/lib/sanad/accord.ts`, testée), complétée par Claude si `ANTHROPIC_API_KEY` est défini ; une valeur du modèle n’est retenue que si elle cite des messages existants.
   - Le **mandat SANAD** est accepté par chaque partie avant sa présentation à l’autre (carte « Mandat SANAD » de la transaction).

La détection d’intention (`src/lib/ai/intent.ts`) est déterministe et testée : rôle, secteur, produit, pays (54 États africains et leurs villes), valeur, quantité.

## Animations et accessibilité

- Carte de l’Afrique animée et interactive (liens tracés, flux aller-retour, routes maritimes, survol des villes, inclinaison 3D), titres qui montent mot à mot, manifeste qui s’éclaire au défilement, cartes à halo lumineux, boutons magnétiques, récit défilant des six mécanismes, frise dont la ligne se remplit, compteurs, simulateur animé, transitions d’état.
- **Mouvement réduit** respecté partout (`prefers-reduced-motion`) : animations désactivées, contenu statique et complet.
- Sans JavaScript, rien n’est masqué (la classe `js` conditionne les apparitions).
- Navigation clavier, lien d’évitement, focus visibles, onglets ARIA, `aria-live` pour l’assistant et les formulaires, cibles tactiles ≥ 44 px, contrastes de la charte (or de lecture `#7A6030` pour le texte courant).

## Langues

L’interface (navigation, pied de page, hero, assistant, palette) existe en **français, anglais, portugais, arabe et swahili**. La langue est stockée dans un cookie (`wassala-locale`) : `lang` et `dir` sont corrects dès le rendu serveur (arabe en RTL sans clignotement).
Le contenu éditorial détaillé reste en français ; un bandeau l’indique honnêtement dans les autres langues. **Les traductions arabe, portugaise et swahili doivent être relues par des locuteurs natifs** avant publication (`src/lib/i18n/dictionaries.ts`).

## Formulaires

Contact, « Être prévenu » et brief SANAD : validation zod partagée client/serveur (`src/lib/forms/schemas.ts`), champ piège anti-robot, consentement explicite, limitation de débit, transmission au webhook `FORMS_WEBHOOK_URL` avec une référence unique.

## Sécurité et performance

- En-têtes : CSP (production), HSTS, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` ; `/app` en `noindex`.
- Polices **auto-hébergées** (`public/fonts`, licence OFL) : aucune requête vers un tiers.
- La clé API ne quitte jamais le serveur ; l’assistant ne reçoit que les 10 derniers messages.
- Le limiteur de débit est en mémoire : derrière plusieurs instances, le brancher sur un stockage partagé (Redis, KV).
- La langue lue dans un cookie rend les pages dynamiques ; pour un cache CDN agressif, passer à des URL préfixées (`/en`, `/ar`…).

## Déploiement

Vercel (recommandé) ou tout hébergeur Node : `npm run build && npm start`. Définir au minimum `NEXT_PUBLIC_SITE_URL` et `FORMS_WEBHOOK_URL`.

## Brancher un backend

L’application lit des données de démonstration (`src/lib/api/mock.ts`, types dans `src/lib/api/types.ts`). Remplacer ces fonctions par des appels à l’API réelle (authentification, transactions, KYC, Deal Room) sans toucher aux composants.

## À compléter avant la mise en ligne

Tout fait manquant est affiché comme `[placeholder]`, jamais inventé. À renseigner :

- `src/data/site.ts` : email, LinkedIn, téléphone, délai de réponse ;
- `src/data/stats.ts` : chiffres clés (transactions accompagnées, corridors couverts, projets accompagnés) ;
- `src/lib/sanad/commission.ts` : règle de répartition SILSILA (illustrative) ;
- `src/data/heritage.ts` : citations à sourcer, chiffres à vérifier, références détaillées ;
- `src/data/platforms.ts` : calendriers, modèle du placement éthique, limites marquées « À valider » ;
- mentions légales (éditeur, registre, hébergeur), charte éthique, code USSD, coordonnées des ambassades.
- texte du mandat SANAD et du récapitulatif d’accord (à faire valider par un juriste : droit algérien, droit du pays de l’acheteur, règles de change pour le paiement des commissions) ; prestataire de signature électronique.

## Correctifs intégrés

Voir [`CORRECTIFS.md`](./CORRECTIFS.md) : chaque demande et l’endroit exact où elle est appliquée.
