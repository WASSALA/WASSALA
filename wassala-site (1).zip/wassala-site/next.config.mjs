/** @type {import('next').NextConfig} */

const isProd = process.env.NODE_ENV === "production";

/**
 * Politique de sécurité du contenu.
 * - Les scripts inline de Next (hydratation) imposent 'unsafe-inline' sans nonce.
 * - En développement, le rechargement à chaud a besoin de 'unsafe-eval' : la CSP n'est posée qu'en production.
 * - L'assistant appelle l'API Claude côté serveur uniquement : aucun domaine externe dans connect-src.
 */
const csp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self'",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
].join("; ");

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), interest-cohort=()" },
  { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
  ...(isProd ? [{ key: "Content-Security-Policy", value: csp }] : []),
];

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  images: { formats: ["image/avif", "image/webp"] },
  experimental: { optimizePackageImports: ["lucide-react", "framer-motion", "recharts"] },
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      // L'application SANAD (démonstration) ne doit pas être indexée.
      { source: "/app/:path*", headers: [{ key: "X-Robots-Tag", value: "noindex, nofollow" }] },
    ];
  },
  async redirects() {
    return [
      // La page « Le projet » a disparu : son contenu est sur l'accueil et sur /projets-continentaux.
      { source: "/projet", destination: "/", permanent: true },
      { source: "/le-projet", destination: "/", permanent: true },
      // Les anciens onglets Formation et Investissement deviennent la page Projets continentaux.
      { source: "/formation", destination: "/projets-continentaux#formation", permanent: true },
      { source: "/investissement", destination: "/projets-continentaux#investissement", permanent: true },
      { source: "/incubateur", destination: "/projets-continentaux#incubation", permanent: true },
      { source: "/finders-fee", destination: "/sanad", permanent: true },
    ];
  },
};

export default nextConfig;
