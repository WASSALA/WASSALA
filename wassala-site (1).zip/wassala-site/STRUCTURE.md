# WASSALA · Arborescence (version finale)

Dossier `src/` pour éviter la collision entre le dossier Next `app/` (routeur) et la route publique `/app` (application SANAD).

```
wassala-site/
├── package.json · tsconfig.json · next.config.mjs · tailwind.config.ts · postcss.config.mjs
├── eslint.config.mjs · vitest.config.ts · playwright.config.ts · .env.example
├── README.md · CORRECTIFS.md · STRUCTURE.md
├── public/fonts/                     Fraunces, Inter, Noto Naskh Arabic (woff2 variables, OFL)
├── tests/
│   ├── unit/                         commission, intention, assistant, formulaires, langues
│   └── e2e/smoke.spec.ts             correctifs, brief, simulateur, Héritage, assistant
└── src/
    ├── app/
    │   ├── layout.tsx                langue (cookie) → lang/dir, palette, couche d'interactions, toasts
    │   ├── fonts.css · globals.css   polices auto-hébergées ; jetons, composants, animations, mouvement réduit
    │   ├── (marketing)/
    │   │   ├── layout.tsx            barre de progression, en-tête, bandeau de traduction, pied de page, assistant
    │   │   ├── page.tsx              /                         accueil
    │   │   ├── sanad/                /sanad                    deuxième page
    │   │   ├── heritage/             /heritage
    │   │   ├── projets-continentaux/ /projets-continentaux
    │   │   └── mentions-legales/     /mentions-legales
    │   ├── app/                      /app/*                    application SANAD (démonstration)
    │   │   ├── page.tsx · loading.tsx · layout.tsx
    │   │   ├── transactions/ (liste, new = brief pré-rempli, [id] = fil, SILSILA, AMANA, DAMAN)
    │   │   ├── matching · veille · coaching · kyc · deal-house · deal-room
    │   │   ├── annuaire/agents · annuaire/ambassades · market-intel · offline · settings
    │   ├── api/
    │   │   ├── assistant/route.ts    flux NDJSON : Claude (si clé) ou base de connaissances
    │   │   ├── brief/route.ts · brief/extract/route.ts
    │   │   ├── contact/route.ts · notify/route.ts
    │   ├── sitemap.ts · robots.ts · manifest.ts · opengraph-image.tsx · icon.svg
    │   └── not-found.tsx · error.tsx
    ├── components/
    │   ├── marketing/                accueil + sanad/ + heritage/ + projets/
    │   ├── app/                      coquille, barre latérale, brief, matching, veille, coaching, KYC, Deal Room…
    │   ├── motion/                   SplitText, ScrollWords, Reveal, Magnetic, Counter, ScrollProgress, InteractionLayer
    │   └── shared/                   Navbar, Footer, Logo (tracé exact du waw), AfricaMap, CommandPalette,
    │                                 AIChatWidget, ChatThread, ChatComposer, RichText, LanguageSwitcher…
    ├── data/                         site, capitals, countries (54), heritage, knowledge, platforms, stats
    └── lib/
        ├── ai/                       intent (détection), retrieve, local-answer, protocol, useAssistant
        ├── api/                      types, mock (données de démonstration)
        ├── forms/schemas.ts          zod partagé client/serveur
        ├── i18n/                     dictionnaires 5 langues, serveur, provider client
        ├── sanad/                    commission (SILSILA, AMANA, DAMAN), readiness (score)
        ├── server/                   forward (webhook), rate-limit
        ├── hooks/useActiveSection.ts
        └── locale.ts · map-geometry.ts · events.ts · utils.ts
```

## Décisions

| Sujet | Décision | Raison |
|---|---|---|
| Framework | Next.js 15.5.28 | Branche 15 maintenue avec correctifs de sécurité |
| Styles | Tailwind 3.4, jetons en variables CSS (canaux RGB) | Une seule source pour la charte, opacités Tailwind disponibles |
| Polices | Auto-hébergées (`public/fonts`) | Pas de dépendance à Google Fonts au build ni à l'exécution ; RGPD |
| Langue | Cookie `wassala-locale`, pas de préfixe d'URL | `lang`/`dir` corrects dès le rendu serveur, arabe sans clignotement |
| IA | Base de connaissances locale + Claude en option | Fonctionne sans clé ; avec clé, réponses ancrées sur les mêmes fiches |
| Données | Aucun fait inventé : `[placeholder]` visibles | Exigence éditoriale du projet |
