# Correctifs demandés et leur application

| # | Demande | Application | Fichiers |
|---|---|---|---|
| 1 | Enlever les onglets Investissement et Formation ; en faire une section Projets continentaux | La navigation ne compte plus que SANAD, Héritage, Projets continentaux. L’accueil a une section « Projets continentaux » (4 plateformes, « À venir »). Les anciennes URL redirigent | `src/data/site.ts`, `src/components/marketing/ContinentalProjects.tsx`, `next.config.mjs` |
| 2 | Une page Projets continentaux : incubation, formation, investissement, placement financier, centrés sur l’Afrique et l’éthique | Page complète : écosystème animé, 4 plateformes détaillées (objectif, contenu, limite), objectifs « Centrés sur l’Afrique », principes « Guidés par l’éthique », enchaînement, « Être prévenu » | `src/app/(marketing)/projets-continentaux/page.tsx`, `src/data/platforms.ts`, `src/components/marketing/projets/*` |
| 3 | Accueil : des entrepreneurs qui deviennent des opérateurs économiques de leur continent (et non l’inverse) ; WASSALA accompagne (ne finance pas) ceux qui sont prêts | Hero, métadonnées, bloc « Notre rôle » (Transformer · Relier · Accompagner), assistant (règle explicite), chiffres clés renommés « projets accompagnés » | `Hero.tsx`, `AgencyBlock.tsx`, `src/data/stats.ts`, `src/data/knowledge.ts`, `src/app/api/assistant/route.ts` |
| 4 | Accueil : « Une agence de coopération à portée panafricaine… à travers les flux commerciaux » | Texte repris mot pour mot, « flux commerciaux » mis en valeur, schéma Algérie ↔ reste du continent | `AgencyBlock.tsx` |
| 5 | Textes « Nous avons un objectif… » et « Créer du lien… » | Repris mot pour mot dans les blocs « Pourquoi ? » et « Créer du lien » (avec وصلة) | `AgencyBlock.tsx` |
| 6 | Le constat : deux CTA, devenir exportateur et devenir acheteur | Deux grands appels à l’action distincts, chacun avec sa promesse ; ils ouvrent le brief avec le bon rôle pré-sélectionné (`?role=exportateur` / `?role=acheteur`) | `Constat.tsx`, `src/components/app/BriefForm.tsx` |
| 7 | « Trois services, un seul réseau » : présenter SANAD uniquement en condensé | Remplacé par un bloc SANAD condensé : définition, six mécanismes en onglets animés, trois garanties, lien vers `/sanad` | `SANADCondensed.tsx` |
| 8 | Retirer « Du diagnostic au financement » de l’accueil | Absent de l’accueil | `src/app/(marketing)/page.tsx` |
| 9 | Enlever l’onglet Formation | Fait (voir 1) | `src/data/site.ts` |
| 10 | SANAD devient la deuxième page à la place de « Le projet » | `/sanad` est le premier lien après l’accueil ; `/projet` redirige vers l’accueil | `src/data/site.ts`, `next.config.mjs` |
| 11 | Héritage : faire un peu d’Histoire pour légitimer qu’une entreprise panafricaine peut s’implanter à Alger | Section « Pourquoi cette page » qui le dit explicitement, et trois piliers de légitimité | `HeritageContext.tsx` |
| 12 | Héritage : après la frise, les 7 grands moments dans une seule et même section | Frise chronologique puis sept grands moments, dans la même section `#frise` (ancre `#moments`) | `HeritageJourney.tsx` |
| 13 | Accueil : retirer la section Héritage | Absente de l’accueil | `src/app/(marketing)/page.tsx` |

Vérifié automatiquement par `tests/e2e/smoke.spec.ts` (navigation, CTA, textes, section unique de l’Héritage).
